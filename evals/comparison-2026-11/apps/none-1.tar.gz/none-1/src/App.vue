<script setup lang="ts">
import { RouterLink, RouterView, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()
const router = useRouter()

async function logout() {
  await auth.logout()
  await router.replace({ name: 'login' })
}
</script>

<template>
  <header v-if="auth.isLoggedIn" class="topbar">
    <RouterLink to="/tickets" class="brand">Support Desk</RouterLink>
    <nav>
      <RouterLink to="/tickets/new">New ticket</RouterLink>
      <span v-if="auth.user" class="muted">{{ auth.user.name }}</span>
      <button type="button" @click="logout">Log out</button>
    </nav>
  </header>
  <RouterView />
</template>
