import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createMemoryHistory } from 'vue-router'
import { createPinia, setActivePinia } from 'pinia'
import { createAppRouter, safeRedirect } from '..'
import { useAuthStore } from '@/stores/auth'
import { setToken } from '@/api/client'

vi.mock('@/api', () => ({
  api: {
    me: vi.fn<() => Promise<unknown>>().mockResolvedValue({ id: 'u1', name: 'Dana' }),
    login: vi
      .fn<() => Promise<unknown>>()
      .mockResolvedValue({ token: 't', user: { id: 'u1', name: 'Dana', email: 'd@x.io' } }),
    logout: vi.fn<() => Promise<void>>().mockResolvedValue(undefined),
  },
}))

describe('auth guard', () => {
  beforeEach(() => {
    localStorage.clear()
    setActivePinia(createPinia())
  })

  it('redirects anonymous users to login with the wanted path', async () => {
    const router = createAppRouter(createMemoryHistory())
    await router.push('/tickets/5?x=1')
    expect(router.currentRoute.value.name).toBe('login')
    expect(router.currentRoute.value.query.redirect).toBe('/tickets/5?x=1')
  })

  it('lets logged-in users through and bounces them off login', async () => {
    setToken('t')
    setActivePinia(createPinia())
    const router = createAppRouter(createMemoryHistory())
    await router.push('/tickets/5')
    expect(router.currentRoute.value.fullPath).toBe('/tickets/5')
    await router.push('/login')
    expect(router.currentRoute.value.fullPath).toBe('/tickets')
  })

  it('returns to the wanted page after login', async () => {
    const router = createAppRouter(createMemoryHistory())
    await router.push('/tickets/5')
    await useAuthStore().login('d@x.io', 'pw')
    await router.push(safeRedirect(router.currentRoute.value.query.redirect)!)
    expect(router.currentRoute.value.fullPath).toBe('/tickets/5')
  })
})

describe('safeRedirect', () => {
  it('only allows in-app paths', () => {
    expect(safeRedirect('/tickets?page=2')).toBe('/tickets?page=2')
    expect(safeRedirect('//evil.com')).toBeNull()
    expect(safeRedirect('https://evil.com')).toBeNull()
    expect(safeRedirect(undefined)).toBeNull()
  })
})
