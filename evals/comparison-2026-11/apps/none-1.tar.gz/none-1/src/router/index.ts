import { createRouter, createWebHistory, type Router, type RouterHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

export function createAppRouter(
  history: RouterHistory = createWebHistory(import.meta.env.BASE_URL),
): Router {
  const router = createRouter({
    history,
    routes: [
      {
        path: '/login',
        name: 'login',
        component: () => import('@/views/LoginView.vue'),
        meta: { public: true },
      },
      { path: '/', redirect: '/tickets' },
      { path: '/tickets', name: 'tickets', component: () => import('@/views/TicketListView.vue') },
      {
        path: '/tickets/new',
        name: 'ticket-new',
        component: () => import('@/views/TicketFormView.vue'),
      },
      {
        path: '/tickets/:id',
        name: 'ticket',
        component: () => import('@/views/TicketDetailView.vue'),
        props: true,
      },
      {
        path: '/tickets/:id/edit',
        name: 'ticket-edit',
        component: () => import('@/views/TicketFormView.vue'),
        props: true,
      },
      { path: '/:pathMatch(.*)*', redirect: '/tickets' },
    ],
  })

  router.beforeEach(async (to) => {
    const auth = useAuthStore()
    if (to.meta.public) {
      if (auth.isLoggedIn) return safeRedirect(to.query.redirect) ?? '/tickets'
      return true
    }
    if (!auth.isLoggedIn) return { name: 'login', query: { redirect: to.fullPath } }
    await auth.restore()
    // restore() drops the session if the stored token is invalid
    if (!auth.isLoggedIn) return { name: 'login', query: { redirect: to.fullPath } }
    return true
  })

  return router
}

/** Only allow in-app paths as redirect targets (prevents open redirects). */
export function safeRedirect(value: unknown): string | null {
  const v = Array.isArray(value) ? value[0] : value
  if (typeof v !== 'string' || !v.startsWith('/') || v.startsWith('//')) return null
  return v
}
