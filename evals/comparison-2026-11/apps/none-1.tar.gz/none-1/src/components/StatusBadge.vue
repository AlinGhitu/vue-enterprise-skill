<script setup lang="ts">
import { STATUS_LABELS, type Status } from '@/api/types'

defineProps<{ status: Status }>()
</script>

<template>
  <span class="badge" :class="`badge-${status}`">{{ STATUS_LABELS[status] }}</span>
</template>
