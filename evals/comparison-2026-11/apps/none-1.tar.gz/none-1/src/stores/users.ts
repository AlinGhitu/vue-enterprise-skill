import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { api } from '@/api'
import type { User } from '@/api/types'

export const useUsersStore = defineStore('users', () => {
  const users = ref<User[]>([])
  const loaded = ref(false)
  let pending: Promise<void> | null = null

  const byId = computed(() => new Map(users.value.map((u) => [u.id, u])))

  function nameOf(id: string | null | undefined): string {
    if (!id) return 'Unassigned'
    return byId.value.get(id)?.name ?? 'Unknown user'
  }

  function load(): Promise<void> {
    if (loaded.value) return Promise.resolve()
    pending ??= api
      .users()
      .then((u) => {
        users.value = u
        loaded.value = true
      })
      .finally(() => {
        pending = null
      })
    return pending
  }

  return { users, loaded, nameOf, load }
})
