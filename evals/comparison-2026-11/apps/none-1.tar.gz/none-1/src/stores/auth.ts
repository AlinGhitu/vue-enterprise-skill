import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { api } from '@/api'
import { getToken, setToken, setUnauthorizedHandler } from '@/api/client'
import type { User } from '@/api/types'

export const useAuthStore = defineStore('auth', () => {
  const token = ref<string | null>(getToken())
  const user = ref<User | null>(null)
  const isLoggedIn = computed(() => !!token.value)

  function clear() {
    token.value = null
    user.value = null
    setToken(null)
  }

  async function login(email: string, password: string) {
    const res = await api.login(email, password)
    setToken(res.token)
    token.value = res.token
    user.value = res.user
  }

  /** Load the current user if we have a token; an invalid token (401) drops the session. */
  async function restore() {
    if (!token.value || user.value) return
    try {
      user.value = await api.me()
    } catch {
      // 401 already cleared the session via the unauthorized handler;
      // other failures keep the token and surface on the pages.
    }
  }

  async function logout() {
    try {
      await api.logout()
    } catch {
      // log out locally regardless of the server outcome
    }
    clear()
  }

  setUnauthorizedHandler(clear)

  return { token, user, isLoggedIn, login, restore, logout }
})
