export class ApiError extends Error {
  status: number
  /** Field errors from a 422 response, keyed by field name. */
  fieldErrors: Record<string, string>

  constructor(status: number, message: string, fieldErrors: Record<string, string> = {}) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.fieldErrors = fieldErrors
  }
}

const TOKEN_KEY = 'support-desk-token'

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY)
}

export function setToken(token: string | null): void {
  if (token) localStorage.setItem(TOKEN_KEY, token)
  else localStorage.removeItem(TOKEN_KEY)
}

let onUnauthorized: (() => void) | null = null

/** Called when an authenticated request gets a 401 (expired/invalid token). */
export function setUnauthorizedHandler(fn: (() => void) | null): void {
  onUnauthorized = fn
}

export async function request<T>(
  method: string,
  path: string,
  options: { body?: unknown; query?: Record<string, string | number | undefined | null> } = {},
): Promise<T> {
  let url = '/api' + path
  if (options.query) {
    const params = new URLSearchParams()
    for (const [k, v] of Object.entries(options.query)) {
      if (v !== undefined && v !== null && v !== '') params.set(k, String(v))
    }
    const qs = params.toString()
    if (qs) url += '?' + qs
  }

  const headers: Record<string, string> = {}
  const token = getToken()
  if (token) headers.Authorization = 'Bearer ' + token
  if (options.body !== undefined) headers['Content-Type'] = 'application/json'

  let res: Response
  try {
    res = await fetch(url, {
      method,
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    })
  } catch {
    throw new ApiError(0, 'Network error. Check your connection and try again.')
  }

  if (res.status === 204) return undefined as T

  let data: unknown = null
  try {
    data = await res.json()
  } catch {
    // non-JSON body
  }

  if (!res.ok) {
    const d = (data ?? {}) as { message?: string; errors?: Record<string, string> }
    if (res.status === 401 && token && path !== '/login') onUnauthorized?.()
    throw new ApiError(
      res.status,
      d.message ?? 'Request failed (' + res.status + ')',
      d.errors ?? {},
    )
  }
  return data as T
}
