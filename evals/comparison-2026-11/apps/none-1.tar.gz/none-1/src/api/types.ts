export type Status = 'open' | 'in_progress' | 'closed'
export type Priority = 'low' | 'medium' | 'high'

export interface User {
  id: string
  name: string
  email: string
}

export interface Ticket {
  id: string
  title: string
  description: string
  status: Status
  priority: Priority
  assigneeId: string | null
  createdAt: string
  updatedAt: string
}

export interface Comment {
  id: string
  ticketId: string
  authorId: string
  body: string
  createdAt: string
}

export interface TicketPage {
  items: Ticket[]
  total: number
  page: number
  pageSize: number
}

export interface TicketInput {
  title: string
  description: string
  priority: Priority
  assigneeId: string | null
}

export const STATUSES: Status[] = ['open', 'in_progress', 'closed']
export const PRIORITIES: Priority[] = ['low', 'medium', 'high']
export const STATUS_LABELS: Record<Status, string> = {
  open: 'Open',
  in_progress: 'In progress',
  closed: 'Closed',
}
