import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { ApiError, request, setToken, setUnauthorizedHandler } from '../client'

function respond(status: number, body?: unknown) {
  return vi.fn<typeof fetch>(() =>
    Promise.resolve(new Response(body === undefined ? null : JSON.stringify(body), { status })),
  )
}

describe('request', () => {
  beforeEach(() => localStorage.clear())
  afterEach(() => {
    vi.unstubAllGlobals()
    setUnauthorizedHandler(null)
  })

  it('sends bearer token and builds the query string, skipping empty values', async () => {
    setToken('abc')
    const fetchMock = respond(200, { ok: true })
    vi.stubGlobal('fetch', fetchMock)
    await request('GET', '/tickets', { query: { q: 'x y', status: '', page: 2 } })
    const [url, init] = fetchMock.mock.calls[0]!
    expect(url).toBe('/api/tickets?q=x+y&page=2')
    expect(new Headers(init?.headers).get('Authorization')).toBe('Bearer abc')
  })

  it('exposes 422 field errors', async () => {
    vi.stubGlobal('fetch', respond(422, { message: 'Validation failed', errors: { title: 'bad' } }))
    const err = await request('POST', '/tickets', { body: {} }).catch((e: unknown) => e)
    expect(err).toBeInstanceOf(ApiError)
    expect((err as ApiError).status).toBe(422)
    expect((err as ApiError).fieldErrors).toEqual({ title: 'bad' })
  })

  it('calls the unauthorized handler on 401 with a token, but not for login', async () => {
    const handler = vi.fn<() => void>()
    setUnauthorizedHandler(handler)
    vi.stubGlobal('fetch', respond(401, { message: 'no' }))
    setToken('abc')
    await expect(request('GET', '/me')).rejects.toThrow('no')
    expect(handler).toHaveBeenCalledTimes(1)
    await expect(request('POST', '/login')).rejects.toThrow('no')
    expect(handler).toHaveBeenCalledTimes(1)
  })

  it('wraps network failures and handles 204', async () => {
    vi.stubGlobal('fetch', vi.fn<typeof fetch>().mockRejectedValue(new TypeError('fail')))
    await expect(request('GET', '/me')).rejects.toMatchObject({ status: 0 })
    vi.stubGlobal('fetch', respond(204))
    await expect(request('POST', '/logout')).resolves.toBeUndefined()
  })
})
