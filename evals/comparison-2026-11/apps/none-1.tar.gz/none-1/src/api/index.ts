import { request } from './client'
import type { Comment, Ticket, TicketInput, TicketPage, User, Status } from './types'

export interface TicketQuery {
  q?: string
  status?: Status | ''
  /** A user id, or `none` for unassigned. */
  assigneeId?: string
  page?: number
  pageSize?: number
}

const t = (id: string) => '/tickets/' + encodeURIComponent(id)

export const api = {
  login: (email: string, password: string) =>
    request<{ token: string; user: User }>('POST', '/login', { body: { email, password } }),
  logout: () => request<void>('POST', '/logout'),
  me: () => request<User>('GET', '/me'),
  users: () => request<User[]>('GET', '/users'),
  listTickets: (query: TicketQuery) =>
    request<TicketPage>('GET', '/tickets', { query: { ...query } }),
  getTicket: (id: string) => request<Ticket>('GET', t(id)),
  createTicket: (input: TicketInput) => request<Ticket>('POST', '/tickets', { body: input }),
  updateTicket: (id: string, patch: Partial<Ticket>) =>
    request<Ticket>('PATCH', t(id), { body: patch }),
  listComments: (id: string) => request<Comment[]>('GET', t(id) + '/comments'),
  addComment: (id: string, body: string) =>
    request<Comment>('POST', t(id) + '/comments', { body: { body } }),
}
