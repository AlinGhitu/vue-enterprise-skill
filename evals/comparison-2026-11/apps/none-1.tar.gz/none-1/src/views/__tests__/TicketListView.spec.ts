import { beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { createMemoryHistory, createRouter } from 'vue-router'
import TicketListView from '../TicketListView.vue'

const listTickets = vi.hoisted(() => vi.fn<(q: unknown) => Promise<unknown>>())
vi.mock('@/api', () => ({
  api: {
    listTickets,
    users: vi.fn<() => Promise<unknown>>().mockResolvedValue([
      { id: 'u1', name: 'Dana', email: 'd@x.io' },
      { id: 'u2', name: 'Lee', email: 'l@x.io' },
    ]),
  },
}))

const ASSIGNEE = 'select[aria-label="Filter by assignee"]'

async function setup(url: string) {
  const router = createRouter({
    history: createMemoryHistory(),
    routes: [{ path: '/tickets', name: 'tickets', component: TicketListView }],
  })
  await router.push(url)
  const wrapper = mount(TicketListView, { global: { plugins: [router] } })
  await flushPromises()
  return { router, wrapper }
}

describe('TicketListView URL state', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    listTickets.mockReset()
    listTickets.mockResolvedValue({ items: [], total: 0, page: 1, pageSize: 10 })
  })

  it('loads filters from the URL', async () => {
    const { wrapper } = await setup('/tickets?q=foo&status=open&assignee=none&page=2')
    expect(listTickets).toHaveBeenCalledWith({
      q: 'foo',
      status: 'open',
      assigneeId: 'none',
      page: 2,
      pageSize: 10,
    })
    const sel = wrapper.get<HTMLSelectElement>(ASSIGNEE)
    expect(sel.element.value).toBe('none')
    expect(sel.findAll('option').map((o) => o.text())).toEqual([
      'All assignees',
      'Unassigned',
      'Dana',
      'Lee',
    ])
  })

  it('writes the assignee to the URL, resets the page, and follows back/forward', async () => {
    const { router, wrapper } = await setup('/tickets?page=3')
    await wrapper.get(ASSIGNEE).setValue('u2')
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ assignee: 'u2' })
    expect(listTickets).toHaveBeenLastCalledWith(
      expect.objectContaining({ assigneeId: 'u2', page: 1 }),
    )

    router.back()
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ page: '3' })
    expect(listTickets).toHaveBeenLastCalledWith(
      expect.objectContaining({ assigneeId: '', page: 3 }),
    )
    expect(wrapper.get<HTMLSelectElement>(ASSIGNEE).element.value).toBe('')
  })

  it('debounces search into the URL', async () => {
    vi.useFakeTimers()
    try {
      const { router, wrapper } = await setup('/tickets')
      await wrapper.get('input[type=search]').setValue(' bug ')
      vi.advanceTimersByTime(300)
      await flushPromises()
      expect(router.currentRoute.value.query).toEqual({ q: 'bug' })
    } finally {
      vi.useRealTimers()
    }
  })
})
