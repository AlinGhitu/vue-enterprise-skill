<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { RouterLink, useRouter } from 'vue-router'
import { api } from '@/api'
import { ApiError } from '@/api/client'
import { PRIORITIES, type Priority } from '@/api/types'
import { useUsersStore } from '@/stores/users'
import { validateTicket, type FieldErrors } from '@/lib/validation'

const props = defineProps<{ id?: string }>()
const router = useRouter()
const users = useUsersStore()

const isEdit = computed(() => !!props.id)
const form = reactive({
  title: '',
  description: '',
  priority: 'medium' as Priority,
  assigneeId: '' as string,
})
const errors = ref<FieldErrors>({})
const formError = ref('')
const loading = ref(false)
const loadError = ref('')
const submitting = ref(false)

async function load() {
  loadError.value = ''
  try {
    await users.load()
  } catch (e) {
    loadError.value = e instanceof Error ? e.message : 'Failed to load users'
    return
  }
  if (!props.id) return
  loading.value = true
  try {
    const t = await api.getTicket(props.id)
    form.title = t.title
    form.description = t.description
    form.priority = t.priority
    form.assigneeId = t.assigneeId ?? ''
  } catch (e) {
    loadError.value = e instanceof Error ? e.message : 'Failed to load ticket'
  } finally {
    loading.value = false
  }
}
watch(() => props.id, load, { immediate: true })

async function submit() {
  formError.value = ''
  errors.value = validateTicket(form)
  if (Object.keys(errors.value).length) return
  const payload = {
    title: form.title.trim(),
    description: form.description.trim(),
    priority: form.priority,
    assigneeId: form.assigneeId || null,
  }
  submitting.value = true
  try {
    const t = props.id ? await api.updateTicket(props.id, payload) : await api.createTicket(payload)
    await router.push({ name: 'ticket', params: { id: t.id } })
  } catch (e) {
    if (e instanceof ApiError && e.status === 422) {
      errors.value = e.fieldErrors
      formError.value = Object.keys(e.fieldErrors).length ? '' : e.message
    } else {
      formError.value = e instanceof Error ? e.message : 'Failed to save ticket'
    }
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <main class="narrow">
    <h1>{{ isEdit ? 'Edit ticket' : 'New ticket' }}</h1>
    <p v-if="loading" class="state">Loading ticket…</p>
    <p v-else-if="loadError" class="state error" role="alert">
      {{ loadError }} <button type="button" @click="load">Retry</button>
    </p>
    <form v-else novalidate @submit.prevent="submit">
      <label>
        Title
        <input v-model="form.title" :aria-invalid="!!errors.title" />
        <span v-if="errors.title" class="error">{{ errors.title }}</span>
      </label>
      <label>
        Description
        <textarea
          v-model="form.description"
          rows="5"
          :aria-invalid="!!errors.description"
        ></textarea>
        <span v-if="errors.description" class="error">{{ errors.description }}</span>
      </label>
      <label>
        Priority
        <select v-model="form.priority">
          <option v-for="p in PRIORITIES" :key="p" :value="p">{{ p }}</option>
        </select>
        <span v-if="errors.priority" class="error">{{ errors.priority }}</span>
      </label>
      <label>
        Assignee
        <select v-model="form.assigneeId">
          <option value="">Unassigned</option>
          <option v-for="u in users.users" :key="u.id" :value="u.id">{{ u.name }}</option>
        </select>
        <span v-if="errors.assigneeId" class="error">{{ errors.assigneeId }}</span>
      </label>
      <p v-if="formError" class="error" role="alert">{{ formError }}</p>
      <div class="actions">
        <button type="submit" class="primary" :disabled="submitting">
          {{ submitting ? 'Saving…' : isEdit ? 'Save changes' : 'Create ticket' }}
        </button>
        <RouterLink :to="isEdit ? `/tickets/${id}` : '/tickets'" class="button">Cancel</RouterLink>
      </div>
    </form>
  </main>
</template>
