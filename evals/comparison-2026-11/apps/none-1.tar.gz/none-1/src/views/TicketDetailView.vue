<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { RouterLink } from 'vue-router'
import { api } from '@/api'
import { ApiError } from '@/api/client'
import type { Comment, Ticket } from '@/api/types'
import StatusBadge from '@/components/StatusBadge.vue'
import { useUsersStore } from '@/stores/users'
import { formatDateTime } from '@/lib/format'
import { useCloseTicket } from '@/lib/useCloseTicket'
import { validateComment } from '@/lib/validation'

const props = defineProps<{ id: string }>()
const users = useUsersStore()
const { closing, error: closeError, close } = useCloseTicket()

const ticket = ref<Ticket | null>(null)
const comments = ref<Comment[]>([])
const loading = ref(true)
const error = ref('')
const notFound = ref(false)

const body = ref('')
const commentError = ref('')
const posting = ref(false)

const isClosing = computed(() => closing.value.includes(props.id))

let requestId = 0
async function load() {
  const rid = ++requestId
  loading.value = true
  error.value = ''
  notFound.value = false
  ticket.value = null
  comments.value = []
  try {
    const [t, c] = await Promise.all([
      api.getTicket(props.id),
      api.listComments(props.id),
      users.load(),
    ])
    if (rid !== requestId) return
    ticket.value = t
    comments.value = c
  } catch (e) {
    if (rid !== requestId) return
    if (e instanceof ApiError && e.status === 404) notFound.value = true
    else error.value = e instanceof Error ? e.message : 'Failed to load ticket'
  } finally {
    if (rid === requestId) loading.value = false
  }
}
watch(() => props.id, load, { immediate: true })

async function addComment() {
  commentError.value = validateComment(body.value) ?? ''
  if (commentError.value) return
  posting.value = true
  try {
    const c = await api.addComment(props.id, body.value.trim())
    comments.value.push(c)
    body.value = ''
  } catch (e) {
    commentError.value =
      e instanceof ApiError ? (e.fieldErrors.body ?? e.message) : 'Failed to add comment'
  } finally {
    posting.value = false
  }
}
</script>

<template>
  <main>
    <p><RouterLink to="/tickets">← All tickets</RouterLink></p>
    <p v-if="loading" class="state">Loading ticket…</p>
    <p v-else-if="notFound" class="state">Ticket not found.</p>
    <p v-else-if="error" class="state error" role="alert">
      {{ error }} <button type="button" @click="load">Retry</button>
    </p>
    <template v-else-if="ticket">
      <h1>{{ ticket.title }}</h1>
      <div class="card">
        <dl>
          <dt>Status</dt>
          <dd><StatusBadge :status="ticket.status" /></dd>
          <dt>Priority</dt>
          <dd>{{ ticket.priority }}</dd>
          <dt>Assignee</dt>
          <dd>{{ users.nameOf(ticket.assigneeId) }}</dd>
          <dt>Created</dt>
          <dd>{{ formatDateTime(ticket.createdAt) }}</dd>
          <dt>Updated</dt>
          <dd>{{ formatDateTime(ticket.updatedAt) }}</dd>
          <dt>Description</dt>
          <dd class="pre">{{ ticket.description }}</dd>
        </dl>
      </div>
      <div class="actions">
        <RouterLink :to="{ name: 'ticket-edit', params: { id: ticket.id } }" class="button">
          Edit
        </RouterLink>
        <button
          v-if="ticket.status !== 'closed'"
          type="button"
          :disabled="isClosing"
          @click="close(ticket)"
        >
          Close ticket
        </button>
      </div>
      <p v-if="closeError" class="error" role="alert">{{ closeError }}</p>

      <h2>Comments ({{ comments.length }})</h2>
      <p v-if="comments.length === 0" class="muted">No comments yet.</p>
      <ul v-else class="comments">
        <li v-for="c in comments" :key="c.id">
          <strong>{{ users.nameOf(c.authorId) }}</strong>
          <span class="muted"> · {{ formatDateTime(c.createdAt) }}</span>
          <div class="pre">{{ c.body }}</div>
        </li>
      </ul>

      <form novalidate @submit.prevent="addComment">
        <label>
          Add a comment
          <textarea v-model="body" rows="3" :aria-invalid="!!commentError"></textarea>
        </label>
        <p v-if="commentError" class="error" role="alert">{{ commentError }}</p>
        <div>
          <button type="submit" class="primary" :disabled="posting">
            {{ posting ? 'Posting…' : 'Add comment' }}
          </button>
        </div>
      </form>
    </template>
  </main>
</template>
