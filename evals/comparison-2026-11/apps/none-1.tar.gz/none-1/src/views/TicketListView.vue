<script setup lang="ts">
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { RouterLink, useRoute, useRouter } from 'vue-router'
import { api } from '@/api'
import { STATUSES, STATUS_LABELS, type Status, type Ticket } from '@/api/types'
import { UNASSIGNED, buildListQuery, parseListQuery, type ListFilters } from '@/lib/ticketQuery'
import StatusBadge from '@/components/StatusBadge.vue'
import { useUsersStore } from '@/stores/users'
import { formatDate, pageCount } from '@/lib/format'
import { useCloseTicket } from '@/lib/useCloseTicket'

const PAGE_SIZE = 10
const route = useRoute()
const router = useRouter()
const users = useUsersStore()
const { closing, error: closeError, close } = useCloseTicket()

const filters = computed(() => parseListQuery(route.query))
const q = computed(() => filters.value.q)
const status = computed(() => filters.value.status)
const assignee = computed(() => filters.value.assignee)
const page = computed(() => filters.value.page)

const searchText = ref(q.value)
const tickets = ref<Ticket[]>([])
const total = ref(0)
const loading = ref(false)
const error = ref('')
const pages = computed(() => pageCount(total.value, PAGE_SIZE))

function setQuery(patch: Partial<ListFilters>, replace = false) {
  const query = buildListQuery({ ...filters.value, ...patch })
  void (replace ? router.replace({ query }) : router.push({ query }))
}

let debounce: ReturnType<typeof setTimeout> | undefined
function onSearchInput() {
  clearTimeout(debounce)
  debounce = setTimeout(() => setQuery({ q: searchText.value.trim(), page: 1 }), 300)
}
onBeforeUnmount(() => clearTimeout(debounce))

let requestId = 0
async function load() {
  const id = ++requestId
  loading.value = true
  error.value = ''
  try {
    const res = await api.listTickets({
      q: q.value,
      status: status.value,
      assigneeId: assignee.value,
      page: page.value,
      pageSize: PAGE_SIZE,
    })
    if (id !== requestId) return // a newer request superseded this one
    tickets.value = res.items
    total.value = res.total
    // page past the end (e.g. after filtering): jump to the last page
    if (res.items.length === 0 && res.total > 0 && page.value > 1) {
      setQuery({ page: pageCount(res.total, PAGE_SIZE) }, true)
    }
  } catch (e) {
    if (id !== requestId) return
    error.value = e instanceof Error ? e.message : 'Failed to load tickets'
  } finally {
    if (id === requestId) loading.value = false
  }
}

watch(
  [q, status, assignee, page],
  () => {
    clearTimeout(debounce)
    searchText.value = q.value
    void load()
  },
  { immediate: true },
)
void users.load().catch(() => {
  // names fall back to "Unknown user"; ticket loading shows its own errors
})
</script>

<template>
  <main>
    <div class="toolbar">
      <h1>Tickets</h1>
      <RouterLink to="/tickets/new" class="button primary">New ticket</RouterLink>
    </div>

    <div class="toolbar">
      <input
        v-model="searchText"
        type="search"
        placeholder="Search tickets…"
        aria-label="Search tickets"
        @input="onSearchInput"
      />
      <select
        :value="status"
        aria-label="Filter by status"
        @change="
          setQuery({ status: ($event.target as HTMLSelectElement).value as Status | '', page: 1 })
        "
      >
        <option value="">All statuses</option>
        <option v-for="s in STATUSES" :key="s" :value="s">{{ STATUS_LABELS[s] }}</option>
      </select>
      <select
        :value="assignee"
        aria-label="Filter by assignee"
        @change="setQuery({ assignee: ($event.target as HTMLSelectElement).value, page: 1 })"
      >
        <option value="">All assignees</option>
        <option :value="UNASSIGNED">Unassigned</option>
        <option v-for="u in users.users" :key="u.id" :value="u.id">{{ u.name }}</option>
      </select>
    </div>

    <p v-if="closeError" class="error" role="alert">{{ closeError }}</p>

    <p v-if="error" class="state error" role="alert">
      {{ error }} <button type="button" @click="load">Retry</button>
    </p>
    <p v-else-if="loading && tickets.length === 0" class="state">Loading tickets…</p>
    <p v-else-if="tickets.length === 0" class="state">No tickets match your filters.</p>
    <template v-else>
      <table :aria-busy="loading">
        <thead>
          <tr>
            <th>Title</th>
            <th>Status</th>
            <th>Priority</th>
            <th>Assignee</th>
            <th>Created</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="t in tickets" :key="t.id">
            <td>
              <RouterLink :to="{ name: 'ticket', params: { id: t.id } }">{{ t.title }}</RouterLink>
            </td>
            <td><StatusBadge :status="t.status" /></td>
            <td>{{ t.priority }}</td>
            <td>{{ users.nameOf(t.assigneeId) }}</td>
            <td>{{ formatDate(t.createdAt) }}</td>
            <td>
              <button
                v-if="t.status !== 'closed'"
                type="button"
                :disabled="closing.includes(t.id)"
                @click="close(t)"
              >
                Close ticket
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="pager">
        <button
          type="button"
          :disabled="page <= 1 || loading"
          @click="setQuery({ page: page - 1 })"
        >
          Previous
        </button>
        <span>Page {{ page }} of {{ pages }} ({{ total }} tickets)</span>
        <button
          type="button"
          :disabled="page >= pages || loading"
          @click="setQuery({ page: page + 1 })"
        >
          Next
        </button>
      </div>
    </template>
  </main>
</template>
