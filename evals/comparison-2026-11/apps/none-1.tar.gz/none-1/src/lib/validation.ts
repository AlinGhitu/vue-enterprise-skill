import { PRIORITIES } from '@/api/types'

export type FieldErrors = Partial<Record<string, string>>

/** Mirrors the API rules: title 5-120 chars, description >= 10 chars (both trimmed). */
export function validateTicket(input: {
  title: string
  description: string
  priority: string
}): FieldErrors {
  const errors: FieldErrors = {}
  const title = input.title.trim()
  if (title.length < 5 || input.title.length > 120) errors.title = 'Title must be 5-120 characters'
  if (input.description.trim().length < 10)
    errors.description = 'Description must be at least 10 characters'
  if (!(PRIORITIES as string[]).includes(input.priority)) errors.priority = 'Unknown priority'
  return errors
}

export function validateComment(body: string): string | null {
  return body.trim() ? null : 'Comment cannot be empty'
}
