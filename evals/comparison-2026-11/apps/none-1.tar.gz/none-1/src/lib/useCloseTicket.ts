import { ref } from 'vue'
import { api } from '@/api'
import type { Ticket } from '@/api/types'
import { closeOptimistically } from './optimistic'

/** Shared "Close ticket" behaviour for the list and detail pages. */
export function useCloseTicket() {
  const closing = ref<string[]>([])
  const error = ref('')

  async function close(ticket: Ticket) {
    if (ticket.status === 'closed' || closing.value.includes(ticket.id)) return
    error.value = ''
    closing.value.push(ticket.id)
    try {
      await closeOptimistically(ticket, () => api.updateTicket(ticket.id, { status: 'closed' }))
    } catch (e) {
      error.value = `Could not close ticket #${ticket.id}: ${e instanceof Error ? e.message : 'unknown error'}`
    } finally {
      closing.value = closing.value.filter((id) => id !== ticket.id)
    }
  }

  return { closing, error, close }
}
