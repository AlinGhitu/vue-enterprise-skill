import { STATUSES, type Status } from '@/api/types'

export const UNASSIGNED = 'none'

export interface ListFilters {
  q: string
  status: Status | ''
  /** A user id, `'none'` (unassigned) or `''` (anyone). */
  assignee: string
  page: number
}

function first(v: unknown): unknown {
  return Array.isArray(v) ? v[0] : v
}

/** Reads list filters from a route query, ignoring invalid values. */
export function parseListQuery(query: Record<string, unknown>): ListFilters {
  const q = first(query.q)
  const s = first(query.status)
  const a = first(query.assignee)
  const n = Number(first(query.page))
  return {
    q: typeof q === 'string' ? q : '',
    status: STATUSES.includes(s as Status) ? (s as Status) : '',
    assignee: typeof a === 'string' ? a : '',
    page: Number.isInteger(n) && n >= 1 ? n : 1,
  }
}

/** Builds a route query, omitting defaults so URLs stay short. */
export function buildListQuery(f: ListFilters): Record<string, string | undefined> {
  return {
    q: f.q || undefined,
    status: f.status || undefined,
    assignee: f.assignee || undefined,
    page: f.page > 1 ? String(f.page) : undefined,
  }
}
