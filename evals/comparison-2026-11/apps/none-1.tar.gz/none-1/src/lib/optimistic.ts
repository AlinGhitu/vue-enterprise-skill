import type { Ticket } from '@/api/types'

/**
 * Optimistically close a ticket: mutate `ticket` right away, run `send`, and
 * restore the previous values if it fails (the error is rethrown).
 * On success the server's copy is merged in.
 */
export async function closeOptimistically(
  ticket: Ticket,
  send: () => Promise<Ticket>,
): Promise<void> {
  const previous = { status: ticket.status, updatedAt: ticket.updatedAt }
  ticket.status = 'closed'
  try {
    Object.assign(ticket, await send())
  } catch (e) {
    ticket.status = previous.status
    ticket.updatedAt = previous.updatedAt
    throw e
  }
}
