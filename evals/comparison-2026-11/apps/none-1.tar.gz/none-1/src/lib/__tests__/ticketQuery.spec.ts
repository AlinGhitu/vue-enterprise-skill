import { describe, it, expect } from 'vitest'
import { buildListQuery, parseListQuery } from '../ticketQuery'

describe('parseListQuery', () => {
  it('defaults when empty', () => {
    expect(parseListQuery({})).toEqual({ q: '', status: '', assignee: '', page: 1 })
  })
  it('reads valid values', () => {
    expect(parseListQuery({ q: 'x', status: 'open', assignee: 'none', page: '3' })).toEqual({
      q: 'x',
      status: 'open',
      assignee: 'none',
      page: 3,
    })
  })
  it('ignores invalid values and takes the first of repeats', () => {
    expect(parseListQuery({ status: 'bogus', page: '0', q: ['a', 'b'] })).toEqual({
      q: 'a',
      status: '',
      assignee: '',
      page: 1,
    })
    expect(parseListQuery({ page: '1.5' }).page).toBe(1)
  })
})

describe('buildListQuery', () => {
  it('omits defaults', () => {
    expect(buildListQuery({ q: '', status: '', assignee: '', page: 1 })).toEqual({
      q: undefined,
      status: undefined,
      assignee: undefined,
      page: undefined,
    })
  })
  it('round-trips', () => {
    const f = { q: 'a b', status: 'closed', assignee: 'u2', page: 2 } as const
    expect(parseListQuery(buildListQuery(f))).toEqual(f)
  })
})
