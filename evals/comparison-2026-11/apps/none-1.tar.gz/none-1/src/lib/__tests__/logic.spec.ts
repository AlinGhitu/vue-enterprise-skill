import { describe, it, expect, vi } from 'vitest'
import type { Ticket } from '@/api/types'
import { validateTicket, validateComment } from '../validation'
import { closeOptimistically } from '../optimistic'
import { pageCount } from '../format'

const valid = { title: 'Hello world', description: 'A long enough description', priority: 'low' }

describe('validateTicket', () => {
  it('accepts valid input', () => {
    expect(validateTicket(valid)).toEqual({})
  })
  it('enforces title 5-120 chars (trimmed lower bound)', () => {
    expect(validateTicket({ ...valid, title: 'abcd' }).title).toBeTruthy()
    expect(validateTicket({ ...valid, title: '  ab  ' }).title).toBeTruthy()
    expect(validateTicket({ ...valid, title: 'abcde' }).title).toBeUndefined()
    expect(validateTicket({ ...valid, title: 'a'.repeat(120) }).title).toBeUndefined()
    expect(validateTicket({ ...valid, title: 'a'.repeat(121) }).title).toBeTruthy()
  })
  it('enforces description min 10 chars', () => {
    expect(validateTicket({ ...valid, description: '123456789' }).description).toBeTruthy()
    expect(validateTicket({ ...valid, description: '1234567890' }).description).toBeUndefined()
    expect(validateTicket({ ...valid, description: '   short   ' }).description).toBeTruthy()
  })
  it('rejects unknown priority', () => {
    expect(validateTicket({ ...valid, priority: 'urgent' }).priority).toBeTruthy()
  })
})

describe('validateComment', () => {
  it('rejects blank, accepts text', () => {
    expect(validateComment('   ')).toBeTruthy()
    expect(validateComment('hi')).toBeNull()
  })
})

describe('pageCount', () => {
  it('is at least 1 and rounds up', () => {
    expect(pageCount(0, 10)).toBe(1)
    expect(pageCount(10, 10)).toBe(1)
    expect(pageCount(57, 10)).toBe(6)
  })
})

describe('closeOptimistically', () => {
  const make = (): Ticket => ({
    id: '1',
    title: 'T',
    description: 'D',
    status: 'open',
    priority: 'low',
    assigneeId: null,
    createdAt: 'a',
    updatedAt: 'b',
  })

  it('updates immediately and keeps the server result', async () => {
    const t = make()
    let resolve!: (t: Ticket) => void
    const p = closeOptimistically(t, () => new Promise((r) => (resolve = r)))
    expect(t.status).toBe('closed')
    resolve({ ...t, status: 'closed', updatedAt: 'c' })
    await p
    expect(t.updatedAt).toBe('c')
  })

  it('rolls back and rethrows on failure', async () => {
    const t = make()
    const send = vi.fn<() => Promise<Ticket>>().mockRejectedValue(new Error('boom'))
    await expect(closeOptimistically(t, send)).rejects.toThrow('boom')
    expect(t.status).toBe('open')
    expect(t.updatedAt).toBe('b')
  })
})
