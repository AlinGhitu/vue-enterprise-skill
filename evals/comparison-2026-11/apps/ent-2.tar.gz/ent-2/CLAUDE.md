# CLAUDE.md

@.github/instructions/vue.instructions.md
