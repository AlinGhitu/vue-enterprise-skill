import { ApiError, isRecord, request } from '@/shared/api/http'

export interface User {
  id: string
  name: string
  email: string
}

export function parseUser(value: unknown): User {
  if (
    !isRecord(value) ||
    typeof value.id !== 'string' ||
    typeof value.name !== 'string' ||
    typeof value.email !== 'string'
  ) {
    throw new ApiError('Unexpected user payload', 500)
  }
  return { id: value.id, name: value.name, email: value.email }
}

export function parseLogin(value: unknown): { token: string; user: User } {
  if (!isRecord(value) || typeof value.token !== 'string') {
    throw new ApiError('Unexpected login payload', 500)
  }
  return { token: value.token, user: parseUser(value.user) }
}

export async function login(email: string, password: string) {
  const payload = await request('/login', {
    method: 'POST',
    body: { email, password },
    skipUnauthorizedHook: true,
  })
  return parseLogin(payload)
}

export async function logout(): Promise<void> {
  await request('/logout', { method: 'POST', skipUnauthorizedHook: true })
}
