import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { useQueryCache } from '@pinia/colada'
import * as api from './api'

/**
 * Session state. The token lives in memory only (never in web storage), so a
 * full page reload signs the user out.
 */
export const useAuthStore = defineStore('auth', () => {
  const queryCache = useQueryCache()
  const token = ref<string | null>(null)
  const user = ref<api.User | null>(null)
  const isAuthenticated = computed(() => token.value !== null)

  async function login(email: string, password: string): Promise<void> {
    const session = await api.login(email, password)
    token.value = session.token
    user.value = session.user
  }

  /** Drops the session locally and wipes cached server data. */
  function clearSession(): void {
    token.value = null
    user.value = null
    queryCache.cancelQueries()
    for (const entry of queryCache.getEntries()) queryCache.remove(entry)
  }

  async function logout(): Promise<void> {
    try {
      await api.logout()
    } catch {
      // The session is dropped locally either way.
    }
    clearSession()
  }

  return { token, user, isAuthenticated, login, logout, clearSession }
})
