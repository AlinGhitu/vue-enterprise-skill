<script setup lang="ts">
import { ref, useId } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ApiError } from '@/shared/api/http'
import { safeRedirect } from '@/shared/lib/safeRedirect'
import { useAuthStore } from './useAuthStore'

const auth = useAuthStore()
const route = useRoute()
const router = useRouter()

const emailId = useId()
const passwordId = useId()
const email = ref('')
const password = ref('')
const submitting = ref(false)
const error = ref<string | null>(null)

async function submit() {
  if (submitting.value) return
  submitting.value = true
  error.value = null
  try {
    await auth.login(email.value.trim(), password.value)
    await router.replace(safeRedirect(route.query.redirect))
  } catch (e) {
    error.value =
      e instanceof ApiError && e.status === 401
        ? 'Invalid email or password.'
        : 'Could not sign in. Please try again.'
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <main class="login">
    <h1>Sign in</h1>
    <form novalidate @submit.prevent="submit">
      <p v-if="error" class="error" role="alert">{{ error }}</p>
      <div class="field">
        <label :for="emailId">Email</label>
        <input
          :id="emailId"
          v-model="email"
          type="email"
          name="email"
          autocomplete="username"
          required
        />
      </div>
      <div class="field">
        <label :for="passwordId">Password</label>
        <input
          :id="passwordId"
          v-model="password"
          type="password"
          name="password"
          autocomplete="current-password"
          required
        />
      </div>
      <button type="submit" :disabled="submitting">
        {{ submitting ? 'Signing in…' : 'Sign in' }}
      </button>
    </form>
  </main>
</template>

<style scoped>
.login {
  max-width: 24rem;
  margin: 3rem auto;
}
.field {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  margin-bottom: 1rem;
}
.error {
  color: #b00020;
}
</style>
