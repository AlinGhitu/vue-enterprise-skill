import type { Ticket, TicketPage } from './model'

/** Pure helpers for optimistic updates; they never mutate their input. */

export function withTicketClosed(ticket: Ticket): Ticket {
  return { ...ticket, status: 'closed' }
}

/** Replaces the ticket with `id` in a list page; returns the same page if absent. */
export function mapTicketInPage(
  page: TicketPage | undefined,
  id: string,
  fn: (ticket: Ticket) => Ticket,
): TicketPage | undefined {
  if (!page || !page.items.some((t) => t.id === id)) return page
  return { ...page, items: page.items.map((t) => (t.id === id ? fn(t) : t)) }
}

/**
 * Rolls a ticket back to `previous`, but only if the cache still holds our
 * optimistic value (status closed). A newer refetch or edit is left alone.
 */
export function rollbackTicket(current: Ticket | undefined, previous: Ticket): Ticket | undefined {
  if (!current || current.status !== 'closed') return current
  return previous
}
