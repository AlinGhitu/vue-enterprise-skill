import { defineQueryOptions } from '@pinia/colada'
import * as api from './api'

export const TICKET_KEYS = {
  root: ['tickets'] as const,
  lists: ['tickets', 'list'] as const,
  list: (params: api.TicketListParams) => ['tickets', 'list', params] as const,
  byId: (id: string) => ['tickets', 'detail', id] as const,
  comments: (id: string) => ['tickets', 'detail', id, 'comments'] as const,
}

export const USERS_KEY = ['users'] as const

export const ticketListQuery = defineQueryOptions((params: api.TicketListParams) => ({
  key: TICKET_KEYS.list(params),
  query: ({ signal }) => api.listTickets(params, signal),
}))

export const ticketQuery = defineQueryOptions((id: string) => ({
  key: TICKET_KEYS.byId(id),
  query: ({ signal }) => api.getTicket(id, signal),
}))

export const commentsQuery = defineQueryOptions((id: string) => ({
  key: TICKET_KEYS.comments(id),
  query: ({ signal }) => api.listComments(id, signal),
}))

export const usersQuery = {
  key: USERS_KEY,
  query: ({ signal }: { signal: AbortSignal }) => api.listUsers(signal),
  staleTime: 60_000,
}
