<script setup lang="ts">
import { computed, ref, useId, watch } from 'vue'
import { RouterLink, useRoute, useRouter } from 'vue-router'
import { useQuery } from '@pinia/colada'
import StateMessage from '@/shared/ui/StateMessage.vue'
import { formatDate } from '@/shared/lib/formatDate'
import CloseTicketButton from './CloseTicketButton.vue'
import TicketStatusBadge from './TicketStatusBadge.vue'
import { PAGE_SIZE, type TicketListParams } from './api'
import { UNASSIGNED, parseListQuery, toListQuery } from './listParams'
import { PRIORITY_LABELS, STATUSES, STATUS_LABELS, isStatus } from './model'
import { ticketListQuery } from './queries'
import { useUsers } from './useUsers'

const route = useRoute()
const router = useRouter()
const searchId = useId()
const statusId = useId()
const assigneeFilterId = useId()

// The URL is the source of truth for filters, so links, reloads and Back/Forward keep them.
const params = computed(() => parseListQuery(route.query))

const searchText = ref(params.value.q)
watch(
  () => params.value.q,
  (q) => {
    searchText.value = q
  },
)

const { state, asyncStatus, refetch } = useQuery(() => ({
  ...ticketListQuery(params.value),
  placeholderData: (previous) => previous,
}))
const { users, userName } = useUsers()

const totalPages = computed(() =>
  state.value.data ? Math.max(1, Math.ceil(state.value.data.total / PAGE_SIZE)) : 1,
)

function navigate(next: Partial<TicketListParams>) {
  void router.push({ query: toListQuery({ ...params.value, ...next }) })
}

function applySearch() {
  navigate({ q: searchText.value.trim(), page: 1 })
}

function onStatusChange(event: Event) {
  if (!(event.target instanceof HTMLSelectElement)) return
  const value = event.target.value
  if (value === '' || isStatus(value)) navigate({ status: value, page: 1 })
}

function onAssigneeChange(event: Event) {
  if (event.target instanceof HTMLSelectElement) navigate({ assigneeId: event.target.value, page: 1 })
}
</script>

<template>
  <main>
    <header class="head">
      <h1>Tickets</h1>
      <RouterLink :to="{ name: 'ticket-new' }">New ticket</RouterLink>
    </header>

    <form class="filters" role="search" @submit.prevent="applySearch">
      <div class="field">
        <label :for="searchId">Search</label>
        <input :id="searchId" v-model="searchText" type="search" name="q" />
      </div>
      <button type="submit">Search</button>
      <div class="field">
        <label :for="statusId">Status</label>
        <select :id="statusId" :value="params.status" @change="onStatusChange">
          <option value="">All</option>
          <option v-for="s in STATUSES" :key="s" :value="s">{{ STATUS_LABELS[s] }}</option>
        </select>
      </div>
      <div class="field">
        <label :for="assigneeFilterId">Assignee</label>
        <select :id="assigneeFilterId" :value="params.assigneeId" @change="onAssigneeChange">
          <option value="">Anyone</option>
          <option :value="UNASSIGNED">Unassigned</option>
          <option v-for="u in users" :key="u.id" :value="u.id">{{ u.name }}</option>
        </select>
      </div>
    </form>

    <StateMessage v-if="state.status === 'pending'" kind="loading" message="Loading tickets…" />

    <template v-else>
      <StateMessage
        v-if="state.status === 'error'"
        kind="error"
        message="Could not load tickets."
      >
        <button type="button" @click="refetch()">Retry</button>
      </StateMessage>

      <template v-if="state.data">
        <StateMessage
          v-if="state.data.items.length === 0"
          kind="empty"
          message="No tickets match your filters."
        />
        <table v-else :aria-busy="asyncStatus === 'loading'">
          <caption class="sr-only">
            Tickets
          </caption>
          <thead>
            <tr>
              <th scope="col">Title</th>
              <th scope="col">Status</th>
              <th scope="col">Priority</th>
              <th scope="col">Assignee</th>
              <th scope="col">Created</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="t in state.data.items" :key="t.id">
              <td>
                <RouterLink :to="{ name: 'ticket-detail', params: { id: t.id } }">
                  {{ t.title }}
                </RouterLink>
              </td>
              <td><TicketStatusBadge :status="t.status" /></td>
              <td>{{ PRIORITY_LABELS[t.priority] }}</td>
              <td>{{ userName(t.assigneeId) }}</td>
              <td>{{ formatDate(t.createdAt) }}</td>
              <td><CloseTicketButton :ticket="t" /></td>
            </tr>
          </tbody>
        </table>

        <nav v-if="state.data.total > 0" class="pager" aria-label="Pagination">
          <button type="button" :disabled="params.page <= 1" @click="navigate({ page: params.page - 1 })">
            Previous
          </button>
          <span>Page {{ params.page }} of {{ totalPages }} ({{ state.data.total }} tickets)</span>
          <button
            type="button"
            :disabled="params.page >= totalPages"
            @click="navigate({ page: params.page + 1 })"
          >
            Next
          </button>
        </nav>
      </template>
    </template>
  </main>
</template>

<style scoped>
.head {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.filters {
  display: flex;
  align-items: flex-end;
  gap: 1rem;
  margin: 1rem 0;
}
.field {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
table {
  width: 100%;
  border-collapse: collapse;
}
th,
td {
  text-align: left;
  padding: 0.4rem;
  border-bottom: 1px solid var(--color-border);
}
.pager {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 1rem;
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
}
</style>
