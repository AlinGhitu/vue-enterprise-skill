import { describe, expect, it } from 'vitest'
import { toTicketInput, validateComment, validateTicketForm, type TicketFormValues } from '../validation'

const valid: TicketFormValues = {
  title: 'Cannot log in',
  description: 'Steps are in the notes.',
  priority: 'high',
  status: 'open',
  assigneeId: '',
}

describe('validateTicketForm', () => {
  it('accepts valid values', () => {
    expect(validateTicketForm(valid, { requireStatus: true })).toEqual({})
  })

  it('enforces title length 5-120 on trimmed minimum', () => {
    expect(validateTicketForm({ ...valid, title: ' abcd ' }, { requireStatus: false }).title).toBeDefined()
    expect(validateTicketForm({ ...valid, title: 'abcde' }, { requireStatus: false }).title).toBeUndefined()
    expect(validateTicketForm({ ...valid, title: 'a'.repeat(120) }, { requireStatus: false }).title).toBeUndefined()
    expect(validateTicketForm({ ...valid, title: 'a'.repeat(121) }, { requireStatus: false }).title).toBeDefined()
  })

  it('requires a description of at least 10 characters', () => {
    expect(validateTicketForm({ ...valid, description: '123456789' }, { requireStatus: false }).description).toBeDefined()
    expect(validateTicketForm({ ...valid, description: '1234567890' }, { requireStatus: false }).description).toBeUndefined()
    expect(validateTicketForm({ ...valid, description: '   short   ' }, { requireStatus: false }).description).toBeDefined()
  })

  it('rejects unknown priority and status', () => {
    const errors = validateTicketForm({ ...valid, priority: 'urgent', status: 'x' }, { requireStatus: true })
    expect(errors.priority).toBeDefined()
    expect(errors.status).toBeDefined()
  })
})

describe('toTicketInput', () => {
  it('trims text and maps empty assignee to null', () => {
    expect(toTicketInput({ ...valid, title: '  Cannot log in  ' })).toEqual({
      title: 'Cannot log in',
      description: 'Steps are in the notes.',
      priority: 'high',
      status: 'open',
      assigneeId: null,
    })
  })

  it('returns null for an invalid priority', () => {
    expect(toTicketInput({ ...valid, priority: 'nope' })).toBeNull()
  })
})

describe('validateComment', () => {
  it('rejects blank comments', () => {
    expect(validateComment('   ')).toBeDefined()
    expect(validateComment('ok')).toBeUndefined()
  })
})
