import { afterEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { PiniaColada } from '@pinia/colada'
import { createMemoryHistory, createRouter } from 'vue-router'
import TicketListPage from '../TicketListPage.vue'

const users = [
  { id: 'u1', name: 'Ada', email: 'ada@example.com' },
  { id: 'u2', name: 'Bob', email: 'bob@example.com' },
]
const emptyPage = { items: [], total: 0, page: 1, pageSize: 10 }

afterEach(() => vi.unstubAllGlobals())

async function setup(url: string) {
  const fetchMock = vi.fn<(input: RequestInfo | URL) => Promise<Response>>((input) => {
    const body = String(input).includes('/users') ? users : emptyPage
    return Promise.resolve(
      new Response(JSON.stringify(body), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      }),
    )
  })
  vi.stubGlobal('fetch', fetchMock)
  const router = createRouter({
    history: createMemoryHistory(),
    routes: [
      { path: '/tickets', name: 'tickets', component: TicketListPage },
      { path: '/tickets/new', name: 'ticket-new', component: { template: '<i />' } },
    ],
  })
  await router.push(url)
  await router.isReady()
  const wrapper = mount(TicketListPage, { global: { plugins: [createPinia(), PiniaColada, router] } })
  await flushPromises()
  const ticketCalls = () =>
    fetchMock.mock.calls.map(([u]) => String(u)).filter((u) => u.includes('/tickets?'))
  return { router, wrapper, ticketCalls }
}

describe('TicketListPage URL state', () => {
  it('initialises controls and request from the URL', async () => {
    const { wrapper, ticketCalls } = await setup('/tickets?q=vpn&status=open&assigneeId=none&page=2')
    expect(wrapper.find<HTMLInputElement>('input[type=search]').element.value).toBe('vpn')
    const selects = wrapper.findAll<HTMLSelectElement>('select')
    expect(selects[0]?.element.value).toBe('open')
    expect(selects[1]?.element.value).toBe('none')
    const url = ticketCalls().slice(-1)[0] ?? ''
    expect(url).toContain('q=vpn')
    expect(url).toContain('status=open')
    expect(url).toContain('assigneeId=none')
    expect(url).toContain('page=2')
  })

  it('offers Anyone, Unassigned and each user', async () => {
    const { wrapper } = await setup('/tickets')
    const options = wrapper.findAll('select')[1]?.findAll('option').map((o) => o.text())
    expect(options).toEqual(['Anyone', 'Unassigned', 'Ada', 'Bob'])
  })

  it('writes the assignee to the URL, resets the page, and follows Back/Forward', async () => {
    const { wrapper, router, ticketCalls } = await setup('/tickets?page=3')
    await wrapper.findAll('select')[1]?.setValue('u2')
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ assigneeId: 'u2' })
    expect(ticketCalls().slice(-1)[0]).toContain('assigneeId=u2')

    router.back()
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ page: '3' })
    expect(wrapper.findAll<HTMLSelectElement>('select')[1]?.element.value).toBe('')

    router.forward()
    await flushPromises()
    expect(wrapper.findAll<HTMLSelectElement>('select')[1]?.element.value).toBe('u2')
  })

  it('writes search and status to the URL', async () => {
    const { wrapper, router } = await setup('/tickets')
    await wrapper.find('input[type=search]').setValue(' printer ')
    await wrapper.find('form').trigger('submit')
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ q: 'printer' })
    await wrapper.findAll('select')[0]?.setValue('closed')
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ q: 'printer', status: 'closed' })
  })
})
