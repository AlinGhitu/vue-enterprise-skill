import { afterEach, describe, expect, it, vi } from 'vitest'
import { defineComponent, h } from 'vue'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { PiniaColada, useQueryCache } from '@pinia/colada'
import { useCloseTicket } from '../useCloseTicket'
import { TICKET_KEYS } from '../queries'
import type { Ticket, TicketPage } from '../model'

const ticket: Ticket = {
  id: '1',
  title: 'Cannot log in',
  description: 'A long enough description',
  status: 'open',
  priority: 'low',
  assigneeId: null,
  createdAt: '2026-10-01T09:00:00.000Z',
  updatedAt: '2026-10-01T09:00:00.000Z',
}
const params = { q: '', status: '' as const, assigneeId: '', page: 1 }
const page: TicketPage = { items: [ticket], total: 1, page: 1, pageSize: 10 }

afterEach(() => vi.unstubAllGlobals())

function setup(fetchImpl: () => Promise<Response>) {
  vi.stubGlobal('fetch', vi.fn(fetchImpl))
  let api!: ReturnType<typeof useCloseTicket> & { cache: ReturnType<typeof useQueryCache> }
  const wrapper = mount(
    defineComponent({
      setup() {
        const cache = useQueryCache()
        api = { ...useCloseTicket(), cache }
        return () => h('div')
      },
    }),
    { global: { plugins: [createPinia(), PiniaColada] } },
  )
  api.cache.setQueryData(TICKET_KEYS.list(params), page)
  api.cache.setQueryData(TICKET_KEYS.byId('1'), ticket)
  return { api, wrapper }
}

const listStatus = (api: { cache: ReturnType<typeof useQueryCache> }) =>
  api.cache.getQueryData<TicketPage>(TICKET_KEYS.list(params))?.items[0]?.status
const detailStatus = (api: { cache: ReturnType<typeof useQueryCache> }) =>
  api.cache.getQueryData<Ticket>(TICKET_KEYS.byId('1'))?.status

describe('useCloseTicket', () => {
  it('shows the ticket closed immediately, before the request finishes', async () => {
    let resolve!: (res: Response) => void
    const { api, wrapper } = setup(() => new Promise<Response>((r) => (resolve = r)))
    api.mutate(ticket)
    await flushPromises()
    expect(listStatus(api)).toBe('closed')
    expect(detailStatus(api)).toBe('closed')
    resolve(new Response(JSON.stringify({ ...ticket, status: 'closed' }), { status: 200 }))
    await flushPromises()
    wrapper.unmount()
  })

  it('rolls back list and detail when the request fails', async () => {
    const { api, wrapper } = setup(() =>
      Promise.resolve(new Response(JSON.stringify({ message: 'boom' }), { status: 500 })),
    )
    api.mutate(ticket)
    await flushPromises()
    expect(api.error.value).not.toBeNull()
    expect(listStatus(api)).toBe('open')
    expect(detailStatus(api)).toBe('open')
    wrapper.unmount()
  })
})
