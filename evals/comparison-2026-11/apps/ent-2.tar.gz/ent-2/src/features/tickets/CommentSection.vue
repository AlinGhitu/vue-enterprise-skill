<script setup lang="ts">
import { ref, useId } from 'vue'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import StateMessage from '@/shared/ui/StateMessage.vue'
import { ApiError } from '@/shared/api/http'
import { formatDate } from '@/shared/lib/formatDate'
import * as api from './api'
import { TICKET_KEYS, commentsQuery } from './queries'
import { useUsers } from './useUsers'
import { validateComment } from './validation'

const props = defineProps<{ ticketId: string }>()

const queryCache = useQueryCache()
const { state, refetch } = useQuery(() => commentsQuery(props.ticketId))
const { userName } = useUsers()

const bodyId = useId()
const body = ref('')
const clientError = ref<string | undefined>()

const { mutate, error, asyncStatus, reset } = useMutation({
  mutation: (text: string) => api.addComment(props.ticketId, text),
  onSuccess: () => {
    body.value = ''
  },
  onSettled: () => queryCache.invalidateQueries({ key: TICKET_KEYS.comments(props.ticketId) }),
})

function fieldError(): string | undefined {
  if (clientError.value) return clientError.value
  if (error.value instanceof ApiError) return error.value.fieldErrors.body
  return undefined
}

function submit() {
  if (asyncStatus.value === 'loading') return
  clientError.value = validateComment(body.value)
  if (clientError.value) return
  reset()
  mutate(body.value.trim())
}
</script>

<template>
  <section aria-labelledby="comments-heading">
    <h2 id="comments-heading">Comments</h2>

    <StateMessage v-if="state.status === 'pending'" kind="loading" message="Loading comments…" />
    <StateMessage v-else-if="state.status === 'error'" kind="error" message="Could not load comments.">
      <button type="button" @click="refetch()">Retry</button>
    </StateMessage>
    <StateMessage v-else-if="state.data.length === 0" kind="empty" message="No comments yet." />
    <ul v-else class="comments">
      <li v-for="c in state.data" :key="c.id">
        <strong>{{ userName(c.authorId) }}</strong>
        <time :datetime="c.createdAt">{{ formatDate(c.createdAt) }}</time>
        <p>{{ c.body }}</p>
      </li>
    </ul>

    <form novalidate @submit.prevent="submit">
      <p v-if="error && !fieldError()" class="error" role="alert">Could not add the comment.</p>
      <label :for="bodyId">Add a comment</label>
      <textarea
        :id="bodyId"
        v-model="body"
        rows="3"
        :aria-invalid="fieldError() ? 'true' : undefined"
        :aria-describedby="fieldError() ? `${bodyId}-err` : undefined"
      />
      <span v-if="fieldError()" :id="`${bodyId}-err`" class="error">{{ fieldError() }}</span>
      <button type="submit" :disabled="asyncStatus === 'loading'">
        {{ asyncStatus === 'loading' ? 'Posting…' : 'Post comment' }}
      </button>
    </form>
  </section>
</template>

<style scoped>
.comments {
  list-style: none;
  padding: 0;
}
.comments li {
  padding: 0.5rem 0;
  border-bottom: 1px solid var(--color-border);
}
.comments time {
  margin-left: 0.5rem;
  font-size: 0.85rem;
}
form {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  max-width: 40rem;
}
.error {
  color: #b00020;
}
</style>
