<script setup lang="ts">
import { RouterLink } from 'vue-router'
import { useQuery } from '@pinia/colada'
import StateMessage from '@/shared/ui/StateMessage.vue'
import { ApiError } from '@/shared/api/http'
import { formatDate } from '@/shared/lib/formatDate'
import CloseTicketButton from './CloseTicketButton.vue'
import CommentSection from './CommentSection.vue'
import TicketStatusBadge from './TicketStatusBadge.vue'
import { PRIORITY_LABELS } from './model'
import { ticketQuery } from './queries'
import { useUsers } from './useUsers'

const props = defineProps<{ id: string }>()

const { state, refetch } = useQuery(() => ticketQuery(props.id))
const { userName } = useUsers()
</script>

<template>
  <main>
    <p><RouterLink :to="{ name: 'tickets' }">← All tickets</RouterLink></p>

    <StateMessage v-if="state.status === 'pending'" kind="loading" message="Loading ticket…" />
    <StateMessage
      v-else-if="state.status === 'error'"
      kind="error"
      :message="
        state.error instanceof ApiError && state.error.status === 404
          ? 'Ticket not found.'
          : 'Could not load the ticket.'
      "
    >
      <button type="button" @click="refetch()">Retry</button>
    </StateMessage>

    <template v-else>
      <header class="head">
        <h1>{{ state.data.title }}</h1>
        <div class="actions">
          <RouterLink :to="{ name: 'ticket-edit', params: { id } }">Edit</RouterLink>
          <CloseTicketButton :ticket="state.data" />
        </div>
      </header>

      <dl>
        <dt>Status</dt>
        <dd><TicketStatusBadge :status="state.data.status" /></dd>
        <dt>Priority</dt>
        <dd>{{ PRIORITY_LABELS[state.data.priority] }}</dd>
        <dt>Assignee</dt>
        <dd>{{ userName(state.data.assigneeId) }}</dd>
        <dt>Created</dt>
        <dd>{{ formatDate(state.data.createdAt) }}</dd>
        <dt>Updated</dt>
        <dd>{{ formatDate(state.data.updatedAt) }}</dd>
        <dt>Description</dt>
        <dd class="description">{{ state.data.description }}</dd>
      </dl>

      <CommentSection :ticket-id="id" />
    </template>
  </main>
</template>

<style scoped>
.head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}
.actions {
  display: flex;
  align-items: center;
  gap: 1rem;
}
dt {
  font-weight: 600;
  margin-top: 0.5rem;
}
dd {
  margin-left: 0;
}
.description {
  white-space: pre-wrap;
}
</style>
