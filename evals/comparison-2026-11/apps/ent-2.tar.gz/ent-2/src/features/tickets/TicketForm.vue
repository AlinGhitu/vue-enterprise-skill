<script setup lang="ts">
import { computed, nextTick, reactive, ref, useId, useTemplateRef, watch } from 'vue'
import type { FieldErrors } from '@/shared/api/http'
import {
  PRIORITIES,
  PRIORITY_LABELS,
  STATUSES,
  STATUS_LABELS,
  type TicketUser,
} from './model'
import {
  TITLE_MAX,
  toTicketInput,
  validateTicketForm,
  type TicketFormValues,
  type TicketInput,
} from './validation'

const props = defineProps<{
  initial: TicketFormValues
  users: TicketUser[]
  submitting: boolean
  submitLabel: string
  /** Show the status select (edit only). */
  withStatus?: boolean
  /** 422 errors from the API, keyed by field. */
  serverErrors?: FieldErrors
  /** Non-field failure message. */
  formError?: string | null
}>()

const emit = defineEmits<{
  submit: [input: TicketInput]
  cancel: []
}>()

const uid = useId()
const formEl = useTemplateRef<HTMLFormElement>('form')
const draft = reactive<TicketFormValues>({ ...props.initial })
const submitted = ref(false)

const clientErrors = computed(() =>
  submitted.value ? validateTicketForm(draft, { requireStatus: !!props.withStatus }) : {},
)

function errorFor(field: keyof TicketFormValues): string | undefined {
  return clientErrors.value[field] ?? props.serverErrors?.[field]
}

async function focusFirstInvalid() {
  await nextTick()
  formEl.value?.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus()
}

watch(() => props.serverErrors, focusFirstInvalid)

function onSubmit() {
  if (props.submitting) return
  submitted.value = true
  const errors = validateTicketForm(draft, { requireStatus: !!props.withStatus })
  const input = toTicketInput(draft)
  if (Object.keys(errors).length > 0 || !input) {
    void focusFirstInvalid()
    return
  }
  emit('submit', input)
}
</script>

<template>
  <form ref="form" novalidate class="ticket-form" @submit.prevent="onSubmit">
    <p v-if="formError" class="error" role="alert">{{ formError }}</p>

    <div class="field">
      <label :for="`${uid}-title`">Title</label>
      <input
        :id="`${uid}-title`"
        v-model="draft.title"
        type="text"
        :maxlength="TITLE_MAX + 50"
        :aria-invalid="errorFor('title') ? 'true' : undefined"
        :aria-describedby="errorFor('title') ? `${uid}-title-err` : undefined"
      />
      <span v-if="errorFor('title')" :id="`${uid}-title-err`" class="error">
        {{ errorFor('title') }}
      </span>
    </div>

    <div class="field">
      <label :for="`${uid}-description`">Description</label>
      <textarea
        :id="`${uid}-description`"
        v-model="draft.description"
        rows="5"
        :aria-invalid="errorFor('description') ? 'true' : undefined"
        :aria-describedby="errorFor('description') ? `${uid}-description-err` : undefined"
      />
      <span v-if="errorFor('description')" :id="`${uid}-description-err`" class="error">
        {{ errorFor('description') }}
      </span>
    </div>

    <div class="field">
      <label :for="`${uid}-priority`">Priority</label>
      <select
        :id="`${uid}-priority`"
        v-model="draft.priority"
        :aria-invalid="errorFor('priority') ? 'true' : undefined"
        :aria-describedby="errorFor('priority') ? `${uid}-priority-err` : undefined"
      >
        <option v-for="p in PRIORITIES" :key="p" :value="p">{{ PRIORITY_LABELS[p] }}</option>
      </select>
      <span v-if="errorFor('priority')" :id="`${uid}-priority-err`" class="error">
        {{ errorFor('priority') }}
      </span>
    </div>

    <div v-if="withStatus" class="field">
      <label :for="`${uid}-status`">Status</label>
      <select
        :id="`${uid}-status`"
        v-model="draft.status"
        :aria-invalid="errorFor('status') ? 'true' : undefined"
        :aria-describedby="errorFor('status') ? `${uid}-status-err` : undefined"
      >
        <option v-for="s in STATUSES" :key="s" :value="s">{{ STATUS_LABELS[s] }}</option>
      </select>
      <span v-if="errorFor('status')" :id="`${uid}-status-err`" class="error">
        {{ errorFor('status') }}
      </span>
    </div>

    <div class="field">
      <label :for="`${uid}-assignee`">Assignee</label>
      <select
        :id="`${uid}-assignee`"
        v-model="draft.assigneeId"
        :aria-invalid="errorFor('assigneeId') ? 'true' : undefined"
        :aria-describedby="errorFor('assigneeId') ? `${uid}-assignee-err` : undefined"
      >
        <option value="">Unassigned</option>
        <option v-for="u in users" :key="u.id" :value="u.id">{{ u.name }}</option>
      </select>
      <span v-if="errorFor('assigneeId')" :id="`${uid}-assignee-err`" class="error">
        {{ errorFor('assigneeId') }}
      </span>
    </div>

    <div class="actions">
      <button type="submit" :disabled="submitting">
        {{ submitting ? 'Saving…' : submitLabel }}
      </button>
      <button type="button" @click="emit('cancel')">Cancel</button>
    </div>
  </form>
</template>

<style scoped>
.ticket-form {
  max-width: 40rem;
}
.field {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  margin-bottom: 1rem;
}
.error {
  color: #b00020;
}
.actions {
  display: flex;
  gap: 0.5rem;
}
</style>
