import { describe, expect, it } from 'vitest'
import { parseListQuery, toListQuery } from '../listParams'

describe('parseListQuery', () => {
  it('returns defaults for an empty query', () => {
    expect(parseListQuery({})).toEqual({ q: '', status: '', assigneeId: '', page: 1 })
  })

  it('reads every filter', () => {
    expect(
      parseListQuery({ q: ' login ', status: 'open', assigneeId: 'none', page: '3' }),
    ).toEqual({ q: 'login', status: 'open', assigneeId: 'none', page: 3 })
  })

  it('falls back on invalid values and uses the first of repeated keys', () => {
    expect(
      parseListQuery({ status: 'bogus', page: ['-2', '4'], assigneeId: ['u1', 'u2'] }),
    ).toEqual({ q: '', status: '', assigneeId: 'u1', page: 1 })
    expect(parseListQuery({ page: 'abc' }).page).toBe(1)
  })
})

describe('toListQuery', () => {
  it('omits defaults', () => {
    expect(toListQuery({ q: '', status: '', assigneeId: '', page: 1 })).toEqual({
      q: undefined,
      status: undefined,
      assigneeId: undefined,
      page: undefined,
    })
  })

  it('round-trips through parseListQuery', () => {
    const params = { q: 'vpn', status: 'closed' as const, assigneeId: 'u2', page: 2 }
    expect(parseListQuery(toListQuery(params))).toEqual(params)
  })
})
