import { useMutation, useQueryCache } from '@pinia/colada'
import * as api from './api'
import { mapTicketInPage, rollbackTicket, withTicketClosed } from './cache'
import type { Ticket, TicketPage } from './model'
import { TICKET_KEYS } from './queries'

/**
 * Closes a ticket optimistically: the detail and every cached list page show
 * "closed" at once; a failed request restores the previous ticket.
 */
export function useCloseTicket() {
  const queryCache = useQueryCache()

  return useMutation({
    mutation: (ticket: Ticket) => api.updateTicket(ticket.id, { status: 'closed' }),
    onMutate(ticket) {
      queryCache.cancelQueries({ key: TICKET_KEYS.root })
      const detail = queryCache.getQueryData<Ticket>(TICKET_KEYS.byId(ticket.id))
      if (detail) queryCache.setQueryData(TICKET_KEYS.byId(ticket.id), withTicketClosed(detail))
      queryCache.setQueriesData<TicketPage | undefined>({ key: TICKET_KEYS.lists }, (page) =>
        mapTicketInPage(page, ticket.id, withTicketClosed),
      )
    },
    onError(_error, ticket) {
      const detail = queryCache.getQueryData<Ticket>(TICKET_KEYS.byId(ticket.id))
      const restored = rollbackTicket(detail, ticket)
      if (restored) queryCache.setQueryData(TICKET_KEYS.byId(ticket.id), restored)
      queryCache.setQueriesData<TicketPage | undefined>({ key: TICKET_KEYS.lists }, (page) =>
        mapTicketInPage(page, ticket.id, (current) => rollbackTicket(current, ticket) ?? current),
      )
    },
    onSettled: () => queryCache.invalidateQueries({ key: TICKET_KEYS.root }),
  })
}
