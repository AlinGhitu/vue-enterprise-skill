<script setup lang="ts">
import type { Ticket } from './model'
import { useCloseTicket } from './useCloseTicket'

const props = defineProps<{ ticket: Ticket }>()

const { mutate, error, asyncStatus } = useCloseTicket()
</script>

<template>
  <span class="close-ticket">
    <button
      v-if="ticket.status !== 'closed'"
      type="button"
      :disabled="asyncStatus === 'loading'"
      :aria-label="`Close ticket: ${props.ticket.title}`"
      @click="mutate(props.ticket)"
    >
      Close ticket
    </button>
    <span v-if="error" class="error" role="alert">
      Could not close the ticket. It was restored.
    </span>
  </span>
</template>

<style scoped>
.error {
  color: #b00020;
  margin-left: 0.5rem;
}
</style>
