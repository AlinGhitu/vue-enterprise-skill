import { describe, expect, it } from 'vitest'
import { mount } from '@vue/test-utils'
import TicketForm from '../TicketForm.vue'

const initial = {
  title: '',
  description: '',
  priority: 'medium',
  status: 'open',
  assigneeId: '',
}

function factory(props: Record<string, unknown> = {}) {
  return mount(TicketForm, {
    props: { initial, users: [], submitting: false, submitLabel: 'Create', ...props },
    attachTo: document.body,
  })
}

describe('TicketForm', () => {
  it('shows client validation errors and does not submit invalid data', async () => {
    const wrapper = factory()
    await wrapper.find('form').trigger('submit')
    expect(wrapper.text()).toContain('Title must be 5-120 characters')
    expect(wrapper.text()).toContain('Description must be at least 10 characters')
    expect(wrapper.emitted('submit')).toBeUndefined()
    expect(wrapper.find('input[type="text"]').attributes('aria-invalid')).toBe('true')
    wrapper.unmount()
  })

  it('emits a trimmed payload when valid', async () => {
    const wrapper = factory()
    await wrapper.find('input[type="text"]').setValue('  Printer is on fire ')
    await wrapper.find('textarea').setValue('It really is on fire, please help.')
    await wrapper.find('form').trigger('submit')
    expect(wrapper.emitted('submit')?.[0]).toEqual([
      {
        title: 'Printer is on fire',
        description: 'It really is on fire, please help.',
        priority: 'medium',
        status: 'open',
        assigneeId: null,
      },
    ])
    wrapper.unmount()
  })

  it('renders API 422 errors next to their fields', () => {
    const wrapper = factory({ serverErrors: { title: 'Title must be 5-120 characters', priority: 'Unknown priority' } })
    const title = wrapper.find('input[type="text"]')
    const describedBy = title.attributes('aria-describedby')
    expect(describedBy).toBeDefined()
    expect(wrapper.find(`[id="${describedBy}"]`).text()).toBe('Title must be 5-120 characters')
    expect(wrapper.text()).toContain('Unknown priority')
    wrapper.unmount()
  })
})
