import { describe, expect, it } from 'vitest'
import { mapTicketInPage, rollbackTicket, withTicketClosed } from '../cache'
import type { Ticket, TicketPage } from '../model'

function ticket(id: string, status: Ticket['status'] = 'open'): Ticket {
  return {
    id,
    title: `Ticket ${id}`,
    description: 'A long enough description',
    status,
    priority: 'low',
    assigneeId: null,
    createdAt: '2026-10-01T09:00:00.000Z',
    updatedAt: '2026-10-01T09:00:00.000Z',
  }
}

const page: TicketPage = { items: [ticket('1'), ticket('2')], total: 2, page: 1, pageSize: 10 }

describe('mapTicketInPage', () => {
  it('updates only the matching ticket without mutating the input', () => {
    const next = mapTicketInPage(page, '2', withTicketClosed)
    expect(next?.items.map((t) => t.status)).toEqual(['open', 'closed'])
    expect(page.items[1]?.status).toBe('open')
  })

  it('returns the same page when the ticket is absent or the page is missing', () => {
    expect(mapTicketInPage(page, '9', withTicketClosed)).toBe(page)
    expect(mapTicketInPage(undefined, '1', withTicketClosed)).toBeUndefined()
  })
})

describe('rollbackTicket', () => {
  it('restores the previous ticket while the optimistic value is still cached', () => {
    const previous = ticket('1', 'in_progress')
    expect(rollbackTicket(withTicketClosed(previous), previous)).toBe(previous)
  })

  it('leaves newer data alone', () => {
    const previous = ticket('1')
    const refetched = ticket('1', 'in_progress')
    expect(rollbackTicket(refetched, previous)).toBe(refetched)
    expect(rollbackTicket(undefined, previous)).toBeUndefined()
  })
})
