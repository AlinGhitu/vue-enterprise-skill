import { ApiError, isRecord } from '@/shared/api/http'

export const STATUSES = ['open', 'in_progress', 'closed'] as const
export const PRIORITIES = ['low', 'medium', 'high'] as const

export type TicketStatus = (typeof STATUSES)[number]
export type TicketPriority = (typeof PRIORITIES)[number]

export interface Ticket {
  id: string
  title: string
  description: string
  status: TicketStatus
  priority: TicketPriority
  assigneeId: string | null
  createdAt: string
  updatedAt: string
}

export interface TicketComment {
  id: string
  ticketId: string
  authorId: string
  body: string
  createdAt: string
}

export interface TicketUser {
  id: string
  name: string
  email: string
}

export interface TicketPage {
  items: Ticket[]
  total: number
  page: number
  pageSize: number
}

export const STATUS_LABELS: Record<TicketStatus, string> = {
  open: 'Open',
  in_progress: 'In progress',
  closed: 'Closed',
}

export const PRIORITY_LABELS: Record<TicketPriority, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
}

export function isStatus(value: unknown): value is TicketStatus {
  return STATUSES.some((s) => s === value)
}

export function isPriority(value: unknown): value is TicketPriority {
  return PRIORITIES.some((p) => p === value)
}

function bad(what: string): never {
  throw new ApiError(`Unexpected ${what} payload`, 500)
}

export function parseTicket(value: unknown): Ticket {
  if (
    !isRecord(value) ||
    typeof value.id !== 'string' ||
    typeof value.title !== 'string' ||
    typeof value.description !== 'string' ||
    !isStatus(value.status) ||
    !isPriority(value.priority) ||
    !(value.assigneeId === null || typeof value.assigneeId === 'string') ||
    typeof value.createdAt !== 'string' ||
    typeof value.updatedAt !== 'string'
  ) {
    return bad('ticket')
  }
  return {
    id: value.id,
    title: value.title,
    description: value.description,
    status: value.status,
    priority: value.priority,
    assigneeId: value.assigneeId,
    createdAt: value.createdAt,
    updatedAt: value.updatedAt,
  }
}

export function parseTicketPage(value: unknown): TicketPage {
  if (
    !isRecord(value) ||
    !Array.isArray(value.items) ||
    typeof value.total !== 'number' ||
    typeof value.page !== 'number' ||
    typeof value.pageSize !== 'number'
  ) {
    return bad('ticket list')
  }
  return {
    items: value.items.map(parseTicket),
    total: value.total,
    page: value.page,
    pageSize: value.pageSize,
  }
}

export function parseComment(value: unknown): TicketComment {
  if (
    !isRecord(value) ||
    typeof value.id !== 'string' ||
    typeof value.ticketId !== 'string' ||
    typeof value.authorId !== 'string' ||
    typeof value.body !== 'string' ||
    typeof value.createdAt !== 'string'
  ) {
    return bad('comment')
  }
  return {
    id: value.id,
    ticketId: value.ticketId,
    authorId: value.authorId,
    body: value.body,
    createdAt: value.createdAt,
  }
}

export function parseComments(value: unknown): TicketComment[] {
  if (!Array.isArray(value)) return bad('comment list')
  return value.map(parseComment)
}

export function parseUsers(value: unknown): TicketUser[] {
  if (!Array.isArray(value)) return bad('user list')
  return value.map((u): TicketUser => {
    if (
      !isRecord(u) ||
      typeof u.id !== 'string' ||
      typeof u.name !== 'string' ||
      typeof u.email !== 'string'
    ) {
      return bad('user')
    }
    return { id: u.id, name: u.name, email: u.email }
  })
}
