import { computed } from 'vue'
import { useQuery } from '@pinia/colada'
import { usersQuery } from './queries'

export function useUsers() {
  const { state, ...rest } = useQuery(usersQuery)
  const users = computed(() => state.value.data ?? [])
  const nameById = computed(() => new Map(users.value.map((u) => [u.id, u.name])))

  /** Assignee name, "Unassigned" for null, "Unknown user" if the id isn't loaded. */
  function userName(id: string | null): string {
    if (id === null) return 'Unassigned'
    return nameById.value.get(id) ?? 'Unknown user'
  }

  return { state, users, userName, ...rest }
}
