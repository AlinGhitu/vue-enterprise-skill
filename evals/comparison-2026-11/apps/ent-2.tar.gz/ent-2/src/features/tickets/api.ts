import { request } from '@/shared/api/http'
import {
  parseComment,
  parseComments,
  parseTicket,
  parseTicketPage,
  parseUsers,
  type TicketStatus,
} from './model'
import type { TicketInput } from './validation'

export interface TicketListParams {
  q: string
  status: TicketStatus | ''
  /** '' = any user, 'none' = unassigned, otherwise a user id. */
  assigneeId: string
  page: number
}

export const PAGE_SIZE = 10

export async function listTickets(params: TicketListParams, signal?: AbortSignal) {
  const search = new URLSearchParams({ page: String(params.page), pageSize: String(PAGE_SIZE) })
  if (params.q) search.set('q', params.q)
  if (params.status) search.set('status', params.status)
  if (params.assigneeId) search.set('assigneeId', params.assigneeId)
  return parseTicketPage(await request(`/tickets?${search.toString()}`, { signal }))
}

export async function getTicket(id: string, signal?: AbortSignal) {
  return parseTicket(await request(`/tickets/${encodeURIComponent(id)}`, { signal }))
}

export async function createTicket(input: TicketInput) {
  const body = {
    title: input.title,
    description: input.description,
    priority: input.priority,
    assigneeId: input.assigneeId,
  }
  return parseTicket(await request('/tickets', { method: 'POST', body }))
}

export async function updateTicket(id: string, patch: Partial<TicketInput>) {
  return parseTicket(
    await request(`/tickets/${encodeURIComponent(id)}`, { method: 'PATCH', body: patch }),
  )
}

export async function listComments(id: string, signal?: AbortSignal) {
  return parseComments(await request(`/tickets/${encodeURIComponent(id)}/comments`, { signal }))
}

export async function addComment(id: string, body: string) {
  return parseComment(
    await request(`/tickets/${encodeURIComponent(id)}/comments`, {
      method: 'POST',
      body: { body },
    }),
  )
}

export async function listUsers(signal?: AbortSignal) {
  return parseUsers(await request('/users', { signal }))
}
