<script setup lang="ts">
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useMutation, useQueryCache } from '@pinia/colada'
import { ApiError } from '@/shared/api/http'
import * as api from './api'
import { TICKET_KEYS } from './queries'
import TicketForm from './TicketForm.vue'
import { useUsers } from './useUsers'
import type { TicketInput } from './validation'

const router = useRouter()
const queryCache = useQueryCache()
const { users } = useUsers()

const { mutate, error, asyncStatus } = useMutation({
  mutation: (input: TicketInput) => api.createTicket(input),
  onSettled: () => queryCache.invalidateQueries({ key: TICKET_KEYS.root }),
  onSuccess: (ticket) => router.push({ name: 'ticket-detail', params: { id: ticket.id } }),
})

const serverErrors = computed(() => (error.value instanceof ApiError ? error.value.fieldErrors : {}))
const formError = computed(() =>
  error.value && Object.keys(serverErrors.value).length === 0
    ? 'Could not create the ticket. Please try again.'
    : null,
)
</script>

<template>
  <main>
    <h1>New ticket</h1>
    <TicketForm
      :initial="{ title: '', description: '', priority: 'medium', status: 'open', assigneeId: '' }"
      :users="users"
      :submitting="asyncStatus === 'loading'"
      :server-errors="serverErrors"
      :form-error="formError"
      submit-label="Create ticket"
      @submit="mutate"
      @cancel="router.push({ name: 'tickets' })"
    />
  </main>
</template>
