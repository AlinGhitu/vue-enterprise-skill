import { isPriority, isStatus, type TicketPriority, type TicketStatus } from './model'

export const TITLE_MIN = 5
export const TITLE_MAX = 120
export const DESCRIPTION_MIN = 10

/** Raw form values; select inputs yield strings, `''` meaning "unassigned". */
export interface TicketFormValues {
  title: string
  description: string
  priority: string
  status: string
  assigneeId: string
}

export type TicketFormErrors = Partial<Record<keyof TicketFormValues, string>>

export interface TicketInput {
  title: string
  description: string
  priority: TicketPriority
  status: TicketStatus
  assigneeId: string | null
}

/** Mirrors the API rules (API.md): title 5-120 chars, description >= 10 chars (both trimmed). */
export function validateTicketForm(
  values: TicketFormValues,
  options: { requireStatus: boolean },
): TicketFormErrors {
  const errors: TicketFormErrors = {}
  const title = values.title.trim()
  if (title.length < TITLE_MIN || values.title.length > TITLE_MAX) {
    errors.title = `Title must be ${TITLE_MIN}-${TITLE_MAX} characters`
  }
  if (values.description.trim().length < DESCRIPTION_MIN) {
    errors.description = `Description must be at least ${DESCRIPTION_MIN} characters`
  }
  if (!isPriority(values.priority)) errors.priority = 'Choose a priority'
  if (options.requireStatus && !isStatus(values.status)) errors.status = 'Choose a status'
  return errors
}

/** Converts valid form values to a payload; returns null when they are invalid. */
export function toTicketInput(values: TicketFormValues): TicketInput | null {
  if (!isPriority(values.priority)) return null
  const status = isStatus(values.status) ? values.status : 'open'
  return {
    title: values.title.trim(),
    description: values.description.trim(),
    priority: values.priority,
    status,
    assigneeId: values.assigneeId === '' ? null : values.assigneeId,
  }
}

export function validateComment(body: string): string | undefined {
  return body.trim().length === 0 ? 'Comment cannot be empty' : undefined
}
