<script setup lang="ts">
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import StateMessage from '@/shared/ui/StateMessage.vue'
import { ApiError } from '@/shared/api/http'
import * as api from './api'
import { TICKET_KEYS, ticketQuery } from './queries'
import TicketForm from './TicketForm.vue'
import { useUsers } from './useUsers'
import type { TicketInput } from './validation'

const props = defineProps<{ id: string }>()

const router = useRouter()
const queryCache = useQueryCache()
const { users } = useUsers()
const { state, refetch } = useQuery(() => ticketQuery(props.id))

const { mutate, error, asyncStatus } = useMutation({
  mutation: (input: TicketInput) => api.updateTicket(props.id, input),
  onSettled: () => queryCache.invalidateQueries({ key: TICKET_KEYS.root }),
  onSuccess: () => router.push({ name: 'ticket-detail', params: { id: props.id } }),
})

const serverErrors = computed(() => (error.value instanceof ApiError ? error.value.fieldErrors : {}))
const formError = computed(() =>
  error.value && Object.keys(serverErrors.value).length === 0
    ? 'Could not save the ticket. Please try again.'
    : null,
)
</script>

<template>
  <main>
    <h1>Edit ticket</h1>
    <StateMessage v-if="state.status === 'pending'" kind="loading" message="Loading ticket…" />
    <StateMessage v-else-if="state.status === 'error'" kind="error" message="Could not load the ticket.">
      <button type="button" @click="refetch()">Retry</button>
    </StateMessage>
    <TicketForm
      v-else
      :initial="{
        title: state.data.title,
        description: state.data.description,
        priority: state.data.priority,
        status: state.data.status,
        assigneeId: state.data.assigneeId ?? '',
      }"
      :users="users"
      :submitting="asyncStatus === 'loading'"
      :server-errors="serverErrors"
      :form-error="formError"
      with-status
      submit-label="Save changes"
      @submit="mutate"
      @cancel="router.push({ name: 'ticket-detail', params: { id } })"
    />
  </main>
</template>
