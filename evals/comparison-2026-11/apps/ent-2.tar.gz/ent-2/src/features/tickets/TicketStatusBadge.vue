<script setup lang="ts">
import { STATUS_LABELS, type TicketStatus } from './model'

defineProps<{ status: TicketStatus }>()
</script>

<template>
  <span class="badge" :data-status="status">{{ STATUS_LABELS[status] }}</span>
</template>

<style scoped>
.badge {
  padding: 0.1rem 0.5rem;
  border: 1px solid currentColor;
  border-radius: 1rem;
  font-size: 0.85rem;
  white-space: nowrap;
}
.badge[data-status='closed'] {
  color: #5a5a5a;
}
.badge[data-status='open'] {
  color: #0b6b3a;
}
.badge[data-status='in_progress'] {
  color: #8a5a00;
}
</style>
