import type { TicketListParams } from './api'
import { isStatus } from './model'

export const UNASSIGNED = 'none'

type QueryValue = string | null | (string | null)[] | undefined
export type ListQuery = Record<string, QueryValue>

function firstString(value: QueryValue): string {
  const v = Array.isArray(value) ? value[0] : value
  return typeof v === 'string' ? v : ''
}

/** Parse the untrusted route query into list params; invalid values fall back to defaults. */
export function parseListQuery(query: ListQuery): TicketListParams {
  const status = firstString(query.status)
  const page = Number.parseInt(firstString(query.page), 10)
  return {
    q: firstString(query.q).trim(),
    status: isStatus(status) ? status : '',
    assigneeId: firstString(query.assigneeId).trim(),
    page: Number.isFinite(page) && page > 0 ? page : 1,
  }
}

/** Build a clean route query: defaults are omitted so URLs stay short. */
export function toListQuery(params: TicketListParams): Record<string, string | undefined> {
  return {
    q: params.q || undefined,
    status: params.status || undefined,
    assigneeId: params.assigneeId || undefined,
    page: params.page > 1 ? String(params.page) : undefined,
  }
}
