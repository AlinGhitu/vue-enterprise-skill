import { describe, expect, it } from 'vitest'
import { createMemoryHistory } from 'vue-router'
import { createPinia, setActivePinia } from 'pinia'
import { PiniaColada } from '@pinia/colada'
import { createApp } from 'vue'
import { useAuthStore } from '@/features/auth/useAuthStore'
import { createAppRouter } from '..'

/** Installs the router last: installing it starts the initial navigation. */
async function setup(options: { token: string | null }) {
  const pinia = createPinia()
  setActivePinia(pinia)
  const app = createApp({ render: () => null })
  app.use(pinia)
  app.use(PiniaColada)
  useAuthStore(pinia).token = options.token
  const router = createAppRouter(createMemoryHistory())
  app.use(router)
  await router.isReady()
  return router
}

describe('auth guard', () => {
  it('redirects anonymous users to login, remembering the wanted page', async () => {
    const router = await setup({ token: null })
    await router.push('/tickets/7?tab=1')
    expect(router.currentRoute.value.name).toBe('login')
    expect(router.currentRoute.value.query.redirect).toBe('/tickets/7?tab=1')
  })

  it('lets authenticated users through', async () => {
    const router = await setup({ token: 'tok' })
    await router.push('/tickets/7')
    expect(router.currentRoute.value.name).toBe('ticket-detail')
  })

  it('sends authenticated users away from the login page', async () => {
    const router = await setup({ token: 'tok' })
    await router.push('/login')
    expect(router.currentRoute.value.name).toBe('tickets')
  })
})
