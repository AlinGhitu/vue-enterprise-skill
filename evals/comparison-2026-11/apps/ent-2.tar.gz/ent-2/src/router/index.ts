import { createRouter, createWebHistory, type RouterHistory } from 'vue-router'
import { useAuthStore } from '@/features/auth/useAuthStore'

export function createAppRouter(history: RouterHistory = createWebHistory(import.meta.env.BASE_URL)) {
  const router = createRouter({
    history,
    routes: [
      { path: '/', redirect: { name: 'tickets' } },
      {
        path: '/login',
        name: 'login',
        component: () => import('@/features/auth/LoginPage.vue'),
        meta: { public: true },
      },
      {
        path: '/tickets',
        name: 'tickets',
        component: () => import('@/features/tickets/TicketListPage.vue'),
      },
      {
        path: '/tickets/new',
        name: 'ticket-new',
        component: () => import('@/features/tickets/TicketCreatePage.vue'),
      },
      {
        path: '/tickets/:id',
        name: 'ticket-detail',
        component: () => import('@/features/tickets/TicketDetailPage.vue'),
        props: true,
      },
      {
        path: '/tickets/:id/edit',
        name: 'ticket-edit',
        component: () => import('@/features/tickets/TicketEditPage.vue'),
        props: true,
      },
    ],
  })

  router.beforeEach((to) => {
    const auth = useAuthStore()
    if (to.meta.public) {
      return to.name === 'login' && auth.isAuthenticated ? { name: 'tickets' } : true
    }
    if (!auth.isAuthenticated) {
      return { name: 'login', query: { redirect: to.fullPath } }
    }
    return true
  })

  return router
}
