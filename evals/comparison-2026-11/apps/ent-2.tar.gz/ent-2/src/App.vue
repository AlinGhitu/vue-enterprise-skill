<script setup lang="ts">
import { RouterLink, RouterView, useRouter } from 'vue-router'
import { useAuthStore } from '@/features/auth/useAuthStore'

const auth = useAuthStore()
const router = useRouter()

async function logout() {
  await auth.logout()
  await router.push({ name: 'login' })
}
</script>

<template>
  <header v-if="auth.isAuthenticated" class="app-header">
    <RouterLink :to="{ name: 'tickets' }" class="brand">Support Desk</RouterLink>
    <div class="user">
      <span>{{ auth.user?.name }}</span>
      <button type="button" @click="logout">Log out</button>
    </div>
  </header>
  <RouterView />
</template>

<style scoped>
.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-bottom: 1rem;
  margin-bottom: 1rem;
  border-bottom: 1px solid var(--color-border);
}
.brand {
  font-weight: 700;
}
.user {
  display: flex;
  align-items: center;
  gap: 1rem;
}
</style>
