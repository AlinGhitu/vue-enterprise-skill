import './assets/main.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { PiniaColada } from '@pinia/colada'

import App from './App.vue'
import { createAppRouter } from './router'
import { configureHttp } from './shared/api/http'
import { useAuthStore } from './features/auth/useAuthStore'

const app = createApp(App)
const pinia = createPinia()
const router = createAppRouter()

app.use(pinia)
app.use(PiniaColada)
app.use(router)

// An expired session on any request sends the user to login and back.
const auth = useAuthStore(pinia)
configureHttp({
  getToken: () => auth.token,
  onUnauthorized: () => {
    if (!auth.isAuthenticated) return
    auth.clearSession()
    void router.push({ name: 'login', query: { redirect: router.currentRoute.value.fullPath } })
  },
})

app.mount('#app')
