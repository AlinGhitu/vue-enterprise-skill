import { afterEach, describe, expect, it, vi } from 'vitest'
import { ApiError, configureHttp, request } from '../http'

function respond(status: number, body?: unknown) {
  vi.stubGlobal(
    'fetch',
    vi.fn(() => Promise.resolve(new Response(body === undefined ? null : JSON.stringify(body), { status }))),
  )
}

afterEach(() => {
  vi.unstubAllGlobals()
  configureHttp({ getToken: () => null, onUnauthorized: () => {} })
})

describe('request', () => {
  it('sends the bearer token', async () => {
    configureHttp({ getToken: () => 'abc', onUnauthorized: () => {} })
    respond(200, { ok: true })
    await request('/me')
    const init = vi.mocked(fetch).mock.calls[0]?.[1]
    expect(new Headers(init?.headers).get('Authorization')).toBe('Bearer abc')
  })

  it('turns 422 into an ApiError carrying field errors', async () => {
    respond(422, { message: 'Validation failed', errors: { title: 'Too short', bad: 1 } })
    const error = await request('/tickets', { method: 'POST', body: {} }).catch((e: unknown) => e)
    expect(error).toBeInstanceOf(ApiError)
    expect((error as ApiError).status).toBe(422)
    expect((error as ApiError).fieldErrors).toEqual({ title: 'Too short' })
  })

  it('calls onUnauthorized for a 401, unless skipped', async () => {
    const onUnauthorized = vi.fn<() => void>()
    configureHttp({ getToken: () => 't', onUnauthorized })
    respond(401, { message: 'Not authenticated' })
    await expect(request('/me')).rejects.toBeInstanceOf(ApiError)
    expect(onUnauthorized).toHaveBeenCalledTimes(1)
    await expect(request('/login', { skipUnauthorizedHook: true })).rejects.toBeInstanceOf(ApiError)
    expect(onUnauthorized).toHaveBeenCalledTimes(1)
  })

  it('returns undefined for an empty 204', async () => {
    respond(204)
    await expect(request('/logout', { method: 'POST' })).resolves.toBeUndefined()
  })
})
