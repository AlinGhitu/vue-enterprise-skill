export type FieldErrors = Record<string, string>

/** Error for any non-2xx response. */
export class ApiError extends Error {
  readonly status: number
  readonly fieldErrors: FieldErrors

  constructor(message: string, status: number, fieldErrors: FieldErrors = {}) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.fieldErrors = fieldErrors
  }
}

interface HttpConfig {
  getToken: () => string | null
  onUnauthorized: () => void
}

let config: HttpConfig = { getToken: () => null, onUnauthorized: () => {} }

/** Wired once by the app layer, so `shared/` never imports a feature. */
export function configureHttp(next: HttpConfig): void {
  config = next
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

export function parseFieldErrors(value: unknown): FieldErrors {
  if (!isRecord(value)) return {}
  const out: FieldErrors = {}
  for (const [key, message] of Object.entries(value)) {
    if (typeof message === 'string') out[key] = message
  }
  return out
}

async function readJson(res: Response): Promise<unknown> {
  const text = await res.text()
  if (!text) return undefined
  try {
    return JSON.parse(text) as unknown
  } catch {
    return undefined
  }
}

export interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH'
  body?: unknown
  signal?: AbortSignal
  /** A 401 here is a normal answer (wrong password), not an expired session. */
  skipUnauthorizedHook?: boolean
}

/** Sends a JSON request, throws `ApiError` on non-2xx, returns the unparsed body. */
export async function request(path: string, options: RequestOptions = {}): Promise<unknown> {
  const headers: Record<string, string> = { Accept: 'application/json' }
  const token = config.getToken()
  if (token) headers.Authorization = `Bearer ${token}`
  if (options.body !== undefined) headers['Content-Type'] = 'application/json'

  const res = await fetch(`/api${path}`, {
    method: options.method ?? 'GET',
    headers,
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
    signal: options.signal,
  })
  const payload = await readJson(res)

  if (!res.ok) {
    if (res.status === 401 && !options.skipUnauthorizedHook) config.onUnauthorized()
    const message =
      isRecord(payload) && typeof payload.message === 'string'
        ? payload.message
        : `Request failed (${res.status})`
    throw new ApiError(
      message,
      res.status,
      isRecord(payload) ? parseFieldErrors(payload.errors) : {},
    )
  }
  return payload
}
