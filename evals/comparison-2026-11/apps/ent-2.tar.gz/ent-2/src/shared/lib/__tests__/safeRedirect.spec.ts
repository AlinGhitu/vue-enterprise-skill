import { describe, expect, it } from 'vitest'
import { safeRedirect } from '../safeRedirect'

describe('safeRedirect', () => {
  it('keeps in-app paths with query strings', () => {
    expect(safeRedirect('/tickets/3?x=1')).toBe('/tickets/3?x=1')
  })

  it.each(['https://evil.example', '//evil.example', '/\\evil', 'tickets', undefined, 42, ['/a']])(
    'falls back for %s',
    (value) => {
      expect(safeRedirect(value)).toBe('/tickets')
    },
  )

  it('never redirects back to the login page', () => {
    expect(safeRedirect('/login?redirect=/x')).toBe('/tickets')
  })
})
