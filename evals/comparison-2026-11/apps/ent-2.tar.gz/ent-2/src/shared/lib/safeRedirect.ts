/**
 * Accepts a post-login redirect target only when it is an in-app path.
 * Anything else (absolute URLs, `//host`, backslashes, non-strings) falls back.
 */
export function safeRedirect(value: unknown, fallback = '/tickets'): string {
  if (typeof value !== 'string') return fallback
  if (!value.startsWith('/') || value.startsWith('//') || value.includes('\\')) return fallback
  if (value === '/login' || value.startsWith('/login?')) return fallback
  return value
}
