<script setup lang="ts">
defineProps<{
  kind: 'loading' | 'error' | 'empty'
  message: string
}>()
</script>

<template>
  <p v-if="kind === 'error'" class="state state-error" role="alert">
    {{ message }}
    <slot />
  </p>
  <p v-else class="state" role="status">
    {{ message }}
    <slot />
  </p>
</template>

<style scoped>
.state {
  padding: 1rem 0;
}
.state-error {
  color: #b00020;
}
</style>
