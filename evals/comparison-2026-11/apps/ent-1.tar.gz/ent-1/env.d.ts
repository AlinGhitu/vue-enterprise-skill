/// <reference types="vite/client" />

import 'vue-router'

declare module 'vue-router' {
  interface RouteMeta {
    /** Routes reachable without logging in. */
    public?: boolean
  }
}
