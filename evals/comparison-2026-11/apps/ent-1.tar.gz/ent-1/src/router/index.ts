import { createRouter, createWebHistory } from 'vue-router'
import { resolveAuthRedirect } from '@/features/auth/guard'
import { useAuthStore } from '@/features/auth/useAuthStore'

export const routes = [
  {
    path: '/login',
    name: 'login',
    component: () => import('@/features/auth/pages/LoginPage.vue'),
    meta: { public: true },
  },
  { path: '/', redirect: { name: 'tickets' } },
  {
    path: '/tickets',
    name: 'tickets',
    component: () => import('@/features/tickets/pages/TicketListPage.vue'),
  },
  {
    path: '/tickets/new',
    name: 'ticket-new',
    component: () => import('@/features/tickets/pages/TicketNewPage.vue'),
  },
  {
    path: '/tickets/:id',
    name: 'ticket-detail',
    component: () => import('@/features/tickets/pages/TicketDetailPage.vue'),
  },
  {
    path: '/tickets/:id/edit',
    name: 'ticket-edit',
    component: () => import('@/features/tickets/pages/TicketEditPage.vue'),
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'not-found',
    component: () => import('@/shared/ui/NotFoundPage.vue'),
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

router.beforeEach((to) => resolveAuthRedirect(to, useAuthStore().isAuthenticated))

export default router
