import './assets/main.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { PiniaColada, useQueryCache } from '@pinia/colada'

import App from './App.vue'
import router from './router'
import { configureHttp } from './shared/api/http'
import { useAuthStore } from './features/auth/useAuthStore'

const app = createApp(App)
const pinia = createPinia()

app.use(pinia)
app.use(PiniaColada)
app.use(router)

// A 401 on any authenticated call means the session expired: clear it and ask for login.
const auth = useAuthStore(pinia)
const queryCache = useQueryCache(pinia)
configureHttp({
  getToken: () => auth.token,
  onUnauthorized: () => {
    if (!auth.isAuthenticated) return
    auth.clear()
    for (const entry of queryCache.getEntries()) {
      queryCache.cancel(entry)
      queryCache.remove(entry)
    }
    const current = router.currentRoute.value
    void router.replace({ name: 'login', query: { redirect: current.fullPath } })
  },
})

app.mount('#app')
