<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
import { useAuthStore } from '@/features/auth/useAuthStore'
import { useEndSession } from '@/app/session'

const auth = useAuthStore()
const endSession = useEndSession()
</script>

<template>
  <header v-if="auth.isAuthenticated" class="app-header">
    <nav aria-label="Main">
      <RouterLink :to="{ name: 'tickets' }">Tickets</RouterLink>
    </nav>
    <div>
      <span>{{ auth.user?.name }}</span>
      <button type="button" @click="endSession({ callServer: true, redirectBack: false })">
        Log out
      </button>
    </div>
  </header>
  <div class="app-body">
    <RouterView />
  </div>
</template>

<style scoped>
.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem 1.5rem;
  border-bottom: 1px solid var(--color-border);
}
.app-header button {
  margin-left: 0.75rem;
}
.app-body {
  padding: 1rem 1.5rem;
}
</style>
