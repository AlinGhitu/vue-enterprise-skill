import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { z } from 'zod'
import { ApiError, configureHttp, request } from '../api/http'

function respond(status: number, body?: unknown) {
  return new Response(body === undefined ? null : JSON.stringify(body), { status })
}

describe('request', () => {
  const onUnauthorized = vi.fn<() => void>()
  const fetchMock = vi.fn<typeof fetch>()

  beforeEach(() => {
    vi.stubGlobal('fetch', fetchMock)
    configureHttp({ getToken: () => 'tok', onUnauthorized })
  })
  afterEach(() => {
    vi.unstubAllGlobals()
    vi.resetAllMocks()
  })

  it('sends the bearer token and query, and parses the response', async () => {
    fetchMock.mockResolvedValue(respond(200, { n: 1 }))
    const result = await request('/api/x', z.object({ n: z.number() }), {
      query: { q: 'a b', status: '', page: 2 },
    })
    expect(result).toEqual({ n: 1 })
    const [url, init] = fetchMock.mock.calls[0] ?? []
    expect(url).toBe('/api/x?q=a+b&page=2')
    expect(new Headers(init?.headers).get('Authorization')).toBe('Bearer tok')
  })

  it('throws ApiError carrying 422 field errors', async () => {
    fetchMock.mockResolvedValue(
      respond(422, { message: 'Validation failed', errors: { title: 'Too short' } }),
    )
    const error = await request('/api/x', z.unknown()).catch((e: unknown) => e)
    expect(error).toBeInstanceOf(ApiError)
    expect(error).toMatchObject({ status: 422, fieldErrors: { title: 'Too short' } })
  })

  it('rejects data that does not match the schema', async () => {
    fetchMock.mockResolvedValue(respond(200, { n: 'nope' }))
    await expect(request('/api/x', z.object({ n: z.number() }))).rejects.toThrow(/number/i)
  })

  it('reports 401 as an expired session unless told otherwise', async () => {
    fetchMock.mockResolvedValue(respond(401, { message: 'Not authenticated' }))
    await expect(request('/api/x', z.unknown())).rejects.toBeInstanceOf(ApiError)
    expect(onUnauthorized).toHaveBeenCalledTimes(1)

    await expect(
      request('/api/login', z.unknown(), { skipUnauthorizedHandler: true }),
    ).rejects.toBeInstanceOf(ApiError)
    expect(onUnauthorized).toHaveBeenCalledTimes(1)
  })
})
