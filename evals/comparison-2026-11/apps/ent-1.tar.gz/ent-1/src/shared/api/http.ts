import { z } from 'zod'

/** Error for any non-2xx response. `fieldErrors` carries the API's 422 `errors` map. */
export class ApiError extends Error {
  readonly status: number
  readonly fieldErrors: Record<string, string>

  constructor(status: number, message: string, fieldErrors: Record<string, string> = {}) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.fieldErrors = fieldErrors
  }
}

export function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : 'Something went wrong'
}

interface HttpConfig {
  getToken: () => string | null
  onUnauthorized: () => void
}

let config: HttpConfig = { getToken: () => null, onUnauthorized: () => {} }

/** Wired once at app start so `shared/` never imports from `features/`. */
export function configureHttp(next: HttpConfig): void {
  config = next
}

const errorBodySchema = z.object({
  message: z.string().optional(),
  errors: z.record(z.string(), z.string()).optional(),
})

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH'
  body?: unknown
  query?: Record<string, string | number | undefined>
  signal?: AbortSignal
  /** A 401 here is a normal failure (wrong password), not an expired session. */
  skipUnauthorizedHandler?: boolean
}

function buildUrl(path: string, query: RequestOptions['query']): string {
  const params = new URLSearchParams()
  for (const [key, value] of Object.entries(query ?? {})) {
    if (value !== undefined && value !== '') params.set(key, String(value))
  }
  const qs = params.toString()
  return qs ? `${path}?${qs}` : path
}

/** Performs a request, throws `ApiError` on non-2xx and parses the body with `schema`. */
export async function request<T>(
  path: string,
  schema: z.ZodType<T>,
  options: RequestOptions = {},
): Promise<T> {
  const headers: Record<string, string> = {}
  const token = config.getToken()
  if (token) headers.Authorization = `Bearer ${token}`
  if (options.body !== undefined) headers['Content-Type'] = 'application/json'

  const response = await fetch(buildUrl(path, options.query), {
    method: options.method ?? 'GET',
    headers,
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
    signal: options.signal,
  })

  if (!response.ok) {
    const parsed = errorBodySchema.safeParse(await response.json().catch(() => null))
    const body = parsed.success ? parsed.data : {}
    if (response.status === 401 && !options.skipUnauthorizedHandler) config.onUnauthorized()
    throw new ApiError(
      response.status,
      body.message ?? `Request failed (${response.status})`,
      body.errors,
    )
  }

  if (response.status === 204) return schema.parse(undefined)
  return schema.parse(await response.json())
}
