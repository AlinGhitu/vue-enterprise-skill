<script setup lang="ts">
import { RouterLink } from 'vue-router'
</script>

<template>
  <section>
    <h1>Page not found</h1>
    <RouterLink to="/">Back to tickets</RouterLink>
  </section>
</template>
