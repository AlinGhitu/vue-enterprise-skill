<script setup lang="ts">
defineProps<{ kind: 'loading' | 'empty' | 'error'; message: string }>()
</script>

<template>
  <p :role="kind === 'error' ? 'alert' : 'status'" :class="['state', kind]">
    {{ message }}
    <slot />
  </p>
</template>

<style scoped>
.state {
  padding: 1rem 0;
}
.error {
  color: #b00020;
}
</style>
