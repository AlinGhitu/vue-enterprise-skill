/** Accepts only same-origin app paths, so `?redirect=` can't send users to another site. */
export function safeRedirect(value: unknown, fallback = '/tickets'): string {
  if (typeof value !== 'string') return fallback
  if (!value.startsWith('/') || value.startsWith('//') || value.includes('\\')) return fallback
  if (value === '/login' || value.startsWith('/login?')) return fallback
  return value
}
