import { describe, expect, it } from 'vitest'
import { resolveAuthRedirect } from '../guard'
import { safeRedirect } from '@/shared/lib/safeRedirect'

describe('resolveAuthRedirect', () => {
  it('redirects anonymous users to login and remembers the target', () => {
    expect(resolveAuthRedirect({ fullPath: '/tickets/5?x=1', meta: {} }, false)).toEqual({
      name: 'login',
      query: { redirect: '/tickets/5?x=1' },
    })
  })

  it('lets authenticated users and public routes through', () => {
    expect(resolveAuthRedirect({ fullPath: '/tickets', meta: {} }, true)).toBe(true)
    expect(resolveAuthRedirect({ fullPath: '/login', meta: { public: true } }, false)).toBe(true)
  })
})

describe('safeRedirect', () => {
  it('keeps same-app paths', () => {
    expect(safeRedirect('/tickets/5?page=2')).toBe('/tickets/5?page=2')
  })

  it('rejects external, protocol-relative and non-string targets', () => {
    expect(safeRedirect('https://evil.example')).toBe('/tickets')
    expect(safeRedirect('//evil.example')).toBe('/tickets')
    expect(safeRedirect('/\\evil.example')).toBe('/tickets')
    expect(safeRedirect(['/a'])).toBe('/tickets')
    expect(safeRedirect(undefined)).toBe('/tickets')
  })

  it('never redirects back to login', () => {
    expect(safeRedirect('/login?redirect=/x')).toBe('/tickets')
  })
})
