<script setup lang="ts">
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '../useAuthStore'
import { ApiError } from '@/shared/api/http'
import { safeRedirect } from '@/shared/lib/safeRedirect'

const auth = useAuthStore()
const route = useRoute()
const router = useRouter()

const email = ref('')
const password = ref('')
const submitting = ref(false)
const error = ref<string | null>(null)

async function submit() {
  if (submitting.value) return
  submitting.value = true
  error.value = null
  try {
    await auth.login(email.value.trim(), password.value)
    await router.replace(safeRedirect(route.query.redirect))
  } catch (e) {
    error.value =
      e instanceof ApiError && e.status === 401
        ? 'Invalid email or password'
        : 'Could not sign in. Please try again.'
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <main class="login">
    <h1>Support Desk</h1>
    <form @submit.prevent="submit">
      <p v-if="error" role="alert" class="error">{{ error }}</p>
      <div class="field">
        <label for="login-email">Email</label>
        <input id="login-email" v-model="email" type="email" autocomplete="username" required />
      </div>
      <div class="field">
        <label for="login-password">Password</label>
        <input
          id="login-password"
          v-model="password"
          type="password"
          autocomplete="current-password"
          required
        />
      </div>
      <button type="submit" :disabled="submitting">
        {{ submitting ? 'Signing in…' : 'Sign in' }}
      </button>
    </form>
  </main>
</template>

<style scoped>
.login {
  max-width: 24rem;
  margin: 4rem auto;
  padding: 0 1rem;
}
.field {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  margin-bottom: 1rem;
}
.error {
  color: #b00020;
}
</style>
