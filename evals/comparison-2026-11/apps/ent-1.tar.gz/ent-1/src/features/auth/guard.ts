import type { RouteLocationNormalized, RouteLocationRaw } from 'vue-router'

/** Pure guard logic: redirects anonymous users to login, remembering where they wanted to go. */
export function resolveAuthRedirect(
  to: Pick<RouteLocationNormalized, 'fullPath' | 'meta'>,
  isAuthenticated: boolean,
): RouteLocationRaw | true {
  if (to.meta.public) return true
  if (isAuthenticated) return true
  return { name: 'login', query: { redirect: to.fullPath } }
}
