import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import * as authApi from './api'
import type { User } from './schemas'

/** The token lives in memory only (no localStorage), so a reload requires a new login. */
export const useAuthStore = defineStore('auth', () => {
  const token = ref<string | null>(null)
  const user = ref<User | null>(null)
  const isAuthenticated = computed(() => token.value !== null)

  async function login(email: string, password: string) {
    const result = await authApi.login(email, password)
    token.value = result.token
    user.value = result.user
  }

  async function logout() {
    try {
      await authApi.logout()
    } catch {
      // The session is dropped locally either way.
    } finally {
      clear()
    }
  }

  function clear() {
    token.value = null
    user.value = null
  }

  return { token, user, isAuthenticated, login, logout, clear }
})
