import { z } from 'zod'
import { request } from '@/shared/api/http'
import { loginResponseSchema } from './schemas'

export function login(email: string, password: string) {
  return request('/api/login', loginResponseSchema, {
    method: 'POST',
    body: { email, password },
    skipUnauthorizedHandler: true,
  })
}

export function logout() {
  return request('/api/logout', z.undefined(), { method: 'POST', skipUnauthorizedHandler: true })
}
