<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { useUsers } from '@/features/users'
import {
  PRIORITIES,
  ticketInputSchema,
  validate,
  type TicketInput,
  type TicketPriority,
} from '../schemas'

const props = defineProps<{
  initial: TicketInput
  submitLabel: string
  pending: boolean
  /** Field errors from an API 422 response. */
  serverErrors: Record<string, string>
  /** Non-field failure message (network error, 404...). */
  formError: string | null
}>()

const emit = defineEmits<{ submit: [value: TicketInput] }>()

const { users } = useUsers()

// One-time snapshot: edits stay local until submit.
 
const form = reactive<TicketInput>({ ...props.initial })
const submitted = ref(false)
const touched = reactive<Record<string, boolean>>({})
// Fields edited since the last server response; their server error is stale.
const edited = reactive<Record<string, boolean>>({})

const clientErrors = computed(() => validate(ticketInputSchema, form))

function errorFor(field: string): string | undefined {
  const server = edited[field] ? undefined : props.serverErrors[field]
  if (server) return server
  return submitted.value || touched[field] ? clientErrors.value[field] : undefined
}

function onInput(field: string) {
  edited[field] = true
}

function onSubmit() {
  if (props.pending) return
  submitted.value = true
  for (const key of Object.keys(edited)) delete edited[key]
  if (Object.keys(clientErrors.value).length > 0) return
  emit('submit', { ...form })
}

function setPriority(event: Event) {
  const value = (event.target as HTMLSelectElement).value
  const match = PRIORITIES.find((p): p is TicketPriority => p === value)
  if (match) form.priority = match
  onInput('priority')
}
</script>

<template>
  <form novalidate @submit.prevent="onSubmit">
    <p v-if="formError" role="alert" class="error">{{ formError }}</p>

    <div class="field">
      <label for="ticket-title">Title</label>
      <input
        id="ticket-title"
        v-model="form.title"
        type="text"
        maxlength="200"
        :aria-invalid="errorFor('title') ? 'true' : undefined"
        :aria-describedby="errorFor('title') ? 'ticket-title-error' : undefined"
        @input="onInput('title')"
        @blur="touched.title = true"
      />
      <p v-if="errorFor('title')" id="ticket-title-error" class="error">{{ errorFor('title') }}</p>
    </div>

    <div class="field">
      <label for="ticket-description">Description</label>
      <textarea
        id="ticket-description"
        v-model="form.description"
        rows="5"
        :aria-invalid="errorFor('description') ? 'true' : undefined"
        :aria-describedby="errorFor('description') ? 'ticket-description-error' : undefined"
        @input="onInput('description')"
        @blur="touched.description = true"
      />
      <p v-if="errorFor('description')" id="ticket-description-error" class="error">
        {{ errorFor('description') }}
      </p>
    </div>

    <div class="field">
      <label for="ticket-priority">Priority</label>
      <select
        id="ticket-priority"
        :value="form.priority"
        :aria-invalid="errorFor('priority') ? 'true' : undefined"
        :aria-describedby="errorFor('priority') ? 'ticket-priority-error' : undefined"
        @change="setPriority"
      >
        <option v-for="p in PRIORITIES" :key="p" :value="p">{{ p }}</option>
      </select>
      <p v-if="errorFor('priority')" id="ticket-priority-error" class="error">
        {{ errorFor('priority') }}
      </p>
    </div>

    <div class="field">
      <label for="ticket-assignee">Assignee</label>
      <select
        id="ticket-assignee"
        :value="form.assigneeId ?? ''"
        :aria-invalid="errorFor('assigneeId') ? 'true' : undefined"
        :aria-describedby="errorFor('assigneeId') ? 'ticket-assignee-error' : undefined"
        @change="
          (e: Event) => {
            form.assigneeId = (e.target as HTMLSelectElement).value || null
            onInput('assigneeId')
          }
        "
      >
        <option value="">Unassigned</option>
        <option v-for="u in users" :key="u.id" :value="u.id">{{ u.name }}</option>
      </select>
      <p v-if="errorFor('assigneeId')" id="ticket-assignee-error" class="error">
        {{ errorFor('assigneeId') }}
      </p>
    </div>

    <button type="submit" :disabled="pending">{{ pending ? 'Saving…' : submitLabel }}</button>
  </form>
</template>

<style scoped>
.field {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  margin-bottom: 1rem;
  max-width: 36rem;
}
.error {
  color: #b00020;
  margin: 0;
}
</style>
