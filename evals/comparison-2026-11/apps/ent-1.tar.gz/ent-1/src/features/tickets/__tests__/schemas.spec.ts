import { describe, expect, it } from 'vitest'
import { parseAssignee, parsePage, parseStatus, ticketInputSchema, validate } from '../schemas'
import { parseTicketId } from '../routeParams'

const valid = {
  title: 'Cannot log in',
  description: 'The login page throws an error.',
  priority: 'medium',
  assigneeId: null,
}

describe('ticket validation (matches the API rules)', () => {
  it('accepts a valid ticket', () => {
    expect(validate(ticketInputSchema, valid)).toEqual({})
  })

  it('rejects titles shorter than 5 characters, also when padded with spaces', () => {
    expect(validate(ticketInputSchema, { ...valid, title: 'abcd' }).title).toBeDefined()
    expect(validate(ticketInputSchema, { ...valid, title: '  ab  ' }).title).toBeDefined()
    expect(validate(ticketInputSchema, { ...valid, title: 'abcde' }).title).toBeUndefined()
  })

  it('rejects titles longer than 120 characters', () => {
    expect(validate(ticketInputSchema, { ...valid, title: 'a'.repeat(121) }).title).toBeDefined()
    expect(validate(ticketInputSchema, { ...valid, title: 'a'.repeat(120) }).title).toBeUndefined()
  })

  it('rejects descriptions shorter than 10 characters', () => {
    expect(validate(ticketInputSchema, { ...valid, description: 'too short' }).description).toBe(
      'Description must be at least 10 characters',
    )
    expect(validate(ticketInputSchema, { ...valid, description: 'ten chars!' })).toEqual({})
  })

  it('rejects unknown priorities', () => {
    expect(validate(ticketInputSchema, { ...valid, priority: 'urgent' }).priority).toBeDefined()
  })
})

describe('query parsing', () => {
  it('parsePage falls back to 1 for bad values', () => {
    expect(parsePage('3')).toBe(3)
    expect(parsePage('0')).toBe(1)
    expect(parsePage('-2')).toBe(1)
    expect(parsePage('abc')).toBe(1)
    expect(parsePage(undefined)).toBe(1)
  })

  it('parseStatus only accepts known statuses', () => {
    expect(parseStatus('closed')).toBe('closed')
    expect(parseStatus('bogus')).toBe('')
    expect(parseStatus(['open'])).toBe('')
  })

  it('parseAssignee accepts ids and "none", rejects anything else', () => {
    expect(parseAssignee('u1')).toBe('u1')
    expect(parseAssignee('none')).toBe('none')
    expect(parseAssignee('../x')).toBe('')
    expect(parseAssignee(['u1'])).toBe('')
    expect(parseAssignee(undefined)).toBe('')
  })

  it('parseTicketId rejects odd route params', () => {
    expect(parseTicketId('12')).toBe('12')
    expect(parseTicketId(['1', '2'])).toBeNull()
    expect(parseTicketId('../x')).toBeNull()
    expect(parseTicketId(undefined)).toBeNull()
  })
})
