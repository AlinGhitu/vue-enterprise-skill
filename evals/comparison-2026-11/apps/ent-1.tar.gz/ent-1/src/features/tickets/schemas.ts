import { z } from 'zod'

export const STATUSES = ['open', 'in_progress', 'closed'] as const
export const PRIORITIES = ['low', 'medium', 'high'] as const

export const statusSchema = z.enum(STATUSES)
export const prioritySchema = z.enum(PRIORITIES)
export type TicketStatus = z.infer<typeof statusSchema>
export type TicketPriority = z.infer<typeof prioritySchema>

export const ticketSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  status: statusSchema,
  priority: prioritySchema,
  assigneeId: z.string().nullable(),
  createdAt: z.string(),
  updatedAt: z.string(),
})
export type Ticket = z.infer<typeof ticketSchema>

export const ticketPageSchema = z.object({
  items: z.array(ticketSchema),
  total: z.number(),
  page: z.number(),
  pageSize: z.number(),
})
export type TicketPage = z.infer<typeof ticketPageSchema>

export const commentSchema = z.object({
  id: z.string(),
  ticketId: z.string(),
  authorId: z.string(),
  body: z.string(),
  createdAt: z.string(),
})
export type Comment = z.infer<typeof commentSchema>

export const PAGE_SIZE = 10

/** Same rules as the API: title 5-120 characters, description at least 10 (both trimmed). */
export const ticketInputSchema = z.object({
  title: z
    .string()
    .refine((v) => v.trim().length >= 5 && v.length <= 120, 'Title must be 5-120 characters'),
  description: z
    .string()
    .refine((v) => v.trim().length >= 10, 'Description must be at least 10 characters'),
  priority: prioritySchema,
  assigneeId: z.string().nullable(),
})
export type TicketInput = z.infer<typeof ticketInputSchema>

export const commentInputSchema = z.object({
  body: z.string().refine((v) => v.trim().length > 0, 'Comment cannot be empty'),
})

/** Returns `{ field: message }` for the first error of each invalid field. */
export function validate(
  schema: z.ZodType,
  value: unknown,
): Record<string, string> {
  const result = schema.safeParse(value)
  const errors: Record<string, string> = {}
  if (!result.success) {
    for (const issue of result.error.issues) {
      const field = String(issue.path[0] ?? '')
      if (field && !(field in errors)) errors[field] = issue.message
    }
  }
  return errors
}

export interface TicketFilters {
  q: string
  status: TicketStatus | ''
  /** '' = any user, 'none' = unassigned, otherwise a user id. */
  assigneeId: string
  page: number
}

export const UNASSIGNED = 'none'

export function parseAssignee(value: unknown): string {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(value) ? value : ''
}

export function parseStatus(value: unknown): TicketStatus | '' {
  const parsed = statusSchema.safeParse(value)
  return parsed.success ? parsed.data : ''
}

export function parsePage(value: unknown): number {
  const n = typeof value === 'string' ? Number.parseInt(value, 10) : NaN
  return Number.isInteger(n) && n >= 1 ? n : 1
}

export const STATUS_LABELS: Record<TicketStatus, string> = {
  open: 'Open',
  in_progress: 'In progress',
  closed: 'Closed',
}
