import { describe, expect, it, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { PiniaColada } from '@pinia/colada'
import TicketForm from '../components/TicketForm.vue'

vi.mock('@/features/users', () => ({
  useUsers: () => ({ users: { value: [{ id: 'u1', name: 'Dana', email: 'd@x.io' }] } }),
}))

function mountForm(props: Partial<InstanceType<typeof TicketForm>['$props']> = {}) {
  return mount(TicketForm, {
    props: {
      initial: { title: '', description: '', priority: 'medium', assigneeId: null },
      submitLabel: 'Save',
      pending: false,
      serverErrors: {},
      formError: null,
      ...props,
    },
    global: { plugins: [createPinia(), PiniaColada] },
  })
}

describe('TicketForm', () => {
  it('blocks submit and shows client errors next to the fields', async () => {
    const wrapper = mountForm()
    await wrapper.find('#ticket-title').setValue('abc')
    await wrapper.find('form').trigger('submit')

    expect(wrapper.emitted('submit')).toBeUndefined()
    expect(wrapper.find('#ticket-title-error').text()).toBe('Title must be 5-120 characters')
    expect(wrapper.find('#ticket-description-error').text()).toContain('at least 10')
    expect(wrapper.find('#ticket-title').attributes('aria-invalid')).toBe('true')
  })

  it('emits the trimmed-valid values when valid', async () => {
    const wrapper = mountForm()
    await wrapper.find('#ticket-title').setValue('Printer is broken')
    await wrapper.find('#ticket-description').setValue('The office printer jams constantly.')
    await wrapper.find('form').trigger('submit')

    expect(wrapper.emitted('submit')?.[0]).toEqual([
      {
        title: 'Printer is broken',
        description: 'The office printer jams constantly.',
        priority: 'medium',
        assigneeId: null,
      },
    ])
  })

  it('shows API 422 errors next to their fields until the field is edited', async () => {
    const wrapper = mountForm({
      initial: {
        title: 'Valid title',
        description: 'A valid long description',
        priority: 'low',
        assigneeId: null,
      },
      serverErrors: { assigneeId: 'Unknown user', title: 'Title taken' },
    })
    expect(wrapper.find('#ticket-title-error').text()).toBe('Title taken')
    expect(wrapper.find('#ticket-assignee-error').text()).toBe('Unknown user')

    await wrapper.find('#ticket-title').setValue('Another valid title')
    expect(wrapper.find('#ticket-title-error').exists()).toBe(false)
    expect(wrapper.find('#ticket-assignee-error').exists()).toBe(true)
  })

  it('disables the submit button while pending', () => {
    const wrapper = mountForm({ pending: true })
    expect(wrapper.find('button[type=submit]').attributes('disabled')).toBeDefined()
  })
})
