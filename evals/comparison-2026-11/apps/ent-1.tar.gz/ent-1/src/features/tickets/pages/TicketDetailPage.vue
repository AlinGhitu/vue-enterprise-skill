<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import StateMessage from '@/shared/ui/StateMessage.vue'
import TicketDetail from '../components/TicketDetail.vue'
import { parseTicketId } from '../routeParams'

const route = useRoute()
const ticketId = computed(() => parseTicketId(route.params.id))
</script>

<template>
  <StateMessage v-if="ticketId === null" kind="error" message="Invalid ticket id." />
  <TicketDetail v-else :ticket-id="ticketId" />
</template>
