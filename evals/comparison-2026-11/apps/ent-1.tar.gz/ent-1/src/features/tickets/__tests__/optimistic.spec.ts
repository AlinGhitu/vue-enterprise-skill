import { describe, expect, it } from 'vitest'
import { closeInPage, optimisticValueFor } from '../optimistic'
import type { Ticket, TicketPage } from '../schemas'

function ticket(id: string, status: Ticket['status'] = 'open'): Ticket {
  return {
    id,
    title: `Ticket ${id}`,
    description: 'Some description',
    status,
    priority: 'low',
    assigneeId: null,
    createdAt: '2026-10-01T00:00:00Z',
    updatedAt: '2026-10-01T00:00:00Z',
  }
}

const page: TicketPage = { items: [ticket('1'), ticket('2', 'closed')], total: 2, page: 1, pageSize: 10 }

describe('closeInPage', () => {
  it('closes the ticket without mutating the input', () => {
    const next = closeInPage(page, '1')
    expect(next.items[0]?.status).toBe('closed')
    expect(page.items[0]?.status).toBe('open')
  })

  it('returns the same page when the ticket is absent or already closed', () => {
    expect(closeInPage(page, '9')).toBe(page)
    expect(closeInPage(page, '2')).toBe(page)
  })
})

describe('optimisticValueFor', () => {
  it('handles detail entries', () => {
    expect(optimisticValueFor(ticket('1'), '1')).toMatchObject({ id: '1', status: 'closed' })
    expect(optimisticValueFor(ticket('3'), '1')).toBeNull()
  })

  it('handles list entries', () => {
    expect(optimisticValueFor(page, '1')).toMatchObject({ items: [{ status: 'closed' }, {}] })
    expect(optimisticValueFor(page, '9')).toBeNull()
  })

  it('ignores unrelated cache data', () => {
    expect(optimisticValueFor([{ id: 'u1' }], '1')).toBeNull()
    expect(optimisticValueFor(undefined, '1')).toBeNull()
  })
})
