/** Ticket ids are short opaque strings; anything else is not a ticket route. */
export function parseTicketId(param: string | string[] | undefined): string | null {
  return typeof param === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(param) ? param : null
}
