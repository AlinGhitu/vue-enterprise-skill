import { beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { PiniaColada } from '@pinia/colada'
import { createMemoryHistory, createRouter } from 'vue-router'
import TicketListPage from '../pages/TicketListPage.vue'
import * as api from '../api'
import { request } from '@/shared/api/http'

vi.mock('../api')
vi.mock('@/shared/api/http', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@/shared/api/http')>()),
  request: vi.fn<typeof import('@/shared/api/http').request>(),
}))

const users = [
  { id: 'u1', name: 'Ann', email: 'ann@example.com' },
  { id: 'u2', name: 'Bob', email: 'bob@example.com' },
]

async function setup(url = '/tickets') {
  const router = createRouter({
    history: createMemoryHistory(),
    routes: [
      { path: '/tickets', name: 'tickets', component: TicketListPage },
      { path: '/tickets/new', name: 'ticket-new', component: { template: '<i />' } },
      { path: '/tickets/:id', name: 'ticket-detail', component: { template: '<i />' } },
    ],
  })
  await router.push(url)
  await router.isReady()
  const wrapper = mount(TicketListPage, {
    global: { plugins: [createPinia(), PiniaColada, router] },
  })
  await flushPromises()
  return { router, wrapper }
}

const lastFilters = () => vi.mocked(api.listTickets).mock.lastCall?.[0]

beforeEach(() => {
  vi.resetAllMocks()
  vi.mocked(request).mockResolvedValue(users)
  vi.mocked(api.listTickets).mockResolvedValue({ items: [], total: 0, page: 1, pageSize: 10 })
})

describe('TicketListPage URL state', () => {
  it('reads search, status, assignee and page from the URL', async () => {
    const { wrapper } = await setup('/tickets?q=vpn&status=open&assigneeId=none&page=2')
    expect(lastFilters()).toEqual({ q: 'vpn', status: 'open', assigneeId: 'none', page: 2 })
    expect(wrapper.get<HTMLSelectElement>('#ticket-assignee').element.value).toBe('none')
    expect(wrapper.get<HTMLSelectElement>('#ticket-status').element.value).toBe('open')
  })

  it('ignores invalid query values', async () => {
    await setup('/tickets?status=bogus&assigneeId=../x&page=-1')
    expect(lastFilters()).toEqual({ q: '', status: '', assigneeId: '', page: 1 })
  })

  it('lists users and "Unassigned" as assignee options', async () => {
    const { wrapper } = await setup()
    const options = wrapper.findAll('#ticket-assignee option').map((o) => o.text())
    expect(options).toEqual(['Any user', 'Unassigned', 'Ann', 'Bob'])
  })

  it('writes the assignee to the URL, resets the page, and supports back/forward', async () => {
    const { wrapper, router } = await setup('/tickets?page=3')
    await wrapper.get('#ticket-assignee').setValue('u2')
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ assigneeId: 'u2' })
    expect(lastFilters()?.assigneeId).toBe('u2')

    router.back()
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ page: '3' })
    // page=3 without assignee was fetched before, so it is served from the cache.
    expect(wrapper.get<HTMLSelectElement>('#ticket-assignee').element.value).toBe('')

    router.forward()
    await flushPromises()
    expect(wrapper.get<HTMLSelectElement>('#ticket-assignee').element.value).toBe('u2')
  })

  it('writes search and status to the URL and syncs the search box on back', async () => {
    const { wrapper, router } = await setup()
    await wrapper.get('#ticket-search').setValue('  printer ')
    await wrapper.get('form').trigger('submit')
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ q: 'printer' })

    await wrapper.get('#ticket-status').setValue('closed')
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ q: 'printer', status: 'closed' })

    router.back()
    await flushPromises()
    expect(router.currentRoute.value.query).toEqual({ q: 'printer' })
    router.back()
    await flushPromises()
    expect(wrapper.get<HTMLInputElement>('#ticket-search').element.value).toBe('')
  })
})
