<script setup lang="ts">
import { errorMessage } from '@/shared/api/http'
import { useCloseTicket } from '../useCloseTicket'
import type { TicketStatus } from '../schemas'

const props = defineProps<{ ticketId: string; status: TicketStatus; ticketTitle: string }>()

const { mutate, error } = useCloseTicket()
</script>

<template>
  <span class="close-ticket">
    <button v-if="props.status !== 'closed'" type="button" @click="mutate(props.ticketId)">
      Close ticket<span class="sr-only">: {{ props.ticketTitle }}</span>
    </button>
    <span v-if="error" role="alert" class="error">
      Could not close ticket: {{ errorMessage(error) }}
    </span>
  </span>
</template>

<style scoped>
.error {
  color: #b00020;
  margin-left: 0.5rem;
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
</style>
