import * as api from './api'
import type { TicketFilters, TicketPage } from './schemas'

export const TICKET_KEYS = {
  root: ['tickets'] as const,
  lists: () => [...TICKET_KEYS.root, 'list'] as const,
  list: (f: TicketFilters) =>
    [...TICKET_KEYS.lists(), { q: f.q.trim(), status: f.status, assigneeId: f.assigneeId, page: f.page }] as const,
  detail: (id: string) => [...TICKET_KEYS.root, 'detail', id] as const,
  comments: (id: string) => ['ticket-comments', id] as const,
}

export const ticketListQuery = (f: TicketFilters) => ({
  key: TICKET_KEYS.list(f),
  query: ({ signal }: { signal: AbortSignal }) => api.listTickets(f, signal),
  // Keep the previous page on screen while the next one loads.
  placeholderData: (previous: TicketPage | undefined) => previous,
})

export const ticketDetailQuery = (id: string) => ({
  key: TICKET_KEYS.detail(id),
  query: ({ signal }: { signal: AbortSignal }) => api.getTicket(id, signal),
})

export const commentsQuery = (id: string) => ({
  key: TICKET_KEYS.comments(id),
  query: ({ signal }: { signal: AbortSignal }) => api.listComments(id, signal),
})
