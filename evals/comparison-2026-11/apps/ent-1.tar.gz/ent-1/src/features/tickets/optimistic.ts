import type { EntryKey } from '@pinia/colada'
import { ticketPageSchema, ticketSchema, type Ticket, type TicketPage } from './schemas'

/** Immutable: returns a closed copy of the ticket. */
export function closed(ticket: Ticket): Ticket {
  return { ...ticket, status: 'closed' }
}

/** Immutable: returns a page whose ticket `id` is closed, or the same page when it isn't listed. */
export function closeInPage(page: TicketPage, id: string): TicketPage {
  if (!page.items.some((t) => t.id === id && t.status !== 'closed')) return page
  return { ...page, items: page.items.map((t) => (t.id === id ? closed(t) : t)) }
}

export interface OptimisticChange {
  key: EntryKey
  previous: unknown
  optimistic: unknown
}

/**
 * Builds the optimistic value for one cache entry, or `null` when the entry
 * doesn't hold an open ticket `id`. Entries are recognised by parsing their data.
 */
export function optimisticValueFor(data: unknown, id: string): Ticket | TicketPage | null {
  const asTicket = ticketSchema.safeParse(data)
  if (asTicket.success) {
    return asTicket.data.id === id && asTicket.data.status !== 'closed'
      ? closed(asTicket.data)
      : null
  }
  const asPage = ticketPageSchema.safeParse(data)
  if (asPage.success) {
    const next = closeInPage(asPage.data, id)
    return next === asPage.data ? null : next
  }
  return null
}
