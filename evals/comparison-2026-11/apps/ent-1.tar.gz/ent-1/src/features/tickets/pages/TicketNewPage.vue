<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink, useRouter } from 'vue-router'
import { useMutation, useQueryCache } from '@pinia/colada'
import { ApiError, errorMessage } from '@/shared/api/http'
import TicketForm from '../components/TicketForm.vue'
import * as api from '../api'
import { TICKET_KEYS } from '../queries'
import type { TicketInput } from '../schemas'

const router = useRouter()
const queryCache = useQueryCache()

const initial: TicketInput = { title: '', description: '', priority: 'medium', assigneeId: null }

const create = useMutation({
  mutation: (input: TicketInput) => api.createTicket(input),
  onSuccess: (ticket) => router.push({ name: 'ticket-detail', params: { id: ticket.id } }),
  onSettled: () => queryCache.invalidateQueries({ key: TICKET_KEYS.root }),
})

const serverErrors = computed(() =>
  create.error.value instanceof ApiError ? create.error.value.fieldErrors : {},
)
const formError = computed(() => {
  const error = create.error.value
  if (!error) return null
  return error instanceof ApiError && error.status === 422 ? null : errorMessage(error)
})
</script>

<template>
  <section>
    <p><RouterLink :to="{ name: 'tickets' }">← All tickets</RouterLink></p>
    <h1>New ticket</h1>
    <TicketForm
      :initial="initial"
      submit-label="Create ticket"
      :pending="create.asyncStatus.value === 'loading'"
      :server-errors="serverErrors"
      :form-error="formError"
      @submit="create.mutate($event)"
    />
  </section>
</template>
