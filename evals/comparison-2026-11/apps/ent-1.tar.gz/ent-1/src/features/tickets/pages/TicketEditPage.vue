<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink, useRoute, useRouter } from 'vue-router'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import StateMessage from '@/shared/ui/StateMessage.vue'
import { ApiError, errorMessage } from '@/shared/api/http'
import TicketForm from '../components/TicketForm.vue'
import * as api from '../api'
import { parseTicketId } from '../routeParams'
import { ticketDetailQuery, TICKET_KEYS } from '../queries'
import type { TicketInput } from '../schemas'

const route = useRoute()
const router = useRouter()
const queryCache = useQueryCache()

const ticketId = computed(() => parseTicketId(route.params.id))
const ticket = useQuery(() => ({
  ...ticketDetailQuery(ticketId.value ?? ''),
  enabled: ticketId.value !== null,
}))

const update = useMutation({
  mutation: (input: TicketInput) => api.updateTicket(ticketId.value ?? '', input),
  onSuccess: async (saved) => {
    queryCache.setQueryData(TICKET_KEYS.detail(saved.id), saved)
    await router.push({ name: 'ticket-detail', params: { id: saved.id } })
  },
  onSettled: () => queryCache.invalidateQueries({ key: TICKET_KEYS.root }),
})

const serverErrors = computed(() =>
  update.error.value instanceof ApiError ? update.error.value.fieldErrors : {},
)
const formError = computed(() => {
  const error = update.error.value
  if (!error) return null
  return error instanceof ApiError && error.status === 422 ? null : errorMessage(error)
})
</script>

<template>
  <section>
    <p><RouterLink :to="{ name: 'tickets' }">← All tickets</RouterLink></p>
    <h1>Edit ticket</h1>
    <StateMessage v-if="ticketId === null" kind="error" message="Invalid ticket id." />
    <StateMessage v-else-if="ticket.state.value.status === 'pending'" kind="loading" message="Loading ticket…" />
    <StateMessage
      v-else-if="ticket.state.value.status === 'error'"
      kind="error"
      :message="`Could not load ticket: ${errorMessage(ticket.state.value.error)}`"
    >
      <button type="button" @click="ticket.refetch()">Retry</button>
    </StateMessage>
    <TicketForm
      v-else-if="ticket.state.value.data"
      :key="ticket.state.value.data.id"
      :initial="{
        title: ticket.state.value.data.title,
        description: ticket.state.value.data.description,
        priority: ticket.state.value.data.priority,
        assigneeId: ticket.state.value.data.assigneeId,
      }"
      submit-label="Save changes"
      :pending="update.asyncStatus.value === 'loading'"
      :server-errors="serverErrors"
      :form-error="formError"
      @submit="update.mutate($event)"
    />
  </section>
</template>
