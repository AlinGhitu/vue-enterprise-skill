import { z } from 'zod'
import { request } from '@/shared/api/http'
import {
  commentSchema,
  PAGE_SIZE,
  ticketPageSchema,
  ticketSchema,
  type TicketFilters,
  type TicketInput,
  type TicketStatus,
} from './schemas'

export function listTickets(filters: TicketFilters, signal?: AbortSignal) {
  return request('/api/tickets', ticketPageSchema, {
    query: {
      q: filters.q.trim(),
      status: filters.status,
      assigneeId: filters.assigneeId,
      page: filters.page,
      pageSize: PAGE_SIZE,
    },
    signal,
  })
}

export function getTicket(id: string, signal?: AbortSignal) {
  return request(`/api/tickets/${encodeURIComponent(id)}`, ticketSchema, { signal })
}

export function createTicket(input: TicketInput) {
  return request('/api/tickets', ticketSchema, {
    method: 'POST',
    body: {
      title: input.title,
      description: input.description,
      priority: input.priority,
      assigneeId: input.assigneeId,
    },
  })
}

export function updateTicket(id: string, input: Partial<TicketInput> & { status?: TicketStatus }) {
  return request(`/api/tickets/${encodeURIComponent(id)}`, ticketSchema, {
    method: 'PATCH',
    body: input,
  })
}

export function listComments(ticketId: string, signal?: AbortSignal) {
  return request(
    `/api/tickets/${encodeURIComponent(ticketId)}/comments`,
    z.array(commentSchema),
    { signal },
  )
}

export function addComment(ticketId: string, body: string) {
  return request(`/api/tickets/${encodeURIComponent(ticketId)}/comments`, commentSchema, {
    method: 'POST',
    body: { body },
  })
}
