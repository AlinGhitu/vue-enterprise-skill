<script setup lang="ts">
import { computed, ref } from 'vue'
import { RouterLink } from 'vue-router'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import StateMessage from '@/shared/ui/StateMessage.vue'
import { ApiError, errorMessage } from '@/shared/api/http'
import { formatDateTime } from '@/shared/lib/format'
import { useUsers } from '@/features/users'
import CloseTicketButton from './CloseTicketButton.vue'
import * as api from '../api'
import { commentsQuery, ticketDetailQuery, TICKET_KEYS } from '../queries'
import { commentInputSchema, STATUS_LABELS, validate } from '../schemas'

const props = defineProps<{ ticketId: string }>()

const { nameOf } = useUsers()
const ticket = useQuery(() => ticketDetailQuery(props.ticketId))
const comments = useQuery(() => commentsQuery(props.ticketId))
const queryCache = useQueryCache()

const body = ref('')
const submitted = ref(false)
const clientError = computed(() =>
  submitted.value ? validate(commentInputSchema, { body: body.value }).body : undefined,
)

const addComment = useMutation({
  mutation: (text: string) => api.addComment(props.ticketId, text),
  onSuccess: () => {
    body.value = ''
    submitted.value = false
  },
  onSettled: () => queryCache.invalidateQueries({ key: TICKET_KEYS.comments(props.ticketId) }),
})

const commentError = computed(() => {
  if (clientError.value) return clientError.value
  const error = addComment.error.value
  if (error instanceof ApiError) return error.fieldErrors.body ?? error.message
  return error ? errorMessage(error) : undefined
})

function submitComment() {
  if (addComment.asyncStatus.value === 'loading') return
  submitted.value = true
  if (validate(commentInputSchema, { body: body.value }).body) return
  addComment.mutate(body.value)
}
</script>

<template>
  <section>
    <p><RouterLink :to="{ name: 'tickets' }">← All tickets</RouterLink></p>

    <StateMessage v-if="ticket.state.value.status === 'pending'" kind="loading" message="Loading ticket…" />
    <StateMessage
      v-else-if="ticket.state.value.status === 'error'"
      kind="error"
      :message="
        ticket.state.value.error instanceof ApiError && ticket.state.value.error.status === 404
          ? 'Ticket not found.'
          : `Could not load ticket: ${errorMessage(ticket.state.value.error)}`
      "
    >
      <button type="button" @click="ticket.refetch()">Retry</button>
    </StateMessage>

    <article v-else-if="ticket.state.value.data">
      <h1>{{ ticket.state.value.data.title }}</h1>
      <dl>
        <dt>Status</dt>
        <dd>{{ STATUS_LABELS[ticket.state.value.data.status] }}</dd>
        <dt>Priority</dt>
        <dd>{{ ticket.state.value.data.priority }}</dd>
        <dt>Assignee</dt>
        <dd>{{ nameOf(ticket.state.value.data.assigneeId) }}</dd>
        <dt>Created</dt>
        <dd>{{ formatDateTime(ticket.state.value.data.createdAt) }}</dd>
        <dt>Updated</dt>
        <dd>{{ formatDateTime(ticket.state.value.data.updatedAt) }}</dd>
        <dt>Description</dt>
        <dd class="description">{{ ticket.state.value.data.description }}</dd>
      </dl>
      <p class="actions">
        <RouterLink :to="{ name: 'ticket-edit', params: { id: ticket.state.value.data.id } }">
          Edit ticket
        </RouterLink>
        <CloseTicketButton
          :ticket-id="ticket.state.value.data.id"
          :status="ticket.state.value.data.status"
          :ticket-title="ticket.state.value.data.title"
        />
      </p>
    </article>

    <section aria-labelledby="comments-heading">
      <h2 id="comments-heading">Comments</h2>
      <StateMessage v-if="comments.state.value.status === 'pending'" kind="loading" message="Loading comments…" />
      <StateMessage
        v-else-if="comments.state.value.status === 'error'"
        kind="error"
        :message="`Could not load comments: ${errorMessage(comments.state.value.error)}`"
      >
        <button type="button" @click="comments.refetch()">Retry</button>
      </StateMessage>
      <template v-else-if="comments.state.value.data">
        <StateMessage
          v-if="comments.state.value.data.length === 0"
          kind="empty"
          message="No comments yet."
        />
        <ul v-else class="comments">
          <li v-for="c in comments.state.value.data" :key="c.id">
            <strong>{{ nameOf(c.authorId) }}</strong>
            <time :datetime="c.createdAt"> {{ formatDateTime(c.createdAt) }}</time>
            <p>{{ c.body }}</p>
          </li>
        </ul>
      </template>

      <form novalidate @submit.prevent="submitComment">
        <label for="comment-body">Add a comment</label>
        <textarea
          id="comment-body"
          v-model="body"
          rows="3"
          :aria-invalid="commentError ? 'true' : undefined"
          :aria-describedby="commentError ? 'comment-body-error' : undefined"
        />
        <p v-if="commentError" id="comment-body-error" class="error">{{ commentError }}</p>
        <button type="submit" :disabled="addComment.asyncStatus.value === 'loading'">
          {{ addComment.asyncStatus.value === 'loading' ? 'Posting…' : 'Post comment' }}
        </button>
      </form>
    </section>
  </section>
</template>

<style scoped>
.description {
  white-space: pre-wrap;
}
.comments {
  list-style: none;
  padding: 0;
}
.actions {
  display: flex;
  gap: 1rem;
  align-items: center;
}
form {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  max-width: 36rem;
  margin-top: 1rem;
}
.error {
  color: #b00020;
  margin: 0;
}
</style>
