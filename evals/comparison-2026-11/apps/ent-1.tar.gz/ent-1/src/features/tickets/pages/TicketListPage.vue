<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { RouterLink, useRoute, useRouter } from 'vue-router'
import { useQuery } from '@pinia/colada'
import StateMessage from '@/shared/ui/StateMessage.vue'
import { errorMessage } from '@/shared/api/http'
import { formatDate } from '@/shared/lib/format'
import { useUsers } from '@/features/users'
import CloseTicketButton from '../components/CloseTicketButton.vue'
import { ticketListQuery } from '../queries'
import {
  PAGE_SIZE,
  parseAssignee,
  parsePage,
  parseStatus,
  STATUS_LABELS,
  STATUSES,
  type TicketFilters,
  UNASSIGNED,
} from '../schemas'

const route = useRoute()
const router = useRouter()
const { nameOf, users } = useUsers()

const filters = computed<TicketFilters>(() => ({
  q: typeof route.query.q === 'string' ? route.query.q : '',
  status: parseStatus(route.query.status),
  assigneeId: parseAssignee(route.query.assigneeId),
  page: parsePage(route.query.page),
}))

const searchText = ref(filters.value.q)
watch(
  () => filters.value.q,
  (q) => {
    searchText.value = q
  },
)

const { state, asyncStatus, refetch } = useQuery(() => ticketListQuery(filters.value))

const totalPages = computed(() =>
  state.value.data ? Math.max(1, Math.ceil(state.value.data.total / PAGE_SIZE)) : 1,
)

function update(next: Partial<TicketFilters>) {
  const merged = { ...filters.value, ...next }
  void router.push({
    query: {
      q: merged.q.trim() || undefined,
      status: merged.status || undefined,
      assigneeId: merged.assigneeId || undefined,
      page: merged.page > 1 ? String(merged.page) : undefined,
    },
  })
}

function onSearch() {
  update({ q: searchText.value, page: 1 })
}

function onAssignee(event: Event) {
  if (event.target instanceof HTMLSelectElement) {
    update({ assigneeId: parseAssignee(event.target.value), page: 1 })
  }
}

function onStatus(event: Event) {
  if (event.target instanceof HTMLSelectElement) {
    update({ status: parseStatus(event.target.value), page: 1 })
  }
}
</script>

<template>
  <section>
    <header class="bar">
      <h1>Tickets</h1>
      <RouterLink :to="{ name: 'ticket-new' }">New ticket</RouterLink>
    </header>

    <form role="search" class="filters" @submit.prevent="onSearch">
      <label for="ticket-search">Search</label>
      <input id="ticket-search" v-model="searchText" type="search" />
      <button type="submit">Search</button>

      <label for="ticket-status">Status</label>
      <select id="ticket-status" :value="filters.status" @change="onStatus">
        <option value="">All</option>
        <option v-for="s in STATUSES" :key="s" :value="s">{{ STATUS_LABELS[s] }}</option>
      </select>

      <label for="ticket-assignee">Assignee</label>
      <select id="ticket-assignee" :value="filters.assigneeId" @change="onAssignee">
        <option value="">Any user</option>
        <option :value="UNASSIGNED">Unassigned</option>
        <option v-for="u in users" :key="u.id" :value="u.id">{{ u.name }}</option>
      </select>
    </form>

    <StateMessage v-if="state.status === 'pending'" kind="loading" message="Loading tickets…" />

    <template v-else>
      <StateMessage
        v-if="state.status === 'error'"
        kind="error"
        :message="`Could not load tickets: ${errorMessage(state.error)}`"
      >
        <button type="button" @click="refetch()">Retry</button>
      </StateMessage>

      <template v-if="state.data">
        <StateMessage
          v-if="state.data.items.length === 0"
          kind="empty"
          message="No tickets match your filters."
        />

        <table v-else :aria-busy="asyncStatus === 'loading'">
          <caption class="sr-only">
            Tickets
          </caption>
          <thead>
            <tr>
              <th scope="col">Title</th>
              <th scope="col">Status</th>
              <th scope="col">Priority</th>
              <th scope="col">Assignee</th>
              <th scope="col">Created</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="ticket in state.data.items" :key="ticket.id">
              <td>
                <RouterLink :to="{ name: 'ticket-detail', params: { id: ticket.id } }">
                  {{ ticket.title }}
                </RouterLink>
              </td>
              <td>{{ STATUS_LABELS[ticket.status] }}</td>
              <td>{{ ticket.priority }}</td>
              <td>{{ nameOf(ticket.assigneeId) }}</td>
              <td>{{ formatDate(ticket.createdAt) }}</td>
              <td>
                <CloseTicketButton
                  :ticket-id="ticket.id"
                  :status="ticket.status"
                  :ticket-title="ticket.title"
                />
              </td>
            </tr>
          </tbody>
        </table>

        <nav v-if="state.data.total > 0" aria-label="Pagination" class="pager">
          <button
            type="button"
            :disabled="filters.page <= 1"
            @click="update({ page: filters.page - 1 })"
          >
            Previous
          </button>
          <span>Page {{ filters.page }} of {{ totalPages }} ({{ state.data.total }} tickets)</span>
          <button
            type="button"
            :disabled="filters.page >= totalPages"
            @click="update({ page: filters.page + 1 })"
          >
            Next
          </button>
        </nav>
      </template>
    </template>
  </section>
</template>

<style scoped>
.bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.filters {
  display: flex;
  gap: 0.5rem;
  align-items: center;
  flex-wrap: wrap;
  margin-bottom: 1rem;
}
table {
  width: 100%;
  border-collapse: collapse;
}
th,
td {
  text-align: left;
  padding: 0.4rem;
  border-bottom: 1px solid var(--color-border);
}
.pager {
  display: flex;
  gap: 1rem;
  align-items: center;
  margin-top: 1rem;
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
}
</style>
