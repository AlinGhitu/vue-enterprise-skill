import { beforeEach, describe, expect, it, vi } from 'vitest'
import { defineComponent } from 'vue'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { PiniaColada, useQueryCache } from '@pinia/colada'
import { useCloseTicket } from '../useCloseTicket'
import { TICKET_KEYS } from '../queries'
import * as api from '../api'
import type { Ticket, TicketPage } from '../schemas'

vi.mock('../api')

const open: Ticket = {
  id: '1',
  title: 'Ticket 1',
  description: 'Some description',
  status: 'open',
  priority: 'low',
  assigneeId: null,
  createdAt: '2026-10-01T00:00:00Z',
  updatedAt: '2026-10-01T00:00:00Z',
}
const listKey = TICKET_KEYS.list({ q: '', status: '', assigneeId: '', page: 1 })

function setup() {
  const page: TicketPage = { items: [open], total: 1, page: 1, pageSize: 10 }
  let result!: ReturnType<typeof useCloseTicket>
  let cache!: ReturnType<typeof useQueryCache>
  mount(
    defineComponent({
      setup() {
        result = useCloseTicket()
        cache = useQueryCache()
        return () => null
      },
    }),
    { global: { plugins: [createPinia(), PiniaColada] } },
  )
  cache.setQueryData(listKey, page)
  cache.setQueryData(TICKET_KEYS.detail('1'), open)
  return { result, cache }
}

function statusOf(cache: ReturnType<typeof useQueryCache>) {
  const list = cache.getQueryData<TicketPage>(listKey)
  const detail = cache.getQueryData<Ticket>(TICKET_KEYS.detail('1'))
  return { list: list?.items[0]?.status, detail: detail?.status }
}

describe('useCloseTicket', () => {
  beforeEach(() => vi.resetAllMocks())

  it('updates list and detail caches immediately, before the request resolves', async () => {
    vi.mocked(api.updateTicket).mockReturnValue(new Promise(() => {}))
    const { result, cache } = setup()

    result.mutate('1')
    await flushPromises()

    expect(statusOf(cache)).toEqual({ list: 'closed', detail: 'closed' })
  })

  it('rolls back when the request fails', async () => {
    vi.mocked(api.updateTicket).mockRejectedValue(new Error('boom'))
    const { result, cache } = setup()

    result.mutate('1')
    await flushPromises()

    expect(statusOf(cache)).toEqual({ list: 'open', detail: 'open' })
    expect(result.error.value?.message).toBe('boom')
  })
})
