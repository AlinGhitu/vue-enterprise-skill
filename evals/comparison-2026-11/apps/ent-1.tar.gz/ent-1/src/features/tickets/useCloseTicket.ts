import { useMutation, useQueryCache } from '@pinia/colada'
import * as api from './api'
import { optimisticValueFor, type OptimisticChange } from './optimistic'
import { TICKET_KEYS } from './queries'

/**
 * Closes a ticket: every cached list page and the detail entry show it as closed
 * immediately; if the request fails each entry is restored, unless something else
 * has replaced it in the meantime.
 */
export function useCloseTicket() {
  const queryCache = useQueryCache()

  return useMutation({
    mutation: (id: string) => api.updateTicket(id, { status: 'closed' }),
    onMutate(id) {
      queryCache.cancelQueries({ key: TICKET_KEYS.root })
      const changes: OptimisticChange[] = []
      for (const entry of queryCache.getEntries({ key: TICKET_KEYS.root })) {
        const previous = entry.state.value.data
        const optimistic = optimisticValueFor(previous, id)
        if (optimistic === null) continue
        queryCache.setQueryData(entry.key, optimistic)
        changes.push({ key: entry.key, previous, optimistic })
      }
      return { changes }
    },
    onError(_error, _id, context) {
      for (const change of context.changes ?? []) {
        if (queryCache.getQueryData(change.key) === change.optimistic) {
          queryCache.setQueryData(change.key, change.previous)
        }
      }
    },
    onSettled: () => queryCache.invalidateQueries({ key: TICKET_KEYS.root }),
  })
}
