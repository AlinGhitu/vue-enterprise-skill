import { computed } from 'vue'
import { useQuery } from '@pinia/colada'
import { z } from 'zod'
import { request } from '@/shared/api/http'
import { userSchema } from '@/features/auth/schemas'

export type { User } from '@/features/auth/schemas'

/** Public API of the users feature: the user list and a name lookup. */
export function useUsers() {
  const query = useQuery({
    key: ['users'],
    query: ({ signal }) => request('/api/users', z.array(userSchema), { signal }),
    staleTime: 60_000,
  })
  const users = computed(() => query.data.value ?? [])
  function nameOf(id: string | null): string {
    if (id === null) return 'Unassigned'
    return users.value.find((u) => u.id === id)?.name ?? 'Unknown user'
  }
  return { users, nameOf, ...query }
}
