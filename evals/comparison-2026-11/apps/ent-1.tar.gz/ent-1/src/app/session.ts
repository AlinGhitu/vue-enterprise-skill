import { useQueryCache } from '@pinia/colada'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/features/auth/useAuthStore'

/** Ends the local session: drops the token and every cached server response. */
export function useEndSession() {
  const auth = useAuthStore()
  const queryCache = useQueryCache()
  const router = useRouter()

  return async function endSession(options: { callServer: boolean; redirectBack: boolean }) {
    if (options.callServer) await auth.logout()
    else auth.clear()
    for (const entry of queryCache.getEntries()) {
      queryCache.cancel(entry)
      queryCache.remove(entry)
    }
    const current = router.currentRoute.value
    if (current.name === 'login') return
    await router.replace(
      options.redirectBack
        ? { name: 'login', query: { redirect: current.fullPath } }
        : { name: 'login' },
    )
  }
}
