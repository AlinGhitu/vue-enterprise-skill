import { describe, expect, it, vi } from 'vitest'
import { reactive } from 'vue'
import type { Ticket } from '@/api/types'
import { useCloseTicket } from '../useCloseTicket'

const make = (): Ticket =>
  reactive({
    id: '7',
    title: 'T',
    description: 'D',
    status: 'open',
    priority: 'low',
    assigneeId: null,
    createdAt: '',
    updatedAt: '',
  })

describe('useCloseTicket', () => {
  it('updates immediately, then keeps the server result', async () => {
    const ticket = make()
    let resolve!: (t: Ticket) => void
    const close = vi.fn<(id: string) => Promise<Ticket>>(
      () => new Promise<Ticket>((r) => (resolve = r)),
    )
    const { closeTicket, closing } = useCloseTicket(close)

    const done = closeTicket(ticket)
    expect(ticket.status).toBe('closed')
    expect(closing.has('7')).toBe(true)

    resolve({ ...ticket, status: 'closed', updatedAt: 'now' })
    expect(await done).toBe(true)
    expect(ticket.updatedAt).toBe('now')
    expect(closing.has('7')).toBe(false)
  })

  it('rolls back and reports an error when the request fails', async () => {
    const ticket = make()
    ticket.status = 'in_progress'
    const { closeTicket, error } = useCloseTicket(() => Promise.reject(new Error('boom')))

    expect(await closeTicket(ticket)).toBe(false)
    expect(ticket.status).toBe('in_progress')
    expect(error.value).toContain('boom')
  })

  it('ignores already closed tickets and duplicate requests', async () => {
    const close = vi.fn<(id: string) => Promise<Ticket>>(() => new Promise<Ticket>(() => {}))
    const { closeTicket } = useCloseTicket(close)
    const ticket = make()
    void closeTicket(ticket)
    expect(await closeTicket(ticket)).toBe(false)
    expect(close).toHaveBeenCalledTimes(1)
  })
})
