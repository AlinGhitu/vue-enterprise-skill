import { reactive, ref } from 'vue'
import { api } from '@/api'
import type { Ticket } from '@/api/types'

/**
 * Optimistically closes a ticket: the (reactive) ticket object is mutated right away
 * and restored if the request fails.
 */
export function useCloseTicket(close: (id: string) => Promise<Ticket> = api.closeTicket) {
  const closing = reactive(new Set<string>())
  const error = ref('')

  async function closeTicket(ticket: Ticket): Promise<boolean> {
    if (ticket.status === 'closed' || closing.has(ticket.id)) return false
    const previous = ticket.status
    error.value = ''
    closing.add(ticket.id)
    ticket.status = 'closed'
    try {
      Object.assign(ticket, await close(ticket.id))
      return true
    } catch (e) {
      ticket.status = previous
      error.value = `Could not close ticket #${ticket.id}: ${e instanceof Error ? e.message : 'unknown error'}`
      return false
    } finally {
      closing.delete(ticket.id)
    }
  }

  return { closing, error, closeTicket }
}
