import './assets/main.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'
import { setUnauthorizedHandler } from './api/client'
import { useAuthStore } from './stores/auth'
import { useUsersStore } from './stores/users'

const app = createApp(App)

app.use(createPinia())
app.use(router)

// Session expired mid-use: drop it and return to login, then back to the current page.
setUnauthorizedHandler(() => {
  useAuthStore().clear()
  useUsersStore().reset()
  const current = router.currentRoute.value
  if (current.name !== 'login') {
    void router.replace({ name: 'login', query: { redirect: current.fullPath } })
  }
})

app.mount('#app')
