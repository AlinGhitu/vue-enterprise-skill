<script setup lang="ts">
import { RouterLink, RouterView, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useUsersStore } from '@/stores/users'

const auth = useAuthStore()
const users = useUsersStore()
const router = useRouter()

async function logout() {
  await auth.logout()
  users.reset()
  await router.push({ name: 'login' })
}
</script>

<template>
  <header v-if="auth.isAuthenticated" class="topbar">
    <RouterLink to="/tickets" class="brand">Support Desk</RouterLink>
    <RouterLink to="/tickets/new">New ticket</RouterLink>
    <span class="spacer" />
    <span v-if="auth.user" class="muted">{{ auth.user.name }}</span>
    <button type="button" @click="logout">Log out</button>
  </header>
  <main class="page">
    <RouterView />
  </main>
</template>

<style scoped>
.topbar {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0.7rem 1.5rem;
  background: #fff;
  border-bottom: 1px solid var(--c-border);
}
.brand {
  font-weight: 700;
  color: var(--c-text);
}
.page {
  max-width: 1000px;
  margin: 0 auto;
  padding: 1.5rem;
}
</style>
