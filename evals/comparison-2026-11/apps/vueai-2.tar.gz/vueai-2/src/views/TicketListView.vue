<script setup lang="ts">
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { RouterLink, useRoute, useRouter } from 'vue-router'
import { api } from '@/api'
import { STATUSES, type Ticket } from '@/api/types'
import TicketBadge from '@/components/TicketBadge.vue'
import { useCloseTicket } from '@/composables/useCloseTicket'
import { useUsersStore } from '@/stores/users'
import {
  PAGE_SIZE,
  formatDate,
  parseListQuery,
  serializeListQuery,
  statusLabel,
  totalPages,
  type ListQuery,
} from '@/utils/ticketQuery'

const route = useRoute()
const router = useRouter()
const users = useUsersStore()
void users.load()

const query = computed(() => parseListQuery(route.query))
// Assignee from the URL that isn't a known user: keep it selectable so the select reflects the URL
const unknownAssignee = computed(() => {
  const id = query.value.assigneeId
  return !!id && id !== 'none' && users.loaded && !users.users.some((u) => u.id === id)
})
const items = ref<Ticket[]>([])
const total = ref(0)
const loading = ref(true)
const error = ref('')
const pages = computed(() => totalPages(total.value))
const { closing, error: closeError, closeTicket } = useCloseTicket()

const searchText = ref(query.value.q)
let seq = 0
let debounce: ReturnType<typeof setTimeout> | undefined

function navigate(patch: Partial<ListQuery>) {
  void router.push({ name: 'tickets', query: serializeListQuery({ ...query.value, ...patch }) })
}

function onSearch() {
  clearTimeout(debounce)
  debounce = setTimeout(() => navigate({ q: searchText.value, page: 1 }), 300)
}

onBeforeUnmount(() => clearTimeout(debounce))

async function load() {
  const mine = ++seq
  loading.value = true
  error.value = ''
  const { q, status, assigneeId, page } = query.value
  try {
    const res = await api.listTickets({ q, status, assigneeId, page, pageSize: PAGE_SIZE })
    if (mine !== seq) return
    items.value = res.items
    total.value = res.total
    // Page out of range (e.g. edited URL): jump to the last page.
    if (res.items.length === 0 && res.total > 0 && page > totalPages(res.total)) {
      void router.replace({
        name: 'tickets',
        query: serializeListQuery({ ...query.value, page: totalPages(res.total) }),
      })
    }
  } catch (e) {
    if (mine === seq) error.value = e instanceof Error ? e.message : 'Failed to load tickets'
  } finally {
    if (mine === seq) loading.value = false
  }
}

watch(query, load, { immediate: true })
// Keep the input in sync with back/forward navigation
watch(
  () => query.value.q,
  (q) => {
    searchText.value = q
  },
)
</script>

<template>
  <div>
    <div class="row">
      <h1>Tickets</h1>
      <span class="spacer" />
      <RouterLink class="btn btn-primary" to="/tickets/new">New ticket</RouterLink>
    </div>

    <div class="row filters">
      <input
        v-model="searchText"
        type="search"
        placeholder="Search tickets…"
        aria-label="Search tickets"
        @input="onSearch"
      />
      <select
        :value="query.status"
        aria-label="Filter by status"
        @change="navigate({ status: ($event.target as HTMLSelectElement).value as ListQuery['status'], page: 1 })"
      >
        <option value="">All statuses</option>
        <option v-for="s in STATUSES" :key="s" :value="s">{{ statusLabel(s) }}</option>
      </select>
      <select
        :value="query.assigneeId"
        aria-label="Filter by assignee"
        @change="navigate({ assigneeId: ($event.target as HTMLSelectElement).value, page: 1 })"
      >
        <option value="">All assignees</option>
        <option value="none">Unassigned</option>
        <option v-for="u in users.users" :key="u.id" :value="u.id">{{ u.name }}</option>
        <option v-if="unknownAssignee" :value="query.assigneeId">Unknown user</option>
      </select>
    </div>

    <div v-if="closeError" class="alert" role="alert">{{ closeError }}</div>

    <div v-if="error" class="alert" role="alert">
      {{ error }} <button type="button" class="btn-small" @click="load">Retry</button>
    </div>
    <p v-else-if="loading && !items.length" class="muted">Loading tickets…</p>
    <p v-else-if="!items.length" class="card muted">No tickets match your filters.</p>
    <template v-else>
      <div class="card list" :aria-busy="loading">
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Status</th>
              <th>Priority</th>
              <th>Assignee</th>
              <th>Created</th>
              <th><span class="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="t in items" :key="t.id">
              <td>
                <RouterLink :to="{ name: 'ticket', params: { id: t.id } }">{{ t.title }}</RouterLink>
              </td>
              <td><TicketBadge kind="status" :value="t.status" /></td>
              <td><TicketBadge kind="priority" :value="t.priority" /></td>
              <td>{{ users.nameOf(t.assigneeId) }}</td>
              <td>{{ formatDate(t.createdAt) }}</td>
              <td>
                <button
                  type="button"
                  class="btn-small"
                  :disabled="t.status === 'closed' || closing.has(t.id)"
                  :aria-label="`Close ticket ${t.title}`"
                  @click="closeTicket(t)"
                >
                  Close ticket
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <nav class="row pager" aria-label="Pagination">
        <button type="button" :disabled="query.page <= 1" @click="navigate({ page: query.page - 1 })">
          Previous
        </button>
        <span>Page {{ query.page }} of {{ pages }} ({{ total }} tickets)</span>
        <button
          type="button"
          :disabled="query.page >= pages"
          @click="navigate({ page: query.page + 1 })"
        >
          Next
        </button>
      </nav>
    </template>
  </div>
</template>

<style scoped>
.filters {
  margin-bottom: 1rem;
}
.list[aria-busy='true'] {
  opacity: 0.6;
}
.pager {
  justify-content: center;
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
}
</style>
