<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { RouterLink, useRouter } from 'vue-router'
import { api } from '@/api'
import { ApiError } from '@/api/client'
import type { Ticket, TicketInput, TicketStatus } from '@/api/types'
import TicketForm from '@/components/TicketForm.vue'
import type { FieldErrors } from '@/utils/validation'

const props = defineProps<{ id?: string }>()
const router = useRouter()

const isEdit = computed(() => props.id !== undefined)
const ticket = ref<Ticket>()
const loading = ref(false)
const loadError = ref('')
const submitting = ref(false)
const serverErrors = ref<FieldErrors>({})
const formError = ref('')
let seq = 0

async function load() {
  ticket.value = undefined
  loadError.value = ''
  if (props.id === undefined) return
  const mine = ++seq
  loading.value = true
  try {
    const t = await api.getTicket(props.id)
    if (mine === seq) ticket.value = t
  } catch (e) {
    if (mine === seq) loadError.value = e instanceof Error ? e.message : 'Failed to load ticket'
  } finally {
    if (mine === seq) loading.value = false
  }
}
watch(() => props.id, load, { immediate: true })

async function save(values: TicketInput & { status?: TicketStatus }) {
  serverErrors.value = {}
  formError.value = ''
  submitting.value = true
  try {
    const saved =
      isEdit.value && props.id !== undefined
        ? await api.updateTicket(props.id, values)
        : await api.createTicket(values)
    await router.push({ name: 'ticket', params: { id: saved.id } })
  } catch (e) {
    if (e instanceof ApiError && e.status === 422) {
      serverErrors.value = e.errors
      formError.value = e.message
    } else {
      formError.value = e instanceof Error ? e.message : 'Failed to save ticket'
    }
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <div>
    <h1>{{ isEdit ? 'Edit ticket' : 'New ticket' }}</h1>
    <p v-if="loading" class="muted">Loading ticket…</p>
    <div v-else-if="loadError" class="alert" role="alert">
      {{ loadError }} <RouterLink to="/tickets">Back to tickets</RouterLink>
    </div>
    <div v-else class="card">
      <div v-if="formError" class="alert" role="alert">{{ formError }}</div>
      <TicketForm
        :key="ticket?.id ?? 'new'"
        :initial="ticket"
        :submitting="submitting"
        :server-errors="serverErrors"
        :submit-label="isEdit ? 'Save changes' : 'Create ticket'"
        @submit="save"
      />
    </div>
  </div>
</template>
