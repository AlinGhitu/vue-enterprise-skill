<script setup lang="ts">
import { ref, watch } from 'vue'
import { RouterLink } from 'vue-router'
import { api } from '@/api'
import type { Ticket } from '@/api/types'
import CommentSection from '@/components/CommentSection.vue'
import TicketBadge from '@/components/TicketBadge.vue'
import { useCloseTicket } from '@/composables/useCloseTicket'
import { useUsersStore } from '@/stores/users'
import { formatDateTime } from '@/utils/ticketQuery'

const props = defineProps<{ id: string }>()

const users = useUsersStore()
const ticket = ref<Ticket>()
const loading = ref(true)
const error = ref('')
const { closing, error: closeError, closeTicket } = useCloseTicket()
let seq = 0

async function load() {
  const mine = ++seq
  loading.value = true
  error.value = ''
  ticket.value = undefined
  try {
    const t = await api.getTicket(props.id)
    if (mine === seq) ticket.value = t
  } catch (e) {
    if (mine === seq) error.value = e instanceof Error ? e.message : 'Failed to load ticket'
  } finally {
    if (mine === seq) loading.value = false
  }
}

watch(() => props.id, load, { immediate: true })
void users.load()
</script>

<template>
  <div>
    <p><RouterLink to="/tickets">← All tickets</RouterLink></p>
    <p v-if="loading" class="muted">Loading ticket…</p>
    <div v-else-if="error" class="alert" role="alert">
      {{ error }} <button type="button" class="btn-small" @click="load">Retry</button>
    </div>
    <template v-else-if="ticket">
      <div class="card">
        <div class="row">
          <h1>{{ ticket.title }}</h1>
          <span class="spacer" />
          <RouterLink class="btn" :to="{ name: 'ticket-edit', params: { id: ticket.id } }"
            >Edit</RouterLink
          >
          <button
            type="button"
            :disabled="ticket.status === 'closed' || closing.has(ticket.id)"
            @click="closeTicket(ticket)"
          >
            Close ticket
          </button>
        </div>
        <div v-if="closeError" class="alert" role="alert">{{ closeError }}</div>
        <dl class="fields">
          <dt>ID</dt>
          <dd>#{{ ticket.id }}</dd>
          <dt>Status</dt>
          <dd><TicketBadge kind="status" :value="ticket.status" /></dd>
          <dt>Priority</dt>
          <dd><TicketBadge kind="priority" :value="ticket.priority" /></dd>
          <dt>Assignee</dt>
          <dd>{{ users.nameOf(ticket.assigneeId) }}</dd>
          <dt>Created</dt>
          <dd>{{ formatDateTime(ticket.createdAt) }}</dd>
          <dt>Updated</dt>
          <dd>{{ formatDateTime(ticket.updatedAt) }}</dd>
          <dt>Description</dt>
          <dd class="description">{{ ticket.description }}</dd>
        </dl>
      </div>
      <CommentSection :ticket-id="ticket.id" />
    </template>
  </div>
</template>

<style scoped>
.fields {
  display: grid;
  grid-template-columns: 8rem 1fr;
  gap: 0.5rem 1rem;
  margin: 0;
}
dt {
  color: var(--c-muted);
}
dd {
  margin: 0;
}
.description {
  white-space: pre-wrap;
}
</style>
