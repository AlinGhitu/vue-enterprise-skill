<script setup lang="ts">
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { ApiError } from '@/api/client'
import { safeRedirect } from '@/utils/ticketQuery'
import { validateLogin, type FieldErrors } from '@/utils/validation'

const auth = useAuthStore()
const route = useRoute()
const router = useRouter()

const email = ref('')
const password = ref('')
const errors = ref<FieldErrors>({})
const formError = ref('')
const submitting = ref(false)

async function submit() {
  formError.value = ''
  errors.value = validateLogin(email.value, password.value)
  if (Object.keys(errors.value).length) return
  submitting.value = true
  try {
    await auth.login(email.value, password.value)
    await router.replace(safeRedirect(route.query.redirect))
  } catch (e) {
    if (e instanceof ApiError && e.status === 401) formError.value = 'Invalid email or password'
    else formError.value = e instanceof Error ? e.message : 'Login failed'
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <div class="card login">
    <h1>Sign in</h1>
    <form novalidate @submit.prevent="submit">
      <div v-if="formError" class="alert" role="alert">{{ formError }}</div>
      <div class="field">
        <label for="email">Email</label>
        <input
          id="email"
          v-model="email"
          type="email"
          autocomplete="username"
          :aria-invalid="!!errors.email"
        />
        <span v-if="errors.email" class="error-text" role="alert">{{ errors.email }}</span>
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input
          id="password"
          v-model="password"
          type="password"
          autocomplete="current-password"
          :aria-invalid="!!errors.password"
        />
        <span v-if="errors.password" class="error-text" role="alert">{{ errors.password }}</span>
      </div>
      <button type="submit" class="btn btn-primary" :disabled="submitting">
        {{ submitting ? 'Signing in…' : 'Sign in' }}
      </button>
    </form>
  </div>
</template>

<style scoped>
.login {
  max-width: 380px;
  margin: 4rem auto;
}
</style>
