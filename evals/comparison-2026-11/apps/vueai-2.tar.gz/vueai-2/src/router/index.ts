import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

declare module 'vue-router' {
  interface RouteMeta {
    public?: boolean
  }
}

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      name: 'login',
      meta: { public: true },
      component: () => import('../views/LoginView.vue'),
    },
    { path: '/', redirect: { name: 'tickets' } },
    {
      path: '/tickets',
      name: 'tickets',
      component: () => import('../views/TicketListView.vue'),
    },
    {
      path: '/tickets/new',
      name: 'ticket-new',
      component: () => import('../views/TicketFormView.vue'),
    },
    {
      path: '/tickets/:id',
      name: 'ticket',
      component: () => import('../views/TicketDetailView.vue'),
      props: true,
    },
    {
      path: '/tickets/:id/edit',
      name: 'ticket-edit',
      component: () => import('../views/TicketFormView.vue'),
      props: true,
    },
    { path: '/:pathMatch(.*)*', redirect: { name: 'tickets' } },
  ],
})

router.beforeEach(async (to) => {
  if (to.meta.public) return true
  const auth = useAuthStore()
  if (!auth.isAuthenticated || !(await auth.restore())) {
    return { name: 'login', query: { redirect: to.fullPath } }
  }
  return true
})

export default router
