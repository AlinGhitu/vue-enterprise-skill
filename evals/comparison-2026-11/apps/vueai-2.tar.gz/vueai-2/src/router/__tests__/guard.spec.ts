import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { tokenStorage } from '@/api/client'
import { api } from '@/api'

vi.mock('@/api', () => ({
  api: {
    login: vi.fn<() => unknown>(),
    logout: vi.fn<() => unknown>(),
    me: vi.fn<() => unknown>(),
  },
}))

describe('auth route guard', () => {
  beforeEach(() => {
    localStorage.clear()
    setActivePinia(createPinia())
    vi.resetModules()
  })

  it('redirects anonymous users to login with the wanted page', async () => {
    const { default: router } = await import('../index')
    await router.push('/tickets/5?x=1')
    expect(router.currentRoute.value.name).toBe('login')
    expect(router.currentRoute.value.query.redirect).toBe('/tickets/5?x=1')
  })

  it('lets authenticated users through', async () => {
    tokenStorage.set('tok')
    setActivePinia(createPinia())
    vi.mocked(api.me).mockResolvedValue({ id: 'u1', name: 'D', email: 'd@x.co' })
    const { default: router } = await import('../index')
    await router.push('/tickets/5')
    expect(router.currentRoute.value.name).toBe('ticket')
  })
})
