const TOKEN_KEY = 'support-desk-token'

export class ApiError extends Error {
  readonly status: number
  readonly errors: Record<string, string>

  constructor(status: number, message: string, errors: Record<string, string> = {}) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.errors = errors
  }
}

export const tokenStorage = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (token: string) => localStorage.setItem(TOKEN_KEY, token),
  clear: () => localStorage.removeItem(TOKEN_KEY),
}

let unauthorizedHandler: (() => void) | null = null

/** Called when an authenticated request is rejected with 401. */
export function setUnauthorizedHandler(handler: (() => void) | null) {
  unauthorizedHandler = handler
}

interface RequestOptions {
  body?: unknown
  query?: Record<string, string | number | undefined>
}

export async function request<T>(
  method: string,
  path: string,
  { body, query }: RequestOptions = {},
): Promise<T> {
  const params = new URLSearchParams()
  for (const [key, value] of Object.entries(query ?? {})) {
    if (value !== undefined && value !== '') params.set(key, String(value))
  }
  const qs = params.toString()
  const token = tokenStorage.get()
  const headers: Record<string, string> = {}
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (token) headers.Authorization = `Bearer ${token}`

  let res: Response
  try {
    res = await fetch(`/api${path}${qs ? `?${qs}` : ''}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    })
  } catch {
    throw new ApiError(0, 'Network error. Check your connection and try again.')
  }

  if (res.ok) {
    if (res.status === 204) return undefined as T
    return (await res.json()) as T
  }

  let data: { message?: string; errors?: Record<string, string> } = {}
  try {
    data = await res.json()
  } catch {
    // non-JSON error body
  }
  if (res.status === 401 && token) unauthorizedHandler?.()
  throw new ApiError(res.status, data.message ?? `Request failed (${res.status})`, data.errors)
}
