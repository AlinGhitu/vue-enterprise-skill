import { request } from './client'
import type {
  Comment,
  Ticket,
  TicketInput,
  TicketPage,
  TicketPatch,
  TicketStatus,
  User,
} from './types'

export interface TicketListParams {
  q?: string
  status?: TicketStatus | ''
  assigneeId?: string
  page?: number
  pageSize?: number
}

const ticketPath = (id: string) => `/tickets/${encodeURIComponent(id)}`

export const api = {
  login: (email: string, password: string) =>
    request<{ token: string; user: User }>('POST', '/login', { body: { email, password } }),
  logout: () => request<void>('POST', '/logout'),
  me: () => request<User>('GET', '/me'),
  users: () => request<User[]>('GET', '/users'),
  listTickets: (params: TicketListParams) =>
    request<TicketPage>('GET', '/tickets', { query: { ...params } }),
  getTicket: (id: string) => request<Ticket>('GET', ticketPath(id)),
  createTicket: (input: TicketInput) => request<Ticket>('POST', '/tickets', { body: input }),
  updateTicket: (id: string, patch: TicketPatch) =>
    request<Ticket>('PATCH', ticketPath(id), { body: patch }),
  closeTicket: (id: string) =>
    request<Ticket>('PATCH', ticketPath(id), { body: { status: 'closed' } }),
  listComments: (id: string) => request<Comment[]>('GET', `${ticketPath(id)}/comments`),
  addComment: (id: string, body: string) =>
    request<Comment>('POST', `${ticketPath(id)}/comments`, { body: { body } }),
}
