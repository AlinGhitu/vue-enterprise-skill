<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{ kind: 'status' | 'priority'; value: string }>()

const label = computed(() => {
  const text = props.value.replace('_', ' ')
  return text.charAt(0).toUpperCase() + text.slice(1)
})
</script>

<template>
  <span class="badge" :class="`badge-${value}`">{{ label }}</span>
</template>
