<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { PRIORITIES, STATUSES, type Ticket, type TicketInput, type TicketStatus } from '@/api/types'
import { useUsersStore } from '@/stores/users'
import { validateTicketInput, type FieldErrors } from '@/utils/validation'
import { statusLabel } from '@/utils/ticketQuery'

const props = defineProps<{
  initial?: Ticket
  submitting: boolean
  serverErrors: FieldErrors
  submitLabel: string
}>()

const emit = defineEmits<{
  submit: [values: TicketInput & { status?: TicketStatus }]
}>()

const users = useUsersStore()
void users.load()

const values = reactive({
  title: props.initial?.title ?? '',
  description: props.initial?.description ?? '',
  priority: props.initial?.priority ?? 'medium',
  assigneeId: props.initial?.assigneeId ?? '',
  status: props.initial?.status ?? 'open',
})
const clientErrors = ref<FieldErrors>({})
const touched = ref(false)

// Client errors win once the user has tried to submit; otherwise show what the API said.
const errors = computed<FieldErrors>(() => ({ ...props.serverErrors, ...clientErrors.value }))

function onInput() {
  // Re-validate live after the first submit attempt
  if (touched.value) clientErrors.value = validateTicketInput(toInput())
}

function toInput(): TicketInput {
  return {
    title: values.title,
    description: values.description,
    priority: values.priority,
    assigneeId: values.assigneeId || null,
  }
}

function onSubmit() {
  touched.value = true
  clientErrors.value = validateTicketInput(toInput())
  if (Object.keys(clientErrors.value).length) return
  emit('submit', props.initial ? { ...toInput(), status: values.status } : toInput())
}
</script>

<template>
  <form novalidate @submit.prevent="onSubmit">
    <div class="field">
      <label for="title">Title</label>
      <input
        id="title"
        v-model="values.title"
        :aria-invalid="!!errors.title"
        aria-describedby="title-error"
        @input="onInput"
      />
      <span v-if="errors.title" id="title-error" class="error-text" role="alert">{{
        errors.title
      }}</span>
    </div>

    <div class="field">
      <label for="description">Description</label>
      <textarea
        id="description"
        v-model="values.description"
        rows="6"
        :aria-invalid="!!errors.description"
        aria-describedby="description-error"
        @input="onInput"
      />
      <span v-if="errors.description" id="description-error" class="error-text" role="alert">{{
        errors.description
      }}</span>
    </div>

    <div class="row">
      <div class="field">
        <label for="priority">Priority</label>
        <select
          id="priority"
          v-model="values.priority"
          :aria-invalid="!!errors.priority"
          @change="onInput"
        >
          <option v-for="p in PRIORITIES" :key="p" :value="p">{{ p }}</option>
        </select>
        <span v-if="errors.priority" class="error-text" role="alert">{{ errors.priority }}</span>
      </div>

      <div class="field">
        <label for="assignee">Assignee</label>
        <select id="assignee" v-model="values.assigneeId" :aria-invalid="!!errors.assigneeId">
          <option value="">Unassigned</option>
          <option v-for="u in users.users" :key="u.id" :value="u.id">{{ u.name }}</option>
        </select>
        <span v-if="errors.assigneeId" class="error-text" role="alert">{{
          errors.assigneeId
        }}</span>
      </div>

      <div v-if="initial" class="field">
        <label for="status">Status</label>
        <select id="status" v-model="values.status" :aria-invalid="!!errors.status">
          <option v-for="s in STATUSES" :key="s" :value="s">{{ statusLabel(s) }}</option>
        </select>
        <span v-if="errors.status" class="error-text" role="alert">{{ errors.status }}</span>
      </div>
    </div>

    <button type="submit" class="btn-primary btn" :disabled="submitting">
      {{ submitting ? 'Saving…' : submitLabel }}
    </button>
  </form>
</template>
