<script setup lang="ts">
import { ref, watch } from 'vue'
import { api } from '@/api'
import { ApiError } from '@/api/client'
import type { Comment } from '@/api/types'
import { useUsersStore } from '@/stores/users'
import { formatDateTime } from '@/utils/ticketQuery'
import { validateComment } from '@/utils/validation'

const props = defineProps<{ ticketId: string }>()

const users = useUsersStore()
const comments = ref<Comment[]>([])
const loading = ref(true)
const loadError = ref('')
const body = ref('')
const bodyError = ref('')
const submitError = ref('')
const submitting = ref(false)
let loadSeq = 0

async function load() {
  const seq = ++loadSeq
  loading.value = true
  loadError.value = ''
  comments.value = []
  try {
    const list = await api.listComments(props.ticketId)
    if (seq === loadSeq) comments.value = list
  } catch (e) {
    if (seq === loadSeq) loadError.value = e instanceof Error ? e.message : 'Failed to load'
  } finally {
    if (seq === loadSeq) loading.value = false
  }
}

watch(() => props.ticketId, load, { immediate: true })
void users.load()

async function submit() {
  submitError.value = ''
  bodyError.value = validateComment(body.value).body ?? ''
  if (bodyError.value) return
  submitting.value = true
  try {
    const created = await api.addComment(props.ticketId, body.value)
    comments.value.push(created)
    body.value = ''
  } catch (e) {
    if (e instanceof ApiError && e.errors.body) bodyError.value = e.errors.body
    else submitError.value = e instanceof Error ? e.message : 'Failed to add comment'
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <section aria-labelledby="comments-heading">
    <h2 id="comments-heading">Comments</h2>
    <p v-if="loading" class="muted">Loading comments…</p>
    <div v-else-if="loadError" class="alert" role="alert">
      {{ loadError }} <button type="button" class="btn-small" @click="load">Retry</button>
    </div>
    <p v-else-if="!comments.length" class="muted">No comments yet.</p>
    <ul v-else class="comments">
      <li v-for="c in comments" :key="c.id" class="card">
        <strong>{{ users.nameOf(c.authorId) }}</strong>
        <span class="muted"> · {{ formatDateTime(c.createdAt) }}</span>
        <p class="body">{{ c.body }}</p>
      </li>
    </ul>

    <form novalidate @submit.prevent="submit">
      <div class="field">
        <label for="comment">Add a comment</label>
        <textarea
          id="comment"
          v-model="body"
          rows="3"
          :aria-invalid="!!bodyError"
          @input="bodyError = ''"
        />
        <span v-if="bodyError" class="error-text" role="alert">{{ bodyError }}</span>
      </div>
      <div v-if="submitError" class="alert" role="alert">{{ submitError }}</div>
      <button type="submit" class="btn btn-primary" :disabled="submitting">
        {{ submitting ? 'Posting…' : 'Add comment' }}
      </button>
    </form>
  </section>
</template>

<style scoped>
.comments {
  list-style: none;
  padding: 0;
}
.body {
  margin: 0.25rem 0 0;
  white-space: pre-wrap;
}
</style>
