import { PRIORITIES, type TicketInput } from '@/api/types'

export type FieldErrors = Partial<Record<string, string>>

export const TITLE_MIN = 5
export const TITLE_MAX = 120
export const DESCRIPTION_MIN = 10

/** Mirrors the API rules (see API.md). */
export function validateTicketInput(values: TicketInput): FieldErrors {
  const errors: FieldErrors = {}
  if (values.title.trim().length < TITLE_MIN || values.title.length > TITLE_MAX) {
    errors.title = `Title must be ${TITLE_MIN}-${TITLE_MAX} characters`
  }
  if (values.description.trim().length < DESCRIPTION_MIN) {
    errors.description = `Description must be at least ${DESCRIPTION_MIN} characters`
  }
  if (!PRIORITIES.includes(values.priority)) errors.priority = 'Unknown priority'
  return errors
}

export function validateComment(body: string): FieldErrors {
  return body.trim() ? {} : { body: 'Comment cannot be empty' }
}

export function validateLogin(email: string, password: string): FieldErrors {
  const errors: FieldErrors = {}
  if (!email.trim()) errors.email = 'Email is required'
  else if (!/^\S+@\S+\.\S+$/.test(email.trim())) errors.email = 'Enter a valid email address'
  if (!password) errors.password = 'Password is required'
  return errors
}
