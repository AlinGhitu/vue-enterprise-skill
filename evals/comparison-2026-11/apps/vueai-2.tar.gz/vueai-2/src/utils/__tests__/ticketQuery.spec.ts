import { describe, expect, it } from 'vitest'
import { parseListQuery, safeRedirect, serializeListQuery, totalPages } from '../ticketQuery'

describe('parseListQuery', () => {
  it('uses defaults', () => {
    expect(parseListQuery({})).toEqual({ q: '', status: '', assigneeId: '', page: 1 })
  })
  it('parses valid values and sanitizes invalid ones', () => {
    expect(
      parseListQuery({ q: 'vat', status: 'closed', assigneeId: 'none', page: '3' }),
    ).toEqual({
      q: 'vat',
      status: 'closed',
      assigneeId: 'none',
      page: 3,
    })
    expect(parseListQuery({ assigneeId: 'u2' }).assigneeId).toBe('u2')
    expect(parseListQuery({ status: 'bogus', page: '-2' })).toMatchObject({ status: '', page: 1 })
    expect(parseListQuery({ page: 'abc' }).page).toBe(1)
    expect(parseListQuery({ page: '1.5' }).page).toBe(1)
  })
})

describe('serializeListQuery', () => {
  it('omits defaults', () => {
    expect(serializeListQuery({ q: ' ', status: '', assigneeId: '', page: 1 })).toEqual({})
    expect(
      serializeListQuery({ q: 'a', status: 'open', assigneeId: 'none', page: 2 }),
    ).toEqual({
      q: 'a',
      status: 'open',
      assigneeId: 'none',
      page: '2',
    })
  })
})

describe('totalPages', () => {
  it('rounds up and is at least 1', () => {
    expect(totalPages(0)).toBe(1)
    expect(totalPages(10)).toBe(1)
    expect(totalPages(11)).toBe(2)
    expect(totalPages(57)).toBe(6)
  })
})

describe('safeRedirect', () => {
  it('allows in-app paths', () => {
    expect(safeRedirect('/tickets/4?x=1')).toBe('/tickets/4?x=1')
  })
  it('rejects external, protocol-relative and login targets', () => {
    expect(safeRedirect('https://evil.com')).toBe('/')
    expect(safeRedirect('//evil.com')).toBe('/')
    expect(safeRedirect('/login')).toBe('/')
    expect(safeRedirect(undefined)).toBe('/')
    expect(safeRedirect(['/a'])).toBe('/')
  })
})
