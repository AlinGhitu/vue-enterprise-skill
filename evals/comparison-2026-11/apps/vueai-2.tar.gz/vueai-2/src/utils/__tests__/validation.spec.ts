import { describe, expect, it } from 'vitest'
import type { TicketInput } from '@/api/types'
import { validateComment, validateLogin, validateTicketInput } from '../validation'

const valid: TicketInput = {
  title: 'Hello world',
  description: 'A long enough description',
  priority: 'low',
  assigneeId: null,
}

describe('validateTicketInput', () => {
  it('accepts valid input', () => {
    expect(validateTicketInput(valid)).toEqual({})
  })

  it('enforces title length 5-120 (trimmed minimum)', () => {
    expect(validateTicketInput({ ...valid, title: 'abcd' }).title).toBeDefined()
    expect(validateTicketInput({ ...valid, title: '  ab  ' }).title).toBeDefined()
    expect(validateTicketInput({ ...valid, title: 'abcde' }).title).toBeUndefined()
    expect(validateTicketInput({ ...valid, title: 'a'.repeat(120) }).title).toBeUndefined()
    expect(validateTicketInput({ ...valid, title: 'a'.repeat(121) }).title).toBeDefined()
  })

  it('requires a description of at least 10 characters', () => {
    expect(validateTicketInput({ ...valid, description: '123456789' }).description).toBeDefined()
    expect(validateTicketInput({ ...valid, description: '1234567890' }).description).toBeUndefined()
    expect(validateTicketInput({ ...valid, description: '   short   ' }).description).toBeDefined()
  })
})

describe('validateComment / validateLogin', () => {
  it('rejects blank comments', () => {
    expect(validateComment('   ').body).toBeDefined()
    expect(validateComment('hi')).toEqual({})
  })

  it('validates email and password', () => {
    expect(validateLogin('', '').email).toBeDefined()
    expect(validateLogin('nope', 'x').email).toBeDefined()
    expect(validateLogin('a@b.co', '').password).toBeDefined()
    expect(validateLogin('a@b.co', 'x')).toEqual({})
  })
})
