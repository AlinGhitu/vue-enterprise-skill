import { STATUSES, type TicketStatus } from '@/api/types'

export const PAGE_SIZE = 10

export interface ListQuery {
  q: string
  status: TicketStatus | ''
  /** '' = any user, 'none' = unassigned, otherwise a user id */
  assigneeId: string
  page: number
}

type RawQuery = Record<string, string | null | (string | null)[] | undefined>

const first = (v: RawQuery[string]) => (Array.isArray(v) ? v[0] : v) ?? ''

/** Parses (untrusted) route query into a valid list query. */
export function parseListQuery(raw: RawQuery): ListQuery {
  const status = first(raw.status)
  const page = Number(first(raw.page))
  return {
    q: first(raw.q),
    assigneeId: first(raw.assigneeId),
    status: (STATUSES as string[]).includes(status) ? (status as TicketStatus) : '',
    page: Number.isInteger(page) && page >= 1 ? page : 1,
  }
}

/** Builds a minimal route query (omits defaults). */
export function serializeListQuery(query: ListQuery): Record<string, string> {
  const out: Record<string, string> = {}
  if (query.q.trim()) out.q = query.q.trim()
  if (query.status) out.status = query.status
  if (query.assigneeId) out.assigneeId = query.assigneeId
  if (query.page > 1) out.page = String(query.page)
  return out
}

export function totalPages(total: number, pageSize = PAGE_SIZE) {
  return Math.max(1, Math.ceil(total / pageSize))
}

/** Only allow in-app, non-login redirect targets. */
export function safeRedirect(target: unknown): string {
  if (typeof target !== 'string') return '/'
  if (!target.startsWith('/') || target.startsWith('//') || target.startsWith('/\\')) return '/'
  if (target === '/login' || target.startsWith('/login?')) return '/'
  return target
}

const STATUS_LABELS: Record<TicketStatus, string> = {
  open: 'Open',
  in_progress: 'In progress',
  closed: 'Closed',
}
export const statusLabel = (s: TicketStatus) => STATUS_LABELS[s]

export function formatDate(iso: string) {
  const d = new Date(iso)
  return Number.isNaN(d.getTime())
    ? iso
    : d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })
}

export function formatDateTime(iso: string) {
  const d = new Date(iso)
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString()
}
