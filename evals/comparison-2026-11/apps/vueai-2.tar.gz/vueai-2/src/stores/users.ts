import { ref } from 'vue'
import { defineStore } from 'pinia'
import { api } from '@/api'
import type { User } from '@/api/types'

export const useUsersStore = defineStore('users', () => {
  const users = ref<User[]>([])
  const loaded = ref(false)
  let pending: Promise<void> | null = null

  function load(): Promise<void> {
    if (loaded.value) return Promise.resolve()
    pending ??= api
      .users()
      .then((list) => {
        users.value = list
        loaded.value = true
      })
      .catch(() => {
        // names fall back to a placeholder; a later load() retries
      })
      .finally(() => {
        pending = null
      })
    return pending
  }

  function nameOf(id: string | null | undefined): string {
    if (!id) return 'Unassigned'
    return users.value.find((u) => u.id === id)?.name ?? 'Unknown user'
  }

  function reset() {
    users.value = []
    loaded.value = false
  }

  return { users, loaded, load, nameOf, reset }
})
