import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { api } from '@/api'
import { tokenStorage } from '@/api/client'
import type { User } from '@/api/types'

export const useAuthStore = defineStore('auth', () => {
  const token = ref<string | null>(tokenStorage.get())
  const user = ref<User | null>(null)
  const isAuthenticated = computed(() => token.value !== null)

  async function login(email: string, password: string) {
    const res = await api.login(email.trim(), password)
    tokenStorage.set(res.token)
    token.value = res.token
    user.value = res.user
  }

  /** Forget the session locally (no request). */
  function clear() {
    tokenStorage.clear()
    token.value = null
    user.value = null
  }

  async function logout() {
    try {
      await api.logout()
    } catch {
      // the local session is dropped regardless
    }
    clear()
  }

  /** Loads the current user for a stored token. Clears the session if it is invalid. */
  async function restore(): Promise<boolean> {
    if (!token.value) return false
    if (user.value) return true
    try {
      user.value = await api.me()
      return true
    } catch {
      clear()
      return false
    }
  }

  return { token, user, isAuthenticated, login, logout, clear, restore }
})
