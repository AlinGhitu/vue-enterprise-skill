import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { api } from '@/api'
import { tokenStorage } from '@/api/client'
import { useAuthStore } from '../auth'

vi.mock('@/api', () => ({
  api: {
    login: vi.fn<() => unknown>(),
    logout: vi.fn<() => unknown>(),
    me: vi.fn<() => unknown>(),
  },
}))

const user = { id: 'u1', name: 'Dana', email: 'd@x.co' }

describe('auth store', () => {
  beforeEach(() => {
    localStorage.clear()
    setActivePinia(createPinia())
    vi.resetAllMocks()
  })

  it('stores the token on login and clears it on logout', async () => {
    vi.mocked(api.login).mockResolvedValue({ token: 'tok', user })
    vi.mocked(api.logout).mockRejectedValue(new Error('offline'))
    const auth = useAuthStore()

    await auth.login(' d@x.co ', 'pw')
    expect(api.login).toHaveBeenCalledWith('d@x.co', 'pw')
    expect(auth.isAuthenticated).toBe(true)
    expect(tokenStorage.get()).toBe('tok')

    await auth.logout()
    expect(auth.isAuthenticated).toBe(false)
    expect(tokenStorage.get()).toBeNull()
  })

  it('restore loads the user for a stored token, and drops invalid tokens', async () => {
    tokenStorage.set('stored')
    setActivePinia(createPinia())
    const auth = useAuthStore()
    vi.mocked(api.me).mockResolvedValueOnce(user)
    expect(await auth.restore()).toBe(true)
    expect(auth.user).toEqual(user)

    setActivePinia(createPinia())
    const other = useAuthStore()
    vi.mocked(api.me).mockRejectedValueOnce(new Error('401'))
    expect(await other.restore()).toBe(false)
    expect(other.isAuthenticated).toBe(false)
    expect(tokenStorage.get()).toBeNull()
  })
})
