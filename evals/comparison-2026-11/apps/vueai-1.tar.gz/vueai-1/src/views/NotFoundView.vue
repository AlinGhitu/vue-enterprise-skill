<template>
  <main>
    <h1>Page not found</h1>
    <RouterLink :to="{ name: 'tickets' }">Back to tickets</RouterLink>
  </main>
</template>
