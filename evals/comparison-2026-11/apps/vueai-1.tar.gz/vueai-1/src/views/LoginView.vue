<script setup lang="ts">
import { shallowRef } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { safeRedirect } from '@/router/guard'
import { useAuthStore } from '@/stores/auth'
import { errorMessage } from '@/utils/format'

const auth = useAuthStore()
const route = useRoute()
const router = useRouter()

const email = shallowRef('')
const password = shallowRef('')
const error = shallowRef<string | null>(null)
const submitting = shallowRef(false)

async function onSubmit() {
  if (!email.value.trim() || !password.value) {
    error.value = 'Enter your email and password'
    return
  }
  error.value = null
  submitting.value = true
  try {
    await auth.login(email.value.trim(), password.value)
    await router.replace(safeRedirect(route.query.redirect))
  } catch (e) {
    error.value = errorMessage(e)
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <main class="login">
    <h1>Support Desk</h1>
    <form novalidate @submit.prevent="onSubmit">
      <p v-if="error" role="alert" class="error">{{ error }}</p>
      <label>
        Email
        <input v-model="email" name="email" type="email" autocomplete="username" />
      </label>
      <label>
        Password
        <input v-model="password" name="password" type="password" autocomplete="current-password" />
      </label>
      <button type="submit" :disabled="submitting">
        {{ submitting ? 'Signing in…' : 'Sign in' }}
      </button>
    </form>
  </main>
</template>

<style scoped>
.login {
  max-width: 22rem;
  margin: 4rem auto;
}
form {
  display: grid;
  gap: 1rem;
}
label {
  display: grid;
  gap: 0.25rem;
}
.error {
  color: #b91c1c;
}
</style>
