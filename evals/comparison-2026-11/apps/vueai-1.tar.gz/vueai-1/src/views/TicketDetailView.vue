<script setup lang="ts">
import { shallowRef, watch } from 'vue'
import { api } from '@/api'
import { ApiError } from '@/api/client'
import type { Ticket } from '@/api/types'
import CommentSection from '@/components/CommentSection.vue'
import StatusBadge from '@/components/StatusBadge.vue'
import { useCloseTicket } from '@/composables/useCloseTicket'
import { useUsers } from '@/composables/useUsers'
import { errorMessage, formatDateTime } from '@/utils/format'

const props = defineProps<{ id: string }>()

const { nameOf } = useUsers()
const ticket = shallowRef<Ticket | null>(null)
const loading = shallowRef(false)
const error = shallowRef<string | null>(null)
const notFound = shallowRef(false)
const {
  close,
  closingIds,
  error: closeError,
} = useCloseTicket((t) => {
  ticket.value = t
})

let seq = 0
async function load() {
  const n = ++seq
  loading.value = true
  error.value = null
  notFound.value = false
  ticket.value = null
  try {
    const res = await api.getTicket(props.id)
    if (n === seq) ticket.value = res
  } catch (e) {
    if (n !== seq) return
    if (e instanceof ApiError && e.status === 404) notFound.value = true
    else error.value = errorMessage(e)
  } finally {
    if (n === seq) loading.value = false
  }
}
watch(() => props.id, load, { immediate: true })
</script>

<template>
  <main>
    <RouterLink :to="{ name: 'tickets' }">← All tickets</RouterLink>

    <p v-if="loading">Loading ticket…</p>
    <p v-else-if="notFound" role="alert">Ticket not found.</p>
    <p v-else-if="error" role="alert" class="error">
      {{ error }} <button type="button" @click="load">Retry</button>
    </p>
    <template v-else-if="ticket">
      <h1>{{ ticket.title }}</h1>
      <p v-if="closeError" role="alert" class="error">{{ closeError }}</p>
      <div class="actions">
        <RouterLink :to="{ name: 'ticket-edit', params: { id: ticket.id } }">Edit</RouterLink>
        <button
          v-if="ticket.status !== 'closed'"
          type="button"
          :disabled="closingIds.has(ticket.id)"
          @click="close(ticket)"
        >
          Close ticket
        </button>
      </div>
      <dl>
        <dt>ID</dt>
        <dd>{{ ticket.id }}</dd>
        <dt>Status</dt>
        <dd><StatusBadge :status="ticket.status" /></dd>
        <dt>Priority</dt>
        <dd>{{ ticket.priority }}</dd>
        <dt>Assignee</dt>
        <dd>{{ nameOf(ticket.assigneeId) }}</dd>
        <dt>Created</dt>
        <dd>{{ formatDateTime(ticket.createdAt) }}</dd>
        <dt>Updated</dt>
        <dd>{{ formatDateTime(ticket.updatedAt) }}</dd>
        <dt>Description</dt>
        <dd class="desc">{{ ticket.description }}</dd>
      </dl>
      <CommentSection :ticket-id="ticket.id" />
    </template>
  </main>
</template>

<style scoped>
.actions {
  display: flex;
  gap: 1rem;
  align-items: center;
}
dl {
  display: grid;
  grid-template-columns: max-content 1fr;
  gap: 0.4rem 1rem;
}
dt {
  font-weight: 600;
}
dd {
  margin: 0;
}
.desc {
  white-space: pre-wrap;
}
.error {
  color: #b91c1c;
}
</style>
