<script setup lang="ts">
import { computed, shallowRef, watch } from 'vue'
import { useRouter } from 'vue-router'
import { api } from '@/api'
import type { Ticket, TicketInput } from '@/api/types'
import TicketForm from '@/components/TicketForm.vue'
import { errorMessage } from '@/utils/format'

// `id` is present on the edit route only.
const props = defineProps<{ id?: string }>()
const router = useRouter()

const ticket = shallowRef<Ticket | null>(null)
const loading = shallowRef(false)
const error = shallowRef<string | null>(null)
const editing = computed(() => props.id !== undefined)

let seq = 0
async function load() {
  ticket.value = null
  error.value = null
  if (props.id === undefined) return
  const n = ++seq
  loading.value = true
  try {
    const res = await api.getTicket(props.id)
    if (n === seq) ticket.value = res
  } catch (e) {
    if (n === seq) error.value = errorMessage(e)
  } finally {
    if (n === seq) loading.value = false
  }
}
watch(() => props.id, load, { immediate: true })

async function submit(input: TicketInput) {
  const saved = props.id ? await api.updateTicket(props.id, input) : await api.createTicket(input)
  await router.push({ name: 'ticket', params: { id: saved.id } })
}

function cancel() {
  void router.back()
}
</script>

<template>
  <main>
    <h1>{{ editing ? 'Edit ticket' : 'New ticket' }}</h1>
    <p v-if="loading">Loading ticket…</p>
    <p v-else-if="error" role="alert" class="error">
      {{ error }} <button type="button" @click="load">Retry</button>
    </p>
    <TicketForm
      v-else-if="!editing || ticket"
      :key="ticket?.id ?? 'new'"
      :initial="ticket ?? undefined"
      :editing="editing"
      :submit="submit"
      @cancel="cancel"
    />
  </main>
</template>

<style scoped>
.error {
  color: #b91c1c;
}
</style>
