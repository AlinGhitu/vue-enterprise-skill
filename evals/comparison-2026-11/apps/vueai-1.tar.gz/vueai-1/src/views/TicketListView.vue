<script setup lang="ts">
import { computed, onBeforeUnmount, shallowRef, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import StatusBadge from '@/components/StatusBadge.vue'
import { useCloseTicket } from '@/composables/useCloseTicket'
import { useTicketList } from '@/composables/useTicketList'
import { useUsers } from '@/composables/useUsers'
import type { TicketStatus } from '@/api/types'
import { formatDate, STATUS_LABELS } from '@/utils/format'
import {
  parseListQuery,
  serializeListQuery,
  UNASSIGNED,
  type ListFilters,
} from '@/utils/ticketQuery'

const route = useRoute()
const router = useRouter()
const { users, nameOf } = useUsers()

// Filters live in the URL so they survive reloads and back/forward.
const query = computed(() => parseListQuery(route.query))

const { items, total, pageCount, loading, error, reload, replaceTicket } = useTicketList(query)
const { close, closingIds, error: closeError } = useCloseTicket(replaceTicket)

const search = shallowRef(query.value.q)
let timer: ReturnType<typeof setTimeout> | undefined
watch(search, (value) => {
  clearTimeout(timer)
  if (value === query.value.q) return
  timer =setTimeout(() => setFilters({ q: value }), 300)
})
watch(
  () => query.value.q,
  (q) => {
    if (q !== search.value) search.value = q
  },
)
onBeforeUnmount(() => clearTimeout(timer))

function setFilters(next: Partial<ListFilters>) {
  void router.push({ query: serializeListQuery({ ...query.value, page: 1, ...next }) })
}

// Clamp a page beyond the last one (e.g. after filtering).
watch([pageCount, loading], () => {
  if (!loading.value && !error.value && query.value.page > pageCount.value) {
    setFilters({ page: pageCount.value })
  }
})
</script>

<template>
  <main>
    <div class="head">
      <h1>Tickets</h1>
      <RouterLink :to="{ name: 'ticket-new' }">New ticket</RouterLink>
    </div>

    <div class="filters">
      <input v-model="search" type="search" placeholder="Search tickets…" aria-label="Search" />
      <select
        :value="query.status"
        aria-label="Status filter"
        @change="setFilters({ status: ($event.target as HTMLSelectElement).value as TicketStatus | '' })"
      >
        <option value="">All statuses</option>
        <option v-for="(label, value) in STATUS_LABELS" :key="value" :value="value">
          {{ label }}
        </option>
      </select>
      <select
        :value="query.assigneeId"
        aria-label="Assignee filter"
        @change="setFilters({ assigneeId: ($event.target as HTMLSelectElement).value })"
      >
        <option value="">Any assignee</option>
        <option :value="UNASSIGNED">Unassigned</option>
        <option v-for="u in users" :key="u.id" :value="u.id">{{ u.name }}</option>
      </select>
    </div>

    <p v-if="closeError" role="alert" class="error">{{ closeError }}</p>

    <p v-if="error" role="alert" class="error">
      {{ error }} <button type="button" @click="reload">Retry</button>
    </p>
    <p v-else-if="loading && items.length === 0">Loading tickets…</p>
    <p v-else-if="items.length === 0">No tickets found.</p>
    <template v-else>
      <table :aria-busy="loading">
        <thead>
          <tr>
            <th>Title</th>
            <th>Status</th>
            <th>Priority</th>
            <th>Assignee</th>
            <th>Created</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="t in items" :key="t.id">
            <td>
              <RouterLink :to="{ name: 'ticket', params: { id: t.id } }">{{ t.title }}</RouterLink>
            </td>
            <td><StatusBadge :status="t.status" /></td>
            <td>{{ t.priority }}</td>
            <td>{{ nameOf(t.assigneeId) }}</td>
            <td>{{ formatDate(t.createdAt) }}</td>
            <td>
              <button
                v-if="t.status !== 'closed'"
                type="button"
                :disabled="closingIds.has(t.id)"
                @click="close(t)"
              >
                Close ticket
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <nav class="pager" aria-label="Pagination">
        <button
          type="button"
          :disabled="query.page <= 1"
          @click="setFilters({ page: query.page - 1 })"
        >
          Previous
        </button>
        <span>Page {{ query.page }} of {{ pageCount }} ({{ total }} tickets)</span>
        <button
          type="button"
          :disabled="query.page >= pageCount"
          @click="setFilters({ page: query.page + 1 })"
        >
          Next
        </button>
      </nav>
    </template>
  </main>
</template>

<style scoped>
.head {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.filters {
  display: flex;
  gap: 0.5rem;
  margin: 1rem 0;
}
table {
  width: 100%;
  border-collapse: collapse;
}
th,
td {
  text-align: left;
  padding: 0.4rem 0.5rem;
  border-bottom: 1px solid #e5e7eb;
}
.pager {
  display: flex;
  gap: 1rem;
  align-items: center;
  margin-top: 1rem;
}
.error {
  color: #b91c1c;
}
</style>
