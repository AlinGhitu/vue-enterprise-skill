import { computed, shallowRef, toValue, watch, type MaybeRefOrGetter } from 'vue'
import { api } from '@/api'
import type { Ticket, TicketPage, TicketQuery } from '@/api/types'
import { errorMessage } from '@/utils/format'

export const PAGE_SIZE = 10

/** Loads a page of tickets whenever the query changes; stale responses are ignored. */
export function useTicketList(query: MaybeRefOrGetter<TicketQuery>) {
  const data = shallowRef<TicketPage | null>(null)
  const loading = shallowRef(false)
  const error = shallowRef<string | null>(null)
  let seq = 0

  async function load() {
    const id = ++seq
    loading.value = true
    error.value = null
    try {
      const res = await api.listTickets({ ...toValue(query), pageSize: PAGE_SIZE })
      if (id !== seq) return
      data.value = res
    } catch (e) {
      if (id !== seq) return
      error.value = errorMessage(e)
    } finally {
      if (id === seq) loading.value = false
    }
  }

  watch(() => ({ ...toValue(query) }), load, { immediate: true, deep: true })

  function replaceTicket(ticket: Ticket) {
    const d = data.value
    if (!d) return
    data.value = { ...d, items: d.items.map((t) => (t.id === ticket.id ? ticket : t)) }
  }

  const items = computed(() => data.value?.items ?? [])
  const total = computed(() => data.value?.total ?? 0)
  const pageCount = computed(() => Math.max(1, Math.ceil(total.value / PAGE_SIZE)))

  return { items, total, pageCount, loading, error, reload: load, replaceTicket }
}
