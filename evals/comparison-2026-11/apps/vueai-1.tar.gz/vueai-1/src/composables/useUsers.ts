import { computed, shallowRef } from 'vue'
import { api } from '@/api'
import type { User } from '@/api/types'

const users = shallowRef<User[]>([])
let loading: Promise<void> | null = null

/** Shared, lazily loaded user directory. */
export function useUsers() {
  if (users.value.length === 0 && !loading) {
    loading = api
      .users()
      .then((list) => {
        users.value = list
      })
      .catch(() => {
        // names fall back to ids; retried on next use
      })
      .finally(() => {
        loading = null
      })
  }
  const byId = computed(() => new Map(users.value.map((u) => [u.id, u])))
  function nameOf(id: string | null | undefined): string {
    if (!id) return 'Unassigned'
    return byId.value.get(id)?.name ?? id
  }
  return { users, nameOf }
}
