import { shallowRef } from 'vue'
import { api } from '@/api'
import type { Ticket } from '@/api/types'
import { closeTicketOptimistically } from '@/utils/optimistic'
import { errorMessage } from '@/utils/format'

/** Close action; `apply` replaces the ticket in the owner's state. */
export function useCloseTicket(apply: (ticket: Ticket) => void) {
  const closingIds = shallowRef<ReadonlySet<string>>(new Set())
  const error = shallowRef<string | null>(null)

  function setClosing(id: string, on: boolean) {
    const next = new Set(closingIds.value)
    if (on) next.add(id)
    else next.delete(id)
    closingIds.value = next
  }

  async function close(ticket: Ticket) {
    if (ticket.status === 'closed' || closingIds.value.has(ticket.id)) return
    error.value = null
    setClosing(ticket.id, true)
    try {
      await closeTicketOptimistically(ticket, apply, () =>
        api.updateTicket(ticket.id, { status: 'closed' }),
      )
    } catch (e) {
      error.value = 'Could not close ticket #' + ticket.id + ': ' + errorMessage(e)
    } finally {
      setClosing(ticket.id, false)
    }
  }

  return { close, closingIds, error }
}
