export type TicketStatus = 'open' | 'in_progress' | 'closed'
export type TicketPriority = 'low' | 'medium' | 'high'

export interface User {
  id: string
  name: string
  email: string
}

export interface Ticket {
  id: string
  title: string
  description: string
  status: TicketStatus
  priority: TicketPriority
  assigneeId: string | null
  createdAt: string
  updatedAt: string
}

export interface Comment {
  id: string
  ticketId: string
  authorId: string
  body: string
  createdAt: string
}

export interface TicketPage {
  items: Ticket[]
  total: number
  page: number
  pageSize: number
}

export interface TicketInput {
  title: string
  description: string
  priority: TicketPriority
  assigneeId: string | null
  status?: TicketStatus
}

export interface TicketQuery {
  q?: string
  status?: TicketStatus | ''
  /** User id, or 'none' for unassigned */
  assigneeId?: string
  page?: number
  pageSize?: number
}
