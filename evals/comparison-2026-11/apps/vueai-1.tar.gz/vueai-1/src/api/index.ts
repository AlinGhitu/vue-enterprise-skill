import { request } from './client'
import type { Comment, Ticket, TicketInput, TicketPage, TicketQuery, User } from './types'

const tid = (id: string) => '/tickets/' + encodeURIComponent(id)

export const api = {
  login: (email: string, password: string) =>
    request<{ token: string; user: User }>('POST', '/login', { email, password }),
  logout: () => request<void>('POST', '/logout'),
  me: () => request<User>('GET', '/me'),
  users: () => request<User[]>('GET', '/users'),
  listTickets: (q: TicketQuery) =>
    request<TicketPage>('GET', '/tickets', undefined, {
      q: q.q,
      status: q.status,
      assigneeId: q.assigneeId,
      page: q.page,
      pageSize: q.pageSize,
    }),
  getTicket: (id: string) => request<Ticket>('GET', tid(id)),
  createTicket: (input: TicketInput) => request<Ticket>('POST', '/tickets', input),
  updateTicket: (id: string, patch: Partial<TicketInput>) =>
    request<Ticket>('PATCH', tid(id), patch),
  listComments: (id: string) => request<Comment[]>('GET', tid(id) + '/comments'),
  addComment: (id: string, body: string) =>
    request<Comment>('POST', tid(id) + '/comments', { body }),
}
