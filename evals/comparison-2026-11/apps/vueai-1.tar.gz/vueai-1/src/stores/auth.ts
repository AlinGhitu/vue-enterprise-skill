import { computed, shallowRef } from 'vue'
import { defineStore } from 'pinia'
import { api } from '@/api'
import { ApiError, getToken, setToken } from '@/api/client'
import type { User } from '@/api/types'

export const useAuthStore = defineStore('auth', () => {
  const token = shallowRef<string | null>(getToken())
  const user = shallowRef<User | null>(null)
  const isLoggedIn = computed(() => token.value !== null)

  function clear() {
    token.value = null
    user.value = null
    setToken(null)
  }

  async function login(email: string, password: string) {
    const res = await api.login(email, password)
    setToken(res.token)
    token.value = res.token
    user.value = res.user
  }

  /** Load the current user for a stored token; clears the session if invalid. */
  async function restore() {
    if (!token.value || user.value) return
    try {
      user.value = await api.me()
    } catch (e) {
      if (e instanceof ApiError && e.status === 0) throw e
      clear()
    }
  }

  async function logout() {
    try {
      await api.logout()
    } catch {
      // the token is dropped locally regardless
    }
    clear()
  }

  return { token, user, isLoggedIn, login, restore, logout, clear }
})
