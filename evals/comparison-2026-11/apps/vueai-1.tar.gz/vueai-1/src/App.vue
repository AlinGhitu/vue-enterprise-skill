<script setup lang="ts">
import { RouterLink, RouterView, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()
const router = useRouter()

async function logout() {
  await auth.logout()
  await router.replace({ name: 'login' })
}
</script>

<template>
  <header v-if="auth.isLoggedIn" class="bar">
    <RouterLink :to="{ name: 'tickets' }" class="brand">Support Desk</RouterLink>
    <span class="spacer" />
    <span v-if="auth.user">{{ auth.user.name }}</span>
    <button type="button" @click="logout">Log out</button>
  </header>
  <RouterView />
</template>

<style scoped>
.bar {
  display: flex;
  gap: 1rem;
  align-items: center;
  padding: 0.75rem 1rem;
  border-bottom: 1px solid var(--color-border);
}
.brand {
  font-weight: 700;
}
.spacer {
  flex: 1;
}
</style>
