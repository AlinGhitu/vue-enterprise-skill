import type { Ticket } from '@/api/types'

/**
 * Optimistically close a ticket. `apply` writes a ticket into the UI state.
 * The UI updates immediately; if the request fails, the previous snapshot is
 * restored and the error is rethrown.
 */
export async function closeTicketOptimistically(
  current: Ticket,
  apply: (ticket: Ticket) => void,
  send: () => Promise<Ticket>,
): Promise<void> {
  const snapshot = { ...current }
  apply({ ...current, status: 'closed' })
  try {
    apply(await send())
  } catch (e) {
    apply(snapshot)
    throw e
  }
}
