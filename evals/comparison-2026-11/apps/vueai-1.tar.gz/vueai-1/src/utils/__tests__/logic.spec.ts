import { describe, expect, it, vi } from 'vitest'
import type { Ticket } from '@/api/types'
import { resolveAuthRedirect, safeRedirect } from '@/router/guard'
import { closeTicketOptimistically } from '../optimistic'
import { parseListQuery, serializeListQuery, UNASSIGNED } from '../ticketQuery'
import { hasErrors,validateComment, validateTicket } from '../validation'

const ticket: Ticket = {
  id: '1',
  title: 'Some title',
  description: 'A long enough description',
  status: 'open',
  priority: 'low',
  assigneeId: null,
  createdAt: '2026-01-01T00:00:00Z',
  updatedAt: '2026-01-01T00:00:00Z',
}

describe('validateTicket', () => {
  const valid = { title: 'Hello', description: '0123456789', priority: 'high' }
  it('accepts boundary values', () => {
    expect(validateTicket(valid)).toEqual({})
    expect(validateTicket({ ...valid, title: 'x'.repeat(120) })).toEqual({})
  })
  it('rejects short/long titles and trims whitespace', () => {
    expect(validateTicket({ ...valid, title: 'abcd' }).title).toBeDefined()
    expect(validateTicket({ ...valid, title: '  ab  ' }).title).toBeDefined()
    expect(validateTicket({ ...valid, title: 'x'.repeat(121) }).title).toBeDefined()
  })
  it('rejects short descriptions and unknown priority', () => {
    const e = validateTicket({ ...valid, description: ' 123456789 ', priority: 'urgent' })
    expect(e.description).toBeDefined()
    expect(e.priority).toBeDefined()
    expect(hasErrors(e)).toBe(true)
  })
})

describe('validateComment', () => {
  it('requires non-blank text', () => {
    expect(validateComment('   ')).not.toBeNull()
    expect(validateComment('hi')).toBeNull()
  })
})

describe('closeTicketOptimistically', () => {
  it('applies closed state immediately, then the server response', async () => {
    const applied: Ticket[] = []
    let resolve!: (t: Ticket) => void
    const p = closeTicketOptimistically(
      ticket,
      (t) => applied.push(t),
      () => new Promise<Ticket>((r) => (resolve = r)),
    )
    expect(applied).toHaveLength(1)
    expect(applied[0]!.status).toBe('closed')
    resolve({ ...ticket, status: 'closed', updatedAt: 'later' })
    await p
    expect(applied[applied.length - 1]!.updatedAt).toBe('later')
  })

  it('rolls back and rethrows when the request fails', async () => {
    const apply = vi.fn<(t: Ticket) => void>()
    await expect(
      closeTicketOptimistically(ticket, apply, () => Promise.reject(new Error('boom'))),
    ).rejects.toThrow('boom')
    expect(apply.mock.calls[0]![0].status).toBe('closed')
    expect(apply.mock.calls[apply.mock.calls.length - 1]![0]).toEqual(ticket)
  })
})

describe('auth redirects', () => {
  const route = (fullPath: string, pub = false, redirect?: string) => ({
    fullPath,
    meta: pub ? { public: true } : {},
    query: (redirect ? { redirect } : {}) as Record<string, string>,
  })
  it('sends anonymous users to login with the wanted path', () => {
    expect(resolveAuthRedirect(route('/tickets/3?x=1'), false)).toEqual({
      name: 'login',
      query: { redirect: '/tickets/3?x=1' },
    })
  })
  it('lets logged-in users through and bounces them off login', () => {
    expect(resolveAuthRedirect(route('/tickets'), true)).toBe(true)
    expect(resolveAuthRedirect(route('/login', true, '/tickets/3'), true)).toBe('/tickets/3')
    expect(resolveAuthRedirect(route('/login', true), false)).toBe(true)
  })
  it('rejects unsafe redirect targets', () => {
    expect(safeRedirect('//evil.com')).toBe('/')
    expect(safeRedirect('https://evil.com')).toBe('/')
    expect(safeRedirect(undefined)).toBe('/')
    expect(safeRedirect('/tickets?page=2')).toBe('/tickets?page=2')
  })
})

describe('ticket list query', () => {
  it('parses defaults and sanitizes bad values', () => {
    expect(parseListQuery({})).toEqual({ q: '', status: '', assigneeId: '', page: 1 })
    const f = parseListQuery({ status: 'toString', page: '-2', q: ['a', 'b'] })
    expect(f).toEqual({ q: 'a', status: '', assigneeId: '', page: 1 })
    expect(parseListQuery({ page: '1.5' }).page).toBe(1)
  })
  it('round-trips assignee, unassigned and page', () => {
    const f = { q: 'x', status: 'open' as const, assigneeId: UNASSIGNED, page: 3 }
    expect(parseListQuery(serializeListQuery(f) as Record<string, string>)).toEqual(f)
  })
  it('omits defaults from the URL', () => {
    const q = serializeListQuery({ q: '', status: '', assigneeId: '', page: 1 })
    expect(Object.values(q).every((v) => v === undefined)).toBe(true)
  })
})
