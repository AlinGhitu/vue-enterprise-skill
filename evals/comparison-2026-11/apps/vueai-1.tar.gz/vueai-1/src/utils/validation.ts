import type { TicketPriority } from '@/api/types'

export type TicketField = 'title' | 'description' | 'priority' | 'assigneeId' | 'status'
export type TicketErrors = Partial<Record<TicketField, string>>

export const PRIORITIES: TicketPriority[] = ['low', 'medium', 'high']

/** Mirrors the API rules (API.md): title 5-120 chars, description >= 10 chars. */
export function validateTicket(input: {
  title: string
  description: string
  priority: string
}): TicketErrors {
  const errors: TicketErrors = {}
  if (input.title.trim().length < 5 || input.title.length > 120) {
    errors.title = 'Title must be 5-120 characters'
  }
  if (input.description.trim().length < 10) {
    errors.description = 'Description must be at least 10 characters'
  }
  if (!PRIORITIES.includes(input.priority as TicketPriority)) {
    errors.priority = 'Unknown priority'
  }
  return errors
}

export function validateComment(body: string): string | null {
  return body.trim().length === 0 ? 'Comment cannot be empty' : null
}

export function hasErrors(errors: object): boolean {
  return Object.keys(errors).length > 0
}
