import type { LocationQuery, LocationQueryRaw } from 'vue-router'
import type { TicketStatus } from '@/api/types'
import { STATUS_LABELS } from './format'

/** Value of the assignee filter meaning "unassigned" (same as the API). */
export const UNASSIGNED = 'none'

export interface ListFilters {
  q: string
  status: TicketStatus | ''
  /** '' = any user, UNASSIGNED, or a user id */
  assigneeId: string
  page: number
}

function first(value: LocationQuery[string] | undefined): string {
  const v = Array.isArray(value) ? value[0] : value
  return v ?? ''
}

/** Reads (and sanitizes) the list filters from a route query. */
export function parseListQuery(query: LocationQuery): ListFilters {
  const status = first(query.status)
  const page = Number(first(query.page))
  return {
    q: first(query.q),
    status: (Object.prototype.hasOwnProperty.call(STATUS_LABELS, status) ? status : '') as TicketStatus | '',
    assigneeId: first(query.assigneeId),
    page: Number.isInteger(page) && page > 0 ? page : 1,
  }
}

/** Builds a route query, omitting defaults to keep URLs short. */
export function serializeListQuery(f: ListFilters): LocationQueryRaw {
  return {
    q: f.q || undefined,
    status: f.status || undefined,
    assigneeId: f.assigneeId || undefined,
    page: f.page > 1 ? String(f.page) : undefined,
  }
}
