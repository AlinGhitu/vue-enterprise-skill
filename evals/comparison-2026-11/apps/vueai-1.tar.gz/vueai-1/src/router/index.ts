import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { onUnauthorized } from '@/api/client'
import { resolveAuthRedirect } from './guard'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/LoginView.vue'),
      meta: { public: true },
    },
    { path: '/', redirect: { name: 'tickets' } },
    {
      path: '/tickets',
      name: 'tickets',
      component: () => import('@/views/TicketListView.vue'),
    },
    {
      path: '/tickets/new',
      name: 'ticket-new',
      component: () => import('@/views/TicketFormView.vue'),
    },
    {
      path: '/tickets/:id',
      name: 'ticket',
      component: () => import('@/views/TicketDetailView.vue'),
      props: true,
    },
    {
      path: '/tickets/:id/edit',
      name: 'ticket-edit',
      component: () => import('@/views/TicketFormView.vue'),
      props: true,
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'not-found',
      component: () => import('@/views/NotFoundView.vue'),
    },
  ],
})

router.beforeEach(async (to) => {
  const auth = useAuthStore()
  if (auth.isLoggedIn && !to.meta.public) {
    try {
      await auth.restore()
    } catch {
      // network failure: let the page show its own error state
    }
  }
  return resolveAuthRedirect(to, auth.isLoggedIn)
})

onUnauthorized(() => {
  const auth = useAuthStore()
  auth.clear()
  const current = router.currentRoute.value
  if (!current.meta.public) {
    void router.replace({ name: 'login', query: { redirect: current.fullPath } })
  }
})

export default router
