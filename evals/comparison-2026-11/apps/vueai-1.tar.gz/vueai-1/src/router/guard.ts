import type { RouteLocationNormalized, RouteLocationRaw } from 'vue-router'

/** Only allow same-app absolute paths as post-login redirect targets. */
export function safeRedirect(value: unknown): string {
  return typeof value === 'string' && value.startsWith('/') && !value.startsWith('//') ? value : '/'
}

export function resolveAuthRedirect(
  to: Pick<RouteLocationNormalized, 'fullPath' | 'meta' | 'query'>,
  isLoggedIn: boolean,
): RouteLocationRaw | true {
  if (to.meta.public) {
    return isLoggedIn ? safeRedirect(to.query.redirect) : true
  }
  if (!isLoggedIn) {
    return { name: 'login', query: { redirect: to.fullPath } }
  }
  return true
}
