<script setup lang="ts">
import type { TicketStatus } from '@/api/types'
import { STATUS_LABELS } from '@/utils/format'

defineProps<{ status: TicketStatus }>()
</script>

<template>
  <span class="badge" :class="'badge-' + status">{{ STATUS_LABELS[status] }}</span>
</template>

<style scoped>
.badge {
  display: inline-block;
  padding: 0.1rem 0.5rem;
  border-radius: 999px;
  font-size: 0.8rem;
  background: #e5e7eb;
  color: #111827;
}
.badge-open {
  background: #dbeafe;
}
.badge-in_progress {
  background: #fef3c7;
}
.badge-closed {
  background: #d1fae5;
}
</style>
