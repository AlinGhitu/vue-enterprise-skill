import { beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { ApiError } from '@/api/client'
import type { TicketInput } from '@/api/types'
import TicketForm from '../TicketForm.vue'

type Submit = (input: TicketInput) => Promise<void>

vi.mock('@/composables/useUsers', async () => {
  const { shallowRef } = await import('vue')
  return { useUsers: () => ({ users: shallowRef([]), nameOf: (id: string) => id }) }
})

describe('TicketForm', () => {
  beforeEach(() => vi.clearAllMocks())

  it('blocks submit and shows client-side errors', async () => {
    const submit = vi.fn<Submit>()
    const w = mount(TicketForm, { props: { submit } })
    await w.find('input[name=title]').setValue('abc')
    await w.find('form').trigger('submit')
    expect(submit).not.toHaveBeenCalled()
    expect(w.find('[data-test=error-title]').exists()).toBe(true)
    expect(w.find('[data-test=error-description]').exists()).toBe(true)
  })

  it('submits valid data', async () => {
    const submit = vi.fn<Submit>().mockResolvedValue(undefined)
    const w = mount(TicketForm, { props: { submit } })
    await w.find('input[name=title]').setValue('A fine title')
    await w.find('textarea[name=description]').setValue('A fine long description')
    await w.find('form').trigger('submit')
    await flushPromises()
    expect(submit).toHaveBeenCalledWith({
      title: 'A fine title',
      description: 'A fine long description',
      priority: 'medium',
      assigneeId: null,
    })
  })

  it('shows API 422 errors next to fields', async () => {
    const submit = vi
      .fn<Submit>()
      .mockRejectedValue(new ApiError(422, 'Invalid', { assigneeId: 'Unknown user' }))
    const w = mount(TicketForm, { props: { submit } })
    await w.find('input[name=title]').setValue('A fine title')
    await w.find('textarea[name=description]').setValue('A fine long description')
    await w.find('form').trigger('submit')
    await flushPromises()
    expect(w.find('[data-test=error-assigneeId]').text()).toBe('Unknown user')
  })
})
