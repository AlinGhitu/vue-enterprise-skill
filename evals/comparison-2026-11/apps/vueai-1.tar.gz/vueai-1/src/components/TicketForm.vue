<script setup lang="ts">
import { reactive, shallowRef } from 'vue'
import { ApiError } from '@/api/client'
import type { TicketInput, TicketStatus } from '@/api/types'
import { useUsers } from '@/composables/useUsers'
import { errorMessage, STATUS_LABELS } from '@/utils/format'
import { hasErrors, PRIORITIES, validateTicket, type TicketErrors } from '@/utils/validation'

const props = defineProps<{
  initial?: TicketInput
  /** Edit mode shows the status field. */
  editing?: boolean
  submit: (input: TicketInput) => Promise<void>
}>()
const emit = defineEmits<{ cancel: [] }>()

const { users } = useUsers()

const form = reactive<TicketInput>({
  title: props.initial?.title ?? '',
  description: props.initial?.description ?? '',
  priority: props.initial?.priority ?? 'medium',
  assigneeId: props.initial?.assigneeId ?? null,
  status: props.initial?.status ?? 'open',
})
const errors = shallowRef<TicketErrors>({})
const formError = shallowRef<string | null>(null)
const saving = shallowRef(false)

async function onSubmit() {
  formError.value = null
  errors.value = validateTicket(form)
  if (hasErrors(errors.value)) return
  saving.value = true
  try {
    const payload: TicketInput = {
      title: form.title,
      description: form.description,
      priority: form.priority,
      assigneeId: form.assigneeId,
    }
    if (props.editing) payload.status = form.status
    await props.submit(payload)
  } catch (e) {
    if (e instanceof ApiError && e.status === 422) {
      errors.value = e.errors
      formError.value = hasErrors(e.errors) ? null : e.message
    } else {
      formError.value = errorMessage(e)
    }
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <form novalidate class="form" @submit.prevent="onSubmit">
    <p v-if="formError" role="alert" class="error">{{ formError }}</p>

    <label>
      Title
      <input v-model="form.title" name="title" type="text" :aria-invalid="!!errors.title" />
      <span v-if="errors.title" class="error" data-test="error-title">{{ errors.title }}</span>
    </label>

    <label>
      Description
      <textarea
        v-model="form.description"
        name="description"
        rows="5"
        :aria-invalid="!!errors.description"
      />
      <span v-if="errors.description" class="error" data-test="error-description">
        {{ errors.description }}
      </span>
    </label>

    <label>
      Priority
      <select v-model="form.priority" name="priority">
        <option v-for="p in PRIORITIES" :key="p" :value="p">{{ p }}</option>
      </select>
      <span v-if="errors.priority" class="error" data-test="error-priority">
        {{ errors.priority }}
      </span>
    </label>

    <label v-if="editing">
      Status
      <select v-model="form.status" name="status">
        <option v-for="(label, value) in STATUS_LABELS" :key="value" :value="value as TicketStatus">
          {{ label }}
        </option>
      </select>
      <span v-if="errors.status" class="error">{{ errors.status }}</span>
    </label>

    <label>
      Assignee
      <select v-model="form.assigneeId" name="assigneeId">
        <option :value="null">Unassigned</option>
        <option v-for="u in users" :key="u.id" :value="u.id">{{ u.name }}</option>
      </select>
      <span v-if="errors.assigneeId" class="error" data-test="error-assigneeId">
        {{ errors.assigneeId }}
      </span>
    </label>

    <div class="actions">
      <button type="submit" :disabled="saving">{{ saving ? 'Saving…' : 'Save' }}</button>
      <button type="button" :disabled="saving" @click="emit('cancel')">Cancel</button>
    </div>
  </form>
</template>

<style scoped>
.form {
  display: grid;
  gap: 1rem;
  max-width: 40rem;
}
label {
  display: grid;
  gap: 0.25rem;
}
.error {
  color: #b91c1c;
  font-size: 0.875rem;
}
.actions {
  display: flex;
  gap: 0.5rem;
}
</style>
