<script setup lang="ts">
import { shallowRef, watch } from 'vue'
import { api } from '@/api'
import { ApiError } from '@/api/client'
import type { Comment } from '@/api/types'
import { useUsers } from '@/composables/useUsers'
import { errorMessage, formatDateTime } from '@/utils/format'
import { validateComment } from '@/utils/validation'

const props = defineProps<{ ticketId: string }>()

const { nameOf } = useUsers()
const comments = shallowRef<Comment[]>([])
const loading = shallowRef(false)
const loadError = shallowRef<string | null>(null)

const body = shallowRef('')
const fieldError = shallowRef<string | null>(null)
const posting = shallowRef(false)

let seq = 0
async function load() {
  const id = ++seq
  loading.value = true
  loadError.value = null
  comments.value = []
  try {
    const res = await api.listComments(props.ticketId)
    if (id === seq) comments.value = res
  } catch (e) {
    if (id === seq) loadError.value = errorMessage(e)
  } finally {
    if (id === seq) loading.value = false
  }
}
watch(() => props.ticketId, load, { immediate: true })

async function onSubmit() {
  fieldError.value = validateComment(body.value)
  if (fieldError.value) return
  posting.value = true
  try {
    const created = await api.addComment(props.ticketId, body.value)
    comments.value = [...comments.value, created]
    body.value = ''
  } catch (e) {
    fieldError.value = e instanceof ApiError && e.errors.body ? e.errors.body : errorMessage(e)
  } finally {
    posting.value = false
  }
}
</script>

<template>
  <section>
    <h2>Comments</h2>
    <p v-if="loading">Loading comments…</p>
    <p v-else-if="loadError" role="alert" class="error">
      {{ loadError }} <button type="button" @click="load">Retry</button>
    </p>
    <p v-else-if="comments.length === 0">No comments yet.</p>
    <ul v-else class="comments">
      <li v-for="c in comments" :key="c.id">
        <strong>{{ nameOf(c.authorId) }}</strong>
        <time :datetime="c.createdAt"> · {{ formatDateTime(c.createdAt) }}</time>
        <p>{{ c.body }}</p>
      </li>
    </ul>

    <form novalidate @submit.prevent="onSubmit">
      <label>
        Add a comment
        <textarea v-model="body" name="body" rows="3" :aria-invalid="!!fieldError" />
      </label>
      <p v-if="fieldError" class="error" data-test="error-body">{{ fieldError }}</p>
      <button type="submit" :disabled="posting">{{ posting ? 'Posting…' : 'Add comment' }}</button>
    </form>
  </section>
</template>

<style scoped>
.comments {
  list-style: none;
  padding: 0;
}
.comments li {
  border-bottom: 1px solid #e5e7eb;
  padding: 0.5rem 0;
}
.comments p {
  margin: 0.25rem 0 0;
  white-space: pre-wrap;
}
form {
  display: grid;
  gap: 0.5rem;
  max-width: 40rem;
  margin-top: 1rem;
}
label {
  display: grid;
  gap: 0.25rem;
}
.error {
  color: #b91c1c;
}
</style>
