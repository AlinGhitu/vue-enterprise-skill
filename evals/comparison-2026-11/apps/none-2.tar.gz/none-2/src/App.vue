<script setup lang="ts">
import { RouterLink, RouterView, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()
const router = useRouter()

async function logout() {
  await auth.logout()
  await router.push({ name: 'login' })
}
</script>

<template>
  <header v-if="auth.isLoggedIn" class="topbar">
    <nav>
      <strong>Support Desk</strong>
      <RouterLink :to="{ name: 'tickets' }">Tickets</RouterLink>
      <RouterLink :to="{ name: 'ticket-new' }">New ticket</RouterLink>
    </nav>
    <div class="actions">
      <span v-if="auth.user" class="muted">{{ auth.user.name }}</span>
      <button type="button" @click="logout">Log out</button>
    </div>
  </header>
  <main>
    <RouterView />
  </main>
</template>
