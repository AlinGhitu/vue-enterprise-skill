<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'
import { api, ApiError } from '@/api/client'
import type { Comment, Ticket } from '@/api/types'
import { useUsersStore } from '@/stores/users'
import { closeTicketOptimistically } from '@/lib/optimistic'
import { formatDateTime, statusLabel } from '@/lib/format'
import { validateComment } from '@/lib/validation'

const props = defineProps<{ id: string }>()
const users = useUsersStore()

const ticket = ref<Ticket | null>(null)
const comments = ref<Comment[]>([])
const loading = ref(true)
const error = ref('')
const actionError = ref('')
const closing = ref(false)

const body = ref('')
const commentError = ref('')
const posting = ref(false)
let seq = 0

async function load() {
  const mine = ++seq
  loading.value = true
  error.value = ''
  ticket.value = null
  try {
    const [t, c] = await Promise.all([api.ticket(props.id), api.comments(props.id), users.load()])
    if (mine !== seq) return
    ticket.value = t
    comments.value = c
  } catch (e) {
    if (mine !== seq) return
    error.value =
      e instanceof ApiError
        ? e.status === 404
          ? 'Ticket not found.'
          : e.message
        : 'Failed to load ticket'
  } finally {
    if (mine === seq) loading.value = false
  }
}
onMounted(load)
watch(() => props.id, load)

async function close() {
  if (!ticket.value) return
  actionError.value = ''
  closing.value = true
  try {
    await closeTicketOptimistically(ticket.value, api.updateTicket)
  } catch (e) {
    actionError.value = `Could not close ticket: ${e instanceof Error ? e.message : 'unknown error'}`
  } finally {
    closing.value = false
  }
}

async function addComment() {
  commentError.value = validateComment(body.value).body ?? ''
  if (commentError.value) return
  posting.value = true
  try {
    comments.value.push(await api.addComment(props.id, body.value))
    body.value = ''
  } catch (e) {
    commentError.value = e instanceof ApiError ? (e.errors.body ?? e.message) : 'Failed to add comment'
  } finally {
    posting.value = false
  }
}
</script>

<template>
  <p>
    <RouterLink :to="{ name: 'tickets' }">← Back to tickets</RouterLink>
  </p>
  <p v-if="loading">Loading ticket…</p>
  <div v-else-if="error || !ticket" class="card">
    <p class="error" role="alert">{{ error }}</p>
    <button type="button" @click="load">Retry</button>
  </div>
  <template v-else>
    <article class="card">
      <h1>{{ ticket.title }}</h1>
      <p v-if="actionError" class="error" role="alert">{{ actionError }}</p>
      <dl>
        <dt>Status</dt>
        <dd>
          <span class="badge" :class="ticket.status">{{ statusLabel(ticket.status) }}</span>
        </dd>
        <dt>Priority</dt>
        <dd>{{ ticket.priority }}</dd>
        <dt>Assignee</dt>
        <dd>{{ users.nameOf(ticket.assigneeId) }}</dd>
        <dt>Created</dt>
        <dd>{{ formatDateTime(ticket.createdAt) }}</dd>
        <dt>Updated</dt>
        <dd>{{ formatDateTime(ticket.updatedAt) }}</dd>
        <dt>Description</dt>
        <dd style="white-space: pre-wrap">{{ ticket.description }}</dd>
      </dl>
      <div class="actions">
        <RouterLink class="btn" :to="{ name: 'ticket-edit', params: { id: ticket.id } }">
          Edit
        </RouterLink>
        <button v-if="ticket.status !== 'closed'" type="button" :disabled="closing" @click="close">
          Close ticket
        </button>
      </div>
    </article>

    <section class="card">
      <h2>Comments ({{ comments.length }})</h2>
      <p v-if="!comments.length" class="muted">No comments yet.</p>
      <ul v-else style="list-style: none; padding: 0">
        <li v-for="c in comments" :key="c.id" style="margin-bottom: 0.75rem">
          <strong>{{ users.nameOf(c.authorId) }}</strong>
          <span class="muted"> · {{ formatDateTime(c.createdAt) }}</span>
          <div style="white-space: pre-wrap">{{ c.body }}</div>
        </li>
      </ul>
      <form novalidate @submit.prevent="addComment">
        <div class="field">
          <label for="comment">Add a comment</label>
          <textarea id="comment" v-model="body" rows="3" />
          <span v-if="commentError" class="error">{{ commentError }}</span>
        </div>
        <button class="primary" type="submit" :disabled="posting">
          {{ posting ? 'Posting…' : 'Add comment' }}
        </button>
      </form>
    </section>
  </template>
</template>
