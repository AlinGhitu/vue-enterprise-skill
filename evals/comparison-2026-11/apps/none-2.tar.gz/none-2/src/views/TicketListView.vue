<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { api, ApiError } from '@/api/client'
import { STATUSES, type Ticket } from '@/api/types'
import { useUsersStore } from '@/stores/users'
import { closeTicketOptimistically } from '@/lib/optimistic'
import { buildListQuery, parseListQuery } from '@/lib/ticketQuery'
import { formatDate, statusLabel, totalPages } from '@/lib/format'

const PAGE_SIZE = 10
const route = useRoute()
const router = useRouter()
const users = useUsersStore()

const items = ref<Ticket[]>([])
const total = ref(0)
const loading = ref(true)
const error = ref('')
const actionError = ref('')
const closing = ref(new Set<string>())

const filters = computed(() => parseListQuery(route.query))
const q = computed(() => filters.value.q)
const status = computed(() => filters.value.status)
const assigneeId = computed(() => filters.value.assigneeId)
const page = computed(() => filters.value.page)
const pages = computed(() => totalPages(total.value, PAGE_SIZE))

const search = ref(q.value)
let timer: ReturnType<typeof setTimeout> | undefined
let seq = 0

function setQuery(patch: Record<string, string | number | undefined>) {
  router.push({ query: buildListQuery(route.query, patch) })
}

watch(search, (v) => {
  clearTimeout(timer)
  timer = setTimeout(() => {
    if (v !== q.value) setQuery({ q: v, page: undefined })
  }, 300)
})
watch(q, (v) => {
  clearTimeout(timer)
  search.value = v
})

async function load() {
  const mine = ++seq
  loading.value = true
  error.value = ''
  try {
    const res = await api.tickets({
      q: q.value,
      status: status.value,
      assigneeId: assigneeId.value,
      page: page.value,
      pageSize: PAGE_SIZE,
    })
    if (mine !== seq) return
    items.value = res.items
    total.value = res.total
  } catch (e) {
    if (mine !== seq) return
    error.value = e instanceof ApiError ? e.message : 'Failed to load tickets'
  } finally {
    if (mine === seq) loading.value = false
  }
}

watch([q, status, assigneeId, page], load)
onMounted(() => {
  load()
  users.load().catch(() => {})
})
onUnmounted(() => clearTimeout(timer))

async function close(t: Ticket) {
  actionError.value = ''
  closing.value.add(t.id)
  try {
    await closeTicketOptimistically(t, api.updateTicket)
  } catch (e) {
    actionError.value = `Could not close "${t.title}": ${e instanceof Error ? e.message : 'unknown error'}`
  } finally {
    closing.value.delete(t.id)
  }
}

function onStatus(e: Event) {
  setQuery({ status: (e.target as HTMLSelectElement).value, page: undefined })
}

function onAssignee(e: Event) {
  setQuery({ assigneeId: (e.target as HTMLSelectElement).value, page: undefined })
}
</script>

<template>
  <h1>Tickets</h1>
  <div class="toolbar">
    <input v-model="search" type="search" placeholder="Search tickets…" aria-label="Search" />
    <select :value="status" aria-label="Status filter" @change="onStatus">
      <option value="">All statuses</option>
      <option v-for="s in STATUSES" :key="s" :value="s">{{ statusLabel(s) }}</option>
    </select>
    <select :value="assigneeId" aria-label="Assignee filter" @change="onAssignee">
      <option value="">All assignees</option>
      <option value="none">Unassigned</option>
      <option v-for="u in users.users" :key="u.id" :value="u.id">{{ u.name }}</option>
    </select>
    <RouterLink class="btn" :to="{ name: 'ticket-new' }">New ticket</RouterLink>
  </div>

  <p v-if="actionError" class="error" role="alert">{{ actionError }}</p>

  <p v-if="loading && !items.length && !error">Loading tickets…</p>
  <div v-else-if="error" class="card">
    <p class="error" role="alert">{{ error }}</p>
    <button type="button" @click="load">Retry</button>
  </div>
  <p v-else-if="!items.length" class="card muted">No tickets found.</p>
  <template v-else>
    <table :style="{ opacity: loading ? 0.6 : 1 }">
      <thead>
        <tr>
          <th>Title</th>
          <th>Status</th>
          <th>Priority</th>
          <th>Assignee</th>
          <th>Created</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="t in items" :key="t.id">
          <td>
            <RouterLink :to="{ name: 'ticket', params: { id: t.id } }">{{ t.title }}</RouterLink>
          </td>
          <td>
            <span class="badge" :class="t.status">{{ statusLabel(t.status) }}</span>
          </td>
          <td>{{ t.priority }}</td>
          <td>{{ users.nameOf(t.assigneeId) }}</td>
          <td>{{ formatDate(t.createdAt) }}</td>
          <td>
            <button
              v-if="t.status !== 'closed'"
              type="button"
              :disabled="closing.has(t.id)"
              @click="close(t)"
            >
              Close ticket
            </button>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="pager">
      <button type="button" :disabled="page <= 1" @click="setQuery({ page: page - 1 })">
        Previous
      </button>
      <span>Page {{ page }} of {{ pages }} ({{ total }} tickets)</span>
      <button type="button" :disabled="page >= pages" @click="setQuery({ page: page + 1 })">
        Next
      </button>
    </div>
  </template>
</template>
