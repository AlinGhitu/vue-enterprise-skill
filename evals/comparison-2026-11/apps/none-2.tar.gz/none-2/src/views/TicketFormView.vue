<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { api, ApiError } from '@/api/client'
import { PRIORITIES, type TicketInput } from '@/api/types'
import { useUsersStore } from '@/stores/users'
import { validateTicket, type FieldErrors } from '@/lib/validation'

const props = defineProps<{ id?: string }>()
const router = useRouter()
const users = useUsersStore()

const isEdit = computed(() => !!props.id)
const form = reactive<TicketInput>({
  title: '',
  description: '',
  priority: 'medium',
  assigneeId: null,
})
const errors = ref<FieldErrors>({})
const formError = ref('')
const loading = ref(isEdit.value)
const loadError = ref('')
const submitting = ref(false)

async function load() {
  loading.value = true
  loadError.value = ''
  try {
    const [t] = await Promise.all([props.id ? api.ticket(props.id) : null, users.load()])
    if (t) {
      form.title = t.title
      form.description = t.description
      form.priority = t.priority
      form.assigneeId = t.assigneeId
    }
  } catch (e) {
    loadError.value = e instanceof ApiError ? e.message : 'Failed to load'
  } finally {
    loading.value = false
  }
}
onMounted(load)

async function submit() {
  formError.value = ''
  errors.value = validateTicket(form)
  if (Object.keys(errors.value).length) return
  submitting.value = true
  try {
    const saved = props.id
      ? await api.updateTicket(props.id, { ...form })
      : await api.createTicket({ ...form })
    await router.push({ name: 'ticket', params: { id: saved.id } })
  } catch (e) {
    if (e instanceof ApiError && e.status === 422) {
      errors.value = e.errors
      formError.value = Object.keys(e.errors).length ? '' : e.message
    } else {
      formError.value = e instanceof Error ? e.message : 'Failed to save'
    }
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <h1>{{ isEdit ? 'Edit ticket' : 'New ticket' }}</h1>
  <p v-if="loading">Loading…</p>
  <div v-else-if="loadError" class="card">
    <p class="error" role="alert">{{ loadError }}</p>
    <button type="button" @click="load">Retry</button>
  </div>
  <form v-else class="card" novalidate @submit.prevent="submit">
    <p v-if="formError" class="error" role="alert">{{ formError }}</p>
    <div class="field">
      <label for="title">Title</label>
      <input id="title" v-model="form.title" />
      <span v-if="errors.title" class="error">{{ errors.title }}</span>
    </div>
    <div class="field">
      <label for="description">Description</label>
      <textarea id="description" v-model="form.description" rows="5" />
      <span v-if="errors.description" class="error">{{ errors.description }}</span>
    </div>
    <div class="field">
      <label for="priority">Priority</label>
      <select id="priority" v-model="form.priority">
        <option v-for="p in PRIORITIES" :key="p" :value="p">{{ p }}</option>
      </select>
      <span v-if="errors.priority" class="error">{{ errors.priority }}</span>
    </div>
    <div class="field">
      <label for="assignee">Assignee</label>
      <select id="assignee" v-model="form.assigneeId">
        <option :value="null">Unassigned</option>
        <option v-for="u in users.users" :key="u.id" :value="u.id">{{ u.name }}</option>
      </select>
      <span v-if="errors.assigneeId" class="error">{{ errors.assigneeId }}</span>
    </div>
    <div class="actions">
      <button class="primary" type="submit" :disabled="submitting">
        {{ submitting ? 'Saving…' : 'Save' }}
      </button>
      <RouterLink
        class="btn"
        :to="props.id ? { name: 'ticket', params: { id: props.id } } : { name: 'tickets' }"
      >
        Cancel
      </RouterLink>
    </div>
  </form>
</template>
