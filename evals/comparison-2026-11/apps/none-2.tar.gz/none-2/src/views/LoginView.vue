<script setup lang="ts">
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { ApiError } from '@/api/client'
import { validateLogin, type FieldErrors } from '@/lib/validation'
import { safeRedirect } from '@/lib/redirect'

const auth = useAuthStore()
const route = useRoute()
const router = useRouter()
const email = ref('')
const password = ref('')
const errors = ref<FieldErrors>({})
const formError = ref('')
const submitting = ref(false)

async function submit() {
  formError.value = ''
  errors.value = validateLogin(email.value, password.value)
  if (Object.keys(errors.value).length) return
  submitting.value = true
  try {
    await auth.login(email.value, password.value)
    await router.replace(safeRedirect(route.query.redirect))
  } catch (e) {
    formError.value = e instanceof ApiError ? e.message : 'Login failed'
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <form
    class="card"
    style="max-width: 360px; margin: 3rem auto"
    novalidate
    @submit.prevent="submit"
  >
    <h1>Log in</h1>
    <p v-if="formError" class="error" role="alert">{{ formError }}</p>
    <div class="field">
      <label for="email">Email</label>
      <input id="email" v-model="email" type="email" autocomplete="username" />
      <span v-if="errors.email" class="error">{{ errors.email }}</span>
    </div>
    <div class="field">
      <label for="password">Password</label>
      <input id="password" v-model="password" type="password" autocomplete="current-password" />
      <span v-if="errors.password" class="error">{{ errors.password }}</span>
    </div>
    <button class="primary" type="submit" :disabled="submitting">
      {{ submitting ? 'Logging in…' : 'Log in' }}
    </button>
  </form>
</template>
