import { createRouter, createWebHistory, type Router } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { onUnauthorized } from '@/api/client'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/LoginView.vue'),
      meta: { public: true },
    },
    { path: '/', redirect: { name: 'tickets' } },
    { path: '/tickets', name: 'tickets', component: () => import('@/views/TicketListView.vue') },
    {
      path: '/tickets/new',
      name: 'ticket-new',
      component: () => import('@/views/TicketFormView.vue'),
    },
    {
      path: '/tickets/:id',
      name: 'ticket',
      component: () => import('@/views/TicketDetailView.vue'),
      props: true,
    },
    {
      path: '/tickets/:id/edit',
      name: 'ticket-edit',
      component: () => import('@/views/TicketFormView.vue'),
      props: true,
    },
    { path: '/:pathMatch(.*)*', redirect: { name: 'tickets' } },
  ],
})

export function installGuards(r: Router) {
  r.beforeEach(async (to) => {
    const auth = useAuthStore()
    if (auth.isLoggedIn) await auth.restore()
    if (to.meta.public) {
      return auth.isLoggedIn && to.name === 'login' ? { name: 'tickets' } : true
    }
    if (!auth.isLoggedIn) return { name: 'login', query: { redirect: to.fullPath } }
    return true
  })
  onUnauthorized(() => {
    useAuthStore().clear()
    const current = r.currentRoute.value
    if (!current.meta.public) r.push({ name: 'login', query: { redirect: current.fullPath } })
  })
}

installGuards(router)

export default router
