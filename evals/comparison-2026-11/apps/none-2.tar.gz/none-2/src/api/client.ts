import type { Comment, Status, Ticket, TicketInput, TicketPage, User } from './types'

export class ApiError extends Error {
  status: number
  errors: Record<string, string>
  constructor(status: number, message: string, errors: Record<string, string> = {}) {
    super(message)
    this.status = status
    this.errors = errors
  }
}

const TOKEN_KEY = 'support-desk-token'
let unauthorizedHandler: (() => void) | null = null

export const getToken = () => localStorage.getItem(TOKEN_KEY)
export const setToken = (t: string | null) =>
  t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY)
export const onUnauthorized = (fn: (() => void) | null) => {
  unauthorizedHandler = fn
}

export async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = {}
  const token = getToken()
  if (token) headers.Authorization = 'Bearer ' + token
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  let res: Response
  try {
    res = await fetch('/api' + path, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    })
  } catch {
    throw new ApiError(0, 'Network error. Please check your connection.')
  }
  if (!res.ok) {
    let data: { message?: string; errors?: Record<string, string> } = {}
    try {
      data = await res.json()
    } catch {
      /* no body */
    }
    if (res.status === 401 && token && path !== '/login') unauthorizedHandler?.()
    throw new ApiError(res.status, data.message ?? 'Request failed (' + res.status + ')', data.errors)
  }
  if (res.status === 204) return undefined as T
  return (await res.json()) as T
}

export interface TicketQuery {
  q?: string
  status?: string
  assigneeId?: string
  page?: number
  pageSize?: number
}

const enc = encodeURIComponent

export const api = {
  login: (email: string, password: string) =>
    request<{ token: string; user: User }>('POST', '/login', { email, password }),
  logout: () => request<void>('POST', '/logout'),
  me: () => request<User>('GET', '/me'),
  users: () => request<User[]>('GET', '/users'),
  tickets: (query: TicketQuery) => {
    const p = new URLSearchParams()
    if (query.q) p.set('q', query.q)
    if (query.status) p.set('status', query.status)
    if (query.assigneeId) p.set('assigneeId', query.assigneeId)
    p.set('page', String(query.page ?? 1))
    p.set('pageSize', String(query.pageSize ?? 10))
    return request<TicketPage>('GET', '/tickets?' + p.toString())
  },
  ticket: (id: string) => request<Ticket>('GET', '/tickets/' + enc(id)),
  createTicket: (input: TicketInput) => request<Ticket>('POST', '/tickets', input),
  updateTicket: (id: string, patch: Partial<TicketInput> & { status?: Status }) =>
    request<Ticket>('PATCH', '/tickets/' + enc(id), patch),
  comments: (id: string) => request<Comment[]>('GET', '/tickets/' + enc(id) + '/comments'),
  addComment: (id: string, body: string) =>
    request<Comment>('POST', '/tickets/' + enc(id) + '/comments', { body }),
}
