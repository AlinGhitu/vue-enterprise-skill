import { afterEach, describe, expect, it, vi } from 'vitest'
import { api } from '../client'

afterEach(() => vi.unstubAllGlobals())

function stub() {
  const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(new Response(JSON.stringify({ items: [] })))
  vi.stubGlobal('fetch', fetchMock)
  vi.stubGlobal('localStorage', { getItem: () => null })
  return fetchMock
}

describe('api.tickets', () => {
  it('sends assigneeId, including none', async () => {
    const f = stub()
    await api.tickets({ assigneeId: 'none', status: 'open', q: 'a', page: 2 })
    const url = new URL(f.mock.calls[0]![0] as string, 'http://x')
    expect(url.searchParams.get('assigneeId')).toBe('none')
    expect(url.searchParams.get('page')).toBe('2')
  })
  it('omits empty assigneeId', async () => {
    const f = stub()
    await api.tickets({ assigneeId: '' })
    expect(f.mock.calls[0]![0]).not.toContain('assigneeId')
  })
})
