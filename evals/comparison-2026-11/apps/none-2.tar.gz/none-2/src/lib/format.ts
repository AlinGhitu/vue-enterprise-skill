export const formatDate = (iso: string) =>
  new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })
export const formatDateTime = (iso: string) => new Date(iso).toLocaleString()
export const statusLabel = (s: string) => s.replace('_', ' ')
export const totalPages = (total: number, pageSize: number) =>
  Math.max(1, Math.ceil(total / pageSize))
