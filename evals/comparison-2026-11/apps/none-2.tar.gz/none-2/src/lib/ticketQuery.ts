import type { LocationQuery } from 'vue-router'

export interface ListFilters {
  q: string
  status: string
  assigneeId: string
  page: number
}

function first(v: LocationQuery[string] | undefined): string {
  const x = Array.isArray(v) ? v[0] : v
  return x ?? ''
}

/** Read list filters from a route query; `assigneeId` may be a user id or 'none'. */
export function parseListQuery(query: LocationQuery): ListFilters {
  const page = Math.floor(Number(first(query.page)))
  return {
    q: first(query.q),
    status: first(query.status),
    assigneeId: first(query.assigneeId),
    page: Number.isFinite(page) && page > 1 ? page : 1,
  }
}

/** Merge a patch into a route query, dropping empty values and page 1. */
export function buildListQuery(
  current: LocationQuery,
  patch: Record<string, string | number | undefined>,
): Record<string, string> {
  const next: Record<string, unknown> = { ...current, ...patch }
  const out: Record<string, string> = {}
  for (const [k, v] of Object.entries(next)) {
    const s = String(first(v as LocationQuery[string]))
    if (s === '' || (k === 'page' && s === '1')) continue
    out[k] = s
  }
  return out
}
