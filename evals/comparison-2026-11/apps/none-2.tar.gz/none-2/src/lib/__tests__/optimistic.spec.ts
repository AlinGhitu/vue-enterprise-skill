import { describe, it, expect } from 'vitest'
import { closeTicketOptimistically } from '../optimistic'
import { safeRedirect } from '../redirect'
import { totalPages } from '../format'

describe('closeTicketOptimistically', () => {
  it('updates immediately and keeps the change on success', async () => {
    const t = { id: '1', status: 'open' }
    let resolve!: () => void
    const p = closeTicketOptimistically(t, () => new Promise<void>((r) => (resolve = r)))
    expect(t.status).toBe('closed')
    resolve()
    await p
    expect(t.status).toBe('closed')
  })
  it('rolls back to the previous status on failure', async () => {
    const t = { id: '1', status: 'in_progress' }
    await expect(
      closeTicketOptimistically(t, () => Promise.reject(new Error('boom'))),
    ).rejects.toThrow('boom')
    expect(t.status).toBe('in_progress')
  })
})

describe('safeRedirect', () => {
  it('allows app paths', () => expect(safeRedirect('/tickets/3?x=1')).toBe('/tickets/3?x=1'))
  it('rejects external and loop targets', () => {
    expect(safeRedirect('//evil.com')).toBe('/tickets')
    expect(safeRedirect('https://evil.com')).toBe('/tickets')
    expect(safeRedirect('/login')).toBe('/tickets')
    expect(safeRedirect(undefined)).toBe('/tickets')
  })
})

describe('totalPages', () => {
  it('computes pages', () => {
    expect(totalPages(0, 10)).toBe(1)
    expect(totalPages(21, 10)).toBe(3)
  })
})
