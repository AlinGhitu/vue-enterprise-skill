import { describe, it, expect } from 'vitest'
import { validateTicket, validateComment, validateLogin } from '../validation'

const ok = {
  title: 'Hello world',
  description: 'A long enough description',
  priority: 'low' as const,
  assigneeId: null,
}

describe('validateTicket', () => {
  it('accepts valid input', () => expect(validateTicket(ok)).toEqual({}))
  it('rejects short and padded titles', () => {
    expect(validateTicket({ ...ok, title: 'abcd' }).title).toBeTruthy()
    expect(validateTicket({ ...ok, title: '  abcd  ' }).title).toBeTruthy()
  })
  it('enforces title max of 120', () => {
    expect(validateTicket({ ...ok, title: 'a'.repeat(120) }).title).toBeUndefined()
    expect(validateTicket({ ...ok, title: 'a'.repeat(121) }).title).toBeTruthy()
  })
  it('requires 10 character description', () => {
    expect(validateTicket({ ...ok, description: '123456789' }).description).toBeTruthy()
    expect(validateTicket({ ...ok, description: '1234567890' }).description).toBeUndefined()
  })
})

describe('validateComment / validateLogin', () => {
  it('rejects blank comments', () => {
    expect(validateComment('   ').body).toBeTruthy()
    expect(validateComment('hi')).toEqual({})
  })
  it('validates login fields', () => {
    expect(Object.keys(validateLogin('nope', ''))).toEqual(['email', 'password'])
    expect(validateLogin('a@b.co', 'x')).toEqual({})
  })
})
