import { describe, expect, it } from 'vitest'
import { buildListQuery, parseListQuery } from '../ticketQuery'

describe('parseListQuery', () => {
  it('defaults', () => {
    expect(parseListQuery({})).toEqual({ q: '', status: '', assigneeId: '', page: 1 })
  })
  it('reads values', () => {
    expect(parseListQuery({ q: 'x', status: 'open', assigneeId: 'none', page: '3' })).toEqual({
      q: 'x',
      status: 'open',
      assigneeId: 'none',
      page: 3,
    })
  })
  it('sanitizes bad pages and repeated params', () => {
    expect(parseListQuery({ page: 'abc' }).page).toBe(1)
    expect(parseListQuery({ page: '-2' }).page).toBe(1)
    expect(parseListQuery({ page: '2.7' }).page).toBe(2)
    expect(parseListQuery({ q: ['a', 'b'] }).q).toBe('a')
  })
})

describe('buildListQuery', () => {
  it('merges and drops empty values', () => {
    expect(buildListQuery({ q: 'a', status: 'open' }, { status: '', assigneeId: 'u1' })).toEqual({
      q: 'a',
      assigneeId: 'u1',
    })
  })
  it('drops page 1 and keeps others', () => {
    expect(buildListQuery({ page: '4' }, { page: 1 })).toEqual({})
    expect(buildListQuery({ q: 'a' }, { page: 2 })).toEqual({ q: 'a', page: '2' })
  })
})
