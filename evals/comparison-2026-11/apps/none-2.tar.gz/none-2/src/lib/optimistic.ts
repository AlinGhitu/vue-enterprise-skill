/**
 * Applies `apply` immediately, awaits `commit`, and calls `rollback` if it fails.
 * Returns the commit result, or rethrows after rolling back.
 */
export async function optimistic<T>(
  apply: () => void,
  rollback: () => void,
  commit: () => Promise<T>,
): Promise<T> {
  apply()
  try {
    return await commit()
  } catch (e) {
    rollback()
    throw e
  }
}

export function closeTicketOptimistically(
  ticket: { id: string; status: string },
  update: (id: string, patch: { status: 'closed' }) => Promise<unknown>,
) {
  const previous = ticket.status
  return optimistic(
    () => {
      ticket.status = 'closed'
    },
    () => {
      ticket.status = previous
    },
    () => update(ticket.id, { status: 'closed' }),
  )
}
