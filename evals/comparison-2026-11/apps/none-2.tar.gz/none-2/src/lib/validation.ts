import type { TicketInput } from '@/api/types'
import { PRIORITIES } from '@/api/types'

export type FieldErrors = Partial<Record<string, string>>

/** Mirrors the API rules: title 5-120 chars, description >= 10 chars. */
export function validateTicket(input: TicketInput): FieldErrors {
  const errors: FieldErrors = {}
  if (input.title.trim().length < 5 || input.title.length > 120)
    errors.title = 'Title must be 5-120 characters'
  if (input.description.trim().length < 10)
    errors.description = 'Description must be at least 10 characters'
  if (!PRIORITIES.includes(input.priority)) errors.priority = 'Unknown priority'
  return errors
}

export function validateComment(body: string): FieldErrors {
  return body.trim() ? {} : { body: 'Comment cannot be empty' }
}

export function validateLogin(email: string, password: string): FieldErrors {
  const errors: FieldErrors = {}
  if (!/^\S+@\S+\.\S+$/.test(email.trim())) errors.email = 'Enter a valid email address'
  if (!password) errors.password = 'Password is required'
  return errors
}
