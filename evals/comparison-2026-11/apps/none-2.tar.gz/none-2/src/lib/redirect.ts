/** Only allow same-app absolute paths as post-login redirect targets. */
export function safeRedirect(value: unknown): string {
  const v = Array.isArray(value) ? value[0] : value
  if (typeof v === 'string' && v.startsWith('/') && !v.startsWith('//') && !v.startsWith('/login'))
    return v
  return '/tickets'
}
