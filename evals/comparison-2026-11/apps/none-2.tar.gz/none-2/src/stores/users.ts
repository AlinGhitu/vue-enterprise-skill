import { defineStore } from 'pinia'
import { ref } from 'vue'
import { api } from '@/api/client'
import type { User } from '@/api/types'

export const useUsersStore = defineStore('users', () => {
  const users = ref<User[]>([])
  const loaded = ref(false)
  let pending: Promise<void> | null = null

  function load() {
    if (loaded.value) return Promise.resolve()
    pending ??= api
      .users()
      .then((u) => {
        users.value = u
        loaded.value = true
      })
      .finally(() => {
        pending = null
      })
    return pending
  }

  const nameOf = (id: string | null | undefined) =>
    id ? (users.value.find((u) => u.id === id)?.name ?? 'Unknown user') : 'Unassigned'

  return { users, loaded, load, nameOf }
})
