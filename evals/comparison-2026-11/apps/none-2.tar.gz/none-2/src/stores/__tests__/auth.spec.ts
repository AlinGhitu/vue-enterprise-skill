import { describe, it, expect, beforeEach, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { createMemoryHistory, createRouter } from 'vue-router'
import { useAuthStore } from '../auth'
import { installGuards } from '@/router'

const jsonRes = (status: number, body: unknown) =>
  Promise.resolve(
    new Response(JSON.stringify(body), {
      status,
      headers: { 'content-type': 'application/json' },
    }),
  )

beforeEach(() => {
  localStorage.clear()
  setActivePinia(createPinia())
  vi.restoreAllMocks()
})

describe('auth store', () => {
  it('stores token on login and clears on logout', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(((url: string) =>
      url.endsWith('/login')
        ? jsonRes(200, { token: 't', user: { id: '1', name: 'D', email: 'd@x.co' } })
        : Promise.resolve(new Response(null, { status: 204 }))) as typeof fetch)
    const auth = useAuthStore()
    await auth.login('d@x.co', 'pw')
    expect(auth.isLoggedIn).toBe(true)
    expect(localStorage.getItem('support-desk-token')).toBe('t')
    await auth.logout()
    expect(auth.isLoggedIn).toBe(false)
    expect(localStorage.getItem('support-desk-token')).toBeNull()
  })

  it('rejects bad credentials', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation((() =>
      jsonRes(401, { message: 'Invalid' })) as typeof fetch)
    await expect(useAuthStore().login('a@b.co', 'x')).rejects.toThrow('Invalid')
  })
})

describe('route guard', () => {
  it('redirects anonymous users to login with the wanted path', async () => {
    const stub = { template: '<div />' }
    const router = createRouter({
      history: createMemoryHistory(),
      routes: [
        { path: '/login', name: 'login', component: stub, meta: { public: true } },
        { path: '/tickets', name: 'tickets', component: stub },
        { path: '/tickets/:id', name: 'ticket', component: stub },
      ],
    })
    installGuards(router)
    await router.push('/tickets/5?x=1')
    expect(router.currentRoute.value.name).toBe('login')
    expect(router.currentRoute.value.query.redirect).toBe('/tickets/5?x=1')
  })
})
