import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { api, getToken, setToken } from '@/api/client'
import type { User } from '@/api/types'

export const useAuthStore = defineStore('auth', () => {
  const user = ref<User | null>(null)
  const token = ref<string | null>(getToken())
  const isLoggedIn = computed(() => !!token.value)

  async function login(email: string, password: string) {
    const res = await api.login(email.trim(), password)
    setToken(res.token)
    token.value = res.token
    user.value = res.user
  }

  /** Restore the user after a page reload; clears the session if the token is invalid. */
  async function restore() {
    if (!token.value || user.value) return
    try {
      user.value = await api.me()
    } catch {
      clear()
    }
  }

  function clear() {
    setToken(null)
    token.value = null
    user.value = null
  }

  async function logout() {
    try {
      await api.logout()
    } catch {
      /* ignore: we clear locally regardless */
    }
    clear()
  }

  return { user, token, isLoggedIn, login, restore, logout, clear }
})
